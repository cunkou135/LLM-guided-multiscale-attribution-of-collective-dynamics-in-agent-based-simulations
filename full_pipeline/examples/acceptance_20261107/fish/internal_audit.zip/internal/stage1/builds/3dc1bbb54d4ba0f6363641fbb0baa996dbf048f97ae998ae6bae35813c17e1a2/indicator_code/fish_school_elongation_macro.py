import numpy as np
import pandas as pd


def compute_indicator(data, config):
    _ = config
    df = data['agent_states']
    cols = ['run_id', 'step', 'role', 'x', 'y']
    missing = [c for c in cols if c not in df.columns]
    if missing:
        raise KeyError(f'agent_states missing required columns: {missing}')
    d = df.loc[:, cols].copy()
    d = d[d['role'].astype(str) == 'fish'].copy()
    d['x'] = pd.to_numeric(d['x'], errors='coerce')
    d['y'] = pd.to_numeric(d['y'], errors='coerce')
    d['step'] = pd.to_numeric(d['step'], errors='coerce')
    d = d.dropna(subset=['run_id', 'step', 'x', 'y'])
    d = d[np.isfinite(d['x']) & np.isfinite(d['y']) & np.isfinite(d['step'])]
    d = d[d['step'] == np.floor(d['step'])].copy()
    d['step'] = d['step'].astype('int64')
    rows = []
    if len(d):
        for (run_id, step), g in d.groupby(['run_id', 'step'], sort=False):
            n = len(g)
            if n < 2:
                val = np.nan
            else:
                x = g['x'].to_numpy(dtype=float)
                y = g['y'].to_numpy(dtype=float)
                dx = x - x.mean()
                dy = y - y.mean()
                cxx = float(np.mean(dx * dx))
                cyy = float(np.mean(dy * dy))
                cxy = float(np.mean(dx * dy))
                tr = cxx + cyy
                disc = float(np.sqrt(max((cxx - cyy) ** 2 + 4.0 * cxy * cxy, 0.0)))
                lam1 = (tr + disc) / 2.0
                lam2 = (tr - disc) / 2.0
                if lam2 > 0.0:
                    val = float(np.sqrt(lam1 / lam2))
                else:
                    val = np.nan
            rows.append((run_id, int(step), val))
    if not rows:
        return pd.Series(dtype=float, name='fish_school_elongation_macro').rename_axis('step')
    res = pd.DataFrame(rows, columns=['run_id', 'step', 'fish_school_elongation_macro'])
    run_ids = res['run_id'].unique()
    if len(run_ids) == 1:
        out = res.set_index('step')['fish_school_elongation_macro'].sort_index()
        out.index.name = 'step'
        out.name = 'fish_school_elongation_macro'
        return out
    out = res.pivot(index='step', columns='run_id', values='fish_school_elongation_macro').sort_index()
    out.index.name = 'step'
    return out
