import pandas as pd
import numpy as np
from collections import Counter

def compute_indicator(data, config):
    agent_states = data.get('agent_states')
    contacts = data.get('contacts')
    if agent_states is None or contacts is None:
        raise ValueError('Required tables agent_states and contacts must be present.')
    for c in ['run_id', 'step', 'agent_id', 'role']:
        if c not in agent_states.columns:
            raise KeyError('agent_states missing column ' + c)
    for c in ['run_id', 'step', 'agent_id', 'partner_id']:
        if c not in contacts.columns:
            raise KeyError('contacts missing column ' + c)
    fish = agent_states[['run_id', 'step', 'agent_id', 'role']].copy()
    fish = fish[fish['role'].astype(str).str.lower() == 'fish']
    fish = fish.dropna(subset=['run_id', 'step', 'agent_id'])
    fish['step'] = fish['step'].astype('int64')
    fish['agent_id'] = fish['agent_id'].astype('int64')
    fish = fish[fish['agent_id'] != -1]
    fish_keys = fish[['run_id', 'step', 'agent_id']].drop_duplicates()
    c = contacts[['run_id', 'step', 'agent_id', 'partner_id']].copy()
    c = c.dropna(subset=['run_id', 'step', 'agent_id', 'partner_id'])
    c['step'] = c['step'].astype('int64')
    c['agent_id'] = c['agent_id'].astype('int64')
    c['partner_id'] = c['partner_id'].astype('int64')
    edges = c.merge(fish_keys, on=['run_id', 'step', 'agent_id'], how='inner')
    edges = edges.rename(columns={'agent_id': 'u'})
    fish_keys2 = fish_keys.rename(columns={'agent_id': 'partner_id'})
    edges = edges.merge(fish_keys2, on=['run_id', 'step', 'partner_id'], how='inner')
    edges = edges.rename(columns={'partner_id': 'v'})
    if not edges.empty:
        edges['a'] = np.minimum(edges['u'], edges['v'])
        edges['b'] = np.maximum(edges['u'], edges['v'])
        edges = edges[edges['a'] != edges['b']]
        edges = edges[['run_id', 'step', 'a', 'b']].drop_duplicates()
    else:
        edges = pd.DataFrame(columns=['run_id', 'step', 'a', 'b'])
    fish_groups = fish_keys.groupby(['run_id', 'step'])['agent_id'].apply(list).to_dict()
    if not edges.empty:
        edges_groups = edges.groupby(['run_id', 'step']).apply(lambda df: list(zip(df['a'], df['b']))).to_dict()
    else:
        edges_groups = {}
    results = []
    for key, verts in fish_groups.items():
        run_id, step = key
        n = len(verts)
        if n == 0:
            continue
        parent = {v: v for v in verts}
        rank = {v: 0 for v in verts}
        def find(x):
            while parent[x] != x:
                parent[x] = parent[parent[x]]
                x = parent[x]
            return x
        def union(x, y):
            rx = find(x)
            ry = find(y)
            if rx == ry:
                return
            if rank[rx] < rank[ry]:
                parent[rx] = ry
            elif rank[rx] > rank[ry]:
                parent[ry] = rx
            else:
                parent[ry] = rx
                rank[rx] += 1
        for u, v in edges_groups.get(key, []):
            if u in parent and v in parent:
                union(u, v)
        sizes = Counter(find(v) for v in verts)
        max_size = max(sizes.values()) if sizes else 0
        frag = 1.0 - max_size / n
        results.append({'run_id': run_id, 'step': step, 'fragmentation': frag})
    res_df = pd.DataFrame(results)
    if res_df.empty:
        return pd.DataFrame(index=pd.Index([], name='step', dtype='int64'))
    run_id_cfg = None
    if config is not None:
        run_id_cfg = config.get('run_id')
    if run_id_cfg is not None:
        res_df = res_df[res_df['run_id'] == run_id_cfg]
        if res_df.empty:
            return pd.DataFrame(index=pd.Index([], name='step', dtype='int64'))
    pivot = res_df.pivot(index='step', columns='run_id', values='fragmentation')
    pivot.index = pivot.index.astype('int64')
    pivot.index.name = 'step'
    pivot.columns = [str(col) for col in pivot.columns]
    pivot = pivot.sort_index()
    return pivot