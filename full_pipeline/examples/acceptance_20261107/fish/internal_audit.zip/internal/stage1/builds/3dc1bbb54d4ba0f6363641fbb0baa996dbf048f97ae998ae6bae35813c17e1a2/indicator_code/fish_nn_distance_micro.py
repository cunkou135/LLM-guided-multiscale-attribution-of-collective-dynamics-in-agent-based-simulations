import numpy as np
import pandas as pd
from scipy.spatial.distance import cdist


def compute_indicator(data, config):
    """Per-fish Euclidean distance to the closest other fish at the same sampled step.

    Snapshot semantics: fish rows at (run_id, step) are used as-is; no time pooling
    or event windows. Fish are selected by role == 'fish'. Non-finite coordinates are
    excluded pairwise before taking the minimum. If fewer than two fish with finite
    coordinates exist in a group, the per-fish value is NaN for all fish in that group.

    Returns a long DataFrame with columns: step, agent_id, value.
    """
    df = data["agent_states"]
    required_cols = ["run_id", "step", "agent_id", "role", "x", "y"]
    for col in required_cols:
        if col not in df.columns:
            raise KeyError(col)

    fish = df[df["role"].astype(str) == "fish"].copy()

    if fish.empty:
        return pd.DataFrame(
            {
                "step": pd.Series(dtype="int64"),
                "agent_id": pd.Series(dtype="float64"),
                "value": pd.Series(dtype="float64"),
            }
        )

    fish["step"] = pd.to_numeric(fish["step"], errors="coerce")
    fish["agent_id"] = pd.to_numeric(fish["agent_id"], errors="coerce")
    fish["x"] = pd.to_numeric(fish["x"], errors="coerce")
    fish["y"] = pd.to_numeric(fish["y"], errors="coerce")

    fish = fish[np.isfinite(fish["step"].to_numpy(dtype=float))]
    if fish.empty:
        return pd.DataFrame(
            {
                "step": pd.Series(dtype="int64"),
                "agent_id": pd.Series(dtype="float64"),
                "value": pd.Series(dtype="float64"),
            }
        )
    fish["step"] = fish["step"].astype("int64")

    out_step = []
    out_agent = []
    out_value = []

    for (_run_id, step), group in fish.groupby(["run_id", "step"], sort=True):
        x = group["x"].to_numpy(dtype=float)
        y = group["y"].to_numpy(dtype=float)
        ids = group["agent_id"].to_numpy()
        n = len(group)

        finite = np.isfinite(x) & np.isfinite(y)
        values = np.full(n, np.nan, dtype=float)

        n_finite = int(finite.sum())
        if n_finite >= 2:
            coords = np.column_stack([x[finite], y[finite]])
            dists = cdist(coords, coords, metric="euclidean")
            np.fill_diagonal(dists, np.inf)
            values[finite] = dists.min(axis=1)

        out_step.append(np.full(n, step, dtype=np.int64))
        out_agent.append(ids)
        out_value.append(values)

    result = pd.DataFrame(
        {
            "step": np.concatenate(out_step),
            "agent_id": np.concatenate(out_agent),
            "value": np.concatenate(out_value),
        }
    )
    return result
