import numpy as np
import pandas as pd
from scipy.spatial.distance import cdist


def compute_indicator(data, config):
    df = data["agent_states"][["run_id", "step", "agent_id", "role", "x", "y"]]
    df = df[df["role"] == "fish"].copy()
    df = df.dropna(subset=["step", "agent_id"])
    df["step"] = pd.to_numeric(df["step"], errors="coerce")
    df = df.dropna(subset=["step"])
    df["step"] = df["step"].astype("int64")
    df["x"] = pd.to_numeric(df["x"], errors="coerce")
    df["y"] = pd.to_numeric(df["y"], errors="coerce")
    df = df[np.isfinite(df["x"]) & np.isfinite(df["y"])].copy()

    frames = []
    for (_, step), g in df.groupby(["run_id", "step"], sort=False):
        ids = g["agent_id"].to_numpy()
        coords = g[["x", "y"]].to_numpy(dtype=float)
        n = coords.shape[0]
        if n < 2:
            continue
        dist = cdist(coords, coords, metric="euclidean")
        np.fill_diagonal(dist, np.inf)
        nn = dist.min(axis=1)
        frames.append(pd.DataFrame({"step": step, "agent_id": ids, "value": nn}))

    if not frames:
        index = pd.MultiIndex.from_arrays([[], []], names=["step", "agent_id"])
        return pd.Series(dtype=float, index=index, name="fish_nn_distance_micro")

    out = pd.concat(frames, ignore_index=True)
    out = out.set_index(["step", "agent_id"])["value"]
    out.name = "fish_nn_distance_micro"
    out.index = out.index.set_names(["step", "agent_id"])
    return out
