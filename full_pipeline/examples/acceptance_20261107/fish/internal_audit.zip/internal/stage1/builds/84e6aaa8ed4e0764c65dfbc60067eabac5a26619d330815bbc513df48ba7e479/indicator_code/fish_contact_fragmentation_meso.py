import numpy as np
import pandas as pd


def _fragmentation(fish_ids, edges):
    n = len(fish_ids)
    if n == 0:
        return np.nan
    parent = {i: i for i in fish_ids}
    size = {i: 1 for i in fish_ids}

    def find(x):
        root = x
        while parent[root] != root:
            root = parent[root]
        while parent[x] != x:
            p = parent[x]
            parent[x] = root
            x = p
        return root

    def union(a, b):
        ra = find(a)
        rb = find(b)
        if ra == rb:
            return
        if size[ra] < size[rb]:
            ra, rb = rb, ra
        parent[rb] = ra
        size[ra] += size[rb]

    for a, b in edges:
        if a in parent and b in parent:
            union(a, b)

    counts = {}
    for i in fish_ids:
        r = find(i)
        counts[r] = counts.get(r, 0) + 1
    largest = max(counts.values())
    return 1.0 - float(largest) / float(n)


def compute_indicator(data, config):
    agents = data['agent_states']
    contacts = data['contacts']

    role = agents['role'].astype(str).str.strip()
    fish_mask = role.eq('fish') & agents['agent_id'].notna()
    fish_df = agents.loc[fish_mask, ['step', 'agent_id']].copy()
    if len(fish_df):
        fish_df['step'] = fish_df['step'].astype('int64')
        fish_df['agent_id'] = fish_df['agent_id'].astype('int64')

    c = contacts[['step', 'agent_id', 'partner_id']].dropna(
        subset=['step', 'agent_id', 'partner_id']
    ).copy()
    if len(c):
        c['step'] = c['step'].astype('int64')
        c['agent_id'] = c['agent_id'].astype('int64')
        c['partner_id'] = c['partner_id'].astype('int64')

    fish_by_step = {}
    for step, g in fish_df.groupby('step', sort=False):
        fish_by_step[step] = set(g['agent_id'].tolist())

    edges_by_step = {}
    for step, a, b in c[['step', 'agent_id', 'partner_id']].itertuples(
        index=False, name=None
    ):
        edges_by_step.setdefault(step, []).append((a, b))

    all_steps = sorted(agents['step'].dropna().astype('int64').unique().tolist())
    values = {}
    for step in all_steps:
        values[step] = _fragmentation(
            fish_by_step.get(step, set()),
            edges_by_step.get(step, []),
        )

    series = pd.Series(
        values,
        name='fish_contact_fragmentation_meso',
        dtype='float64',
    )
    series.index.name = 'step'
    return series.sort_index()
