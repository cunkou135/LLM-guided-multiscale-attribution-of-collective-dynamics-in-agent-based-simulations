import pandas as pd
import numpy as np

def compute_indicator(data, config):
    contacts = data['contacts'][['run_id','step','agent_id','partner_id','layer']].copy()
    agent_states = data['agent_states'][['run_id','step','agent_id','infectious']].copy()
    
    contacts = contacts[contacts['layer'].notna()]
    
    contacts['step'] = contacts['step'].astype(int)
    agent_states['step'] = agent_states['step'].astype(int)
    
    agent_states_agent = agent_states.rename(columns={'infectious':'agent_inf'})
    agent_states_partner = agent_states.rename(columns={'infectious':'partner_inf'})
    
    merged = contacts.merge(agent_states_agent, on=['run_id','step','agent_id'], how='left')
    merged = merged.merge(
        agent_states_partner,
        left_on=['run_id','step','partner_id'],
        right_on=['run_id','step','agent_id'],
        how='left',
        suffixes=('','_partner')
    )
    merged = merged.drop(columns=['agent_id_partner'], errors='ignore')
    
    agent_inf_true = merged['agent_inf'].eq(True)
    partner_inf_true = merged['partner_inf'].eq(True)
    any_inf = agent_inf_true | partner_inf_true
    
    agent_missing = merged['agent_inf'].isna() & merged['agent_id'].notna()
    partner_missing = merged['partner_inf'].isna() & merged['partner_id'].notna()
    unresolved = (~any_inf) & (agent_missing | partner_missing)
    
    merged['any_inf'] = any_inf
    merged['unresolved'] = unresolved
    
    grouped = merged.groupby(['run_id','step','layer'], dropna=False).agg(
        N=('any_inf','size'),
        N_inf=('any_inf','sum'),
        unresolved_count=('unresolved','sum')
    ).reset_index()
    
    grouped['fraction'] = np.where(
        (grouped['N'] > 0) & (grouped['unresolved_count'] == 0),
        grouped['N_inf'] / grouped['N'],
        np.nan
    )
    
    if grouped.empty:
        return pd.DataFrame(index=pd.Index([], name='step'))
    
    pivot = grouped.pivot_table(
        index='step',
        columns=['run_id','layer'],
        values='fraction',
        aggfunc='first'
    )
    pivot.columns = [f"{run_id}__{layer}" for run_id, layer in pivot.columns]
    pivot.index.name = 'step'
    return pivot