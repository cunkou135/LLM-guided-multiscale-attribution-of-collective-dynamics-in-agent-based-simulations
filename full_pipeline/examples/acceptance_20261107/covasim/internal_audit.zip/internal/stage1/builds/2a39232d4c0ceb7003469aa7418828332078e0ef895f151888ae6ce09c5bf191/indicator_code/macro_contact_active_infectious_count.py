import pandas as pd

def compute_indicator(data, config):
    '''Per (run_id, step): count distinct agents that are infectious in agent_states
    and also appear as either endpoint in contacts at the same (run_id, step),
    after excluding null, sentinel, and unmatched endpoint identifiers.
    Returns a pandas Series indexed by step, aggregated across runs.
    '''
    if 'agent_states' not in data or 'contacts' not in data:
        raise ValueError('required tables agent_states and contacts are missing')
    states = data['agent_states']
    contacts = data['contacts']

    required_state_cols = ['run_id', 'step', 'agent_id', 'infectious']
    required_contact_cols = ['run_id', 'step', 'agent_id', 'partner_id']
    missing_state = [c for c in required_state_cols if c not in states.columns]
    missing_contact = [c for c in required_contact_cols if c not in contacts.columns]
    if missing_state or missing_contact:
        raise ValueError('missing required columns: ' + str(missing_state + missing_contact))

    s = states[required_state_cols].copy()
    c = contacts[required_contact_cols].copy()

    for df in (s, c):
        df['step'] = pd.to_numeric(df['step'], errors='coerce')
        df['run_id'] = df['run_id'].astype('string')
    s = s.dropna(subset=['run_id', 'step'])
    c = c.dropna(subset=['run_id', 'step'])
    s['step'] = s['step'].astype('int64')
    c['step'] = c['step'].astype('int64')

    s['agent_id'] = pd.to_numeric(s['agent_id'], errors='coerce')
    c['agent_id'] = pd.to_numeric(c['agent_id'], errors='coerce')
    c['partner_id'] = pd.to_numeric(c['partner_id'], errors='coerce')

    s['infectious'] = s['infectious'].fillna(False).astype(bool)

    valid = s.dropna(subset=['agent_id'])[['run_id', 'step', 'agent_id']].drop_duplicates()
    valid['agent_id'] = valid['agent_id'].astype('int64')

    inf = s.loc[s['infectious'], ['run_id', 'step', 'agent_id']].dropna(subset=['agent_id']).drop_duplicates()
    inf['agent_id'] = inf['agent_id'].astype('int64')

    ep1 = c[['run_id', 'step', 'agent_id']].rename(columns={'agent_id': 'endpoint_id'})
    ep2 = c[['run_id', 'step', 'partner_id']].rename(columns={'partner_id': 'endpoint_id'})
    endpoints = pd.concat([ep1, ep2], ignore_index=True)
    endpoints = endpoints.dropna(subset=['endpoint_id'])
    endpoints['endpoint_id'] = endpoints['endpoint_id'].astype('int64')

    sentinel_ids = config.get('sentinel_ids', [-1]) if isinstance(config, dict) else [-1]
    if sentinel_ids:
        endpoints = endpoints[~endpoints['endpoint_id'].isin(sentinel_ids)]

    endpoints_valid = endpoints.merge(
        valid,
        left_on=['run_id', 'step', 'endpoint_id'],
        right_on=['run_id', 'step', 'agent_id'],
        how='inner'
    )
    endpoints_valid = endpoints_valid.drop_duplicates(subset=['run_id', 'step', 'endpoint_id'])

    qualifying = endpoints_valid.merge(
        inf,
        left_on=['run_id', 'step', 'endpoint_id'],
        right_on=['run_id', 'step', 'agent_id'],
        how='inner',
        suffixes=('', '_inf')
    )

    counts = qualifying.groupby(['run_id', 'step'], as_index=False)['endpoint_id'].nunique()
    counts = counts.rename(columns={'endpoint_id': 'count'})

    grid = s[['run_id', 'step']].drop_duplicates()
    per_run = grid.merge(counts, on=['run_id', 'step'], how='left')
    per_run['count'] = per_run['count'].fillna(0).astype('int64')

    agg = 'mean'
    if isinstance(config, dict):
        agg = config.get('aggregation', 'mean')
    if agg not in ('mean', 'median', 'sum', 'min', 'max'):
        agg = 'mean'

    result = per_run.groupby('step')['count'].agg(agg).sort_index()
    result.name = 'macro_contact_active_infectious_count'
    result.index.name = 'step'
    return result