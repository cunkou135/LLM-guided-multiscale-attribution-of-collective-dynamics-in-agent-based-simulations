import pandas as pd
import numpy as np

def compute_indicator(data, config):
    contacts = data['contacts']
    agent_states = data['agent_states']
    c = contacts[['run_id','step','agent_id','partner_id','layer']].copy()
    c = c[c['layer'].notna()]
    a = agent_states[['run_id','step','agent_id','infectious']].copy()
    c = c.merge(a, on=['run_id','step','agent_id'], how='left')
    c = c.rename(columns={'infectious':'inf_agent'})
    a2 = a.rename(columns={'agent_id':'partner_id','infectious':'inf_partner'})
    c = c.merge(a2, on=['run_id','step','partner_id'], how='left')
    c['inf_agent'] = c['inf_agent'].fillna(False).astype(bool)
    c['inf_partner'] = c['inf_partner'].fillna(False).astype(bool)
    c['infectious_edge'] = c['inf_agent'] | c['inf_partner']
    grp = c.groupby(['run_id','step','layer'], sort=False)
    N = grp.size()
    N_inf = grp['infectious_edge'].sum()
    frac = (N_inf / N).rename('fraction')
    df = frac.reset_index()
    pivot = df.pivot_table(index='step', columns=['run_id','layer'], values='fraction', aggfunc='first')
    runs = df['run_id'].unique()
    if len(runs) == 1:
        pivot.columns = [layer for (run, layer) in pivot.columns]
    else:
        pivot.columns = [f"{run}|{layer}" for (run, layer) in pivot.columns]
    pivot.index.name = 'step'
    pivot = pivot.sort_index()
    return pivot
