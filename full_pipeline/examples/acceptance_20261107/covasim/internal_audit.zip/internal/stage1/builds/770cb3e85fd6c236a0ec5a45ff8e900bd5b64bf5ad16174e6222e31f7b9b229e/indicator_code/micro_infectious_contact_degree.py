def compute_indicator(data, config):
    import pandas as pd

    ag = data['agent_states'][['run_id', 'step', 'agent_id', 'infectious']].copy()
    ct = data['contacts'][['run_id', 'step', 'agent_id', 'partner_id']].copy()

    ag = ag.dropna(subset=['run_id', 'step', 'agent_id'])
    ct = ct.dropna(subset=['run_id', 'step', 'agent_id', 'partner_id'])

    # Focal agents must have a known infectious state; do not impute unknown states as false.
    focal = ag.dropna(subset=['infectious'])[
        ['run_id', 'step', 'agent_id', 'infectious']
    ].rename(columns={'infectious': 'focal_infectious'})

    # Partner presence is any valid agent identifier in agent_states at the same run/step.
    partner_presence = ag[['run_id', 'step', 'agent_id']].drop_duplicates().rename(
        columns={'agent_id': 'partner_id'}
    )

    # Partner infectious state is only available when non-null; unknowns are not treated as false.
    partner_inf = ag.dropna(subset=['infectious'])[
        ['run_id', 'step', 'agent_id', 'infectious']
    ].rename(columns={'agent_id': 'partner_id', 'infectious': 'partner_infectious'})

    base = focal[['run_id', 'step', 'agent_id']].drop_duplicates()

    if len(ct) == 0 or len(focal) == 0:
        counts = base.copy()
        counts['value'] = 0
    else:
        edges = ct.merge(focal, on=['run_id', 'step', 'agent_id'], how='inner')
        edges = edges.merge(partner_presence, on=['run_id', 'step', 'partner_id'], how='inner')
        edges = edges.merge(partner_inf, on=['run_id', 'step', 'partner_id'], how='left')

        # Include an edge when the focal agent is infectious, or when the partner is known infectious.
        # Unknown partner infectious states are excluded unless the focal agent is infectious.
        focal_true = edges['focal_infectious'].eq(True)
        partner_true = edges['partner_infectious'].eq(True)
        edges_q = edges[focal_true | partner_true]

        # Count distinct contact partners per focal agent-step.
        edges_q = edges_q.drop_duplicates(subset=['run_id', 'step', 'agent_id', 'partner_id'])
        counts = (
            edges_q.groupby(['run_id', 'step', 'agent_id'], dropna=False)
            .size()
            .rename('value')
            .reset_index()
        )
        counts = base.merge(counts, on=['run_id', 'step', 'agent_id'], how='left')
        counts['value'] = counts['value'].fillna(0).astype(int)

    out = counts[['step', 'agent_id', 'value']].copy()
    out = out.sort_values(['step', 'agent_id']).reset_index(drop=True)
    out = out.set_index(['step', 'agent_id'])
    out.index.names = ['step', 'agent_id']
    out = out.rename(columns={'value': 'micro_infectious_contact_degree'})
    return out
