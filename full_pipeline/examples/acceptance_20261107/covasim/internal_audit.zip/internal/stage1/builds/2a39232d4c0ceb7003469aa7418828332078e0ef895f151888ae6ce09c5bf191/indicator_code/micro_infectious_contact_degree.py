import pandas as pd
import numpy as np


def compute_indicator(data, config):
    contacts = data.get('contacts')
    states = data.get('agent_states')
    if contacts is None or states is None:
        return pd.Series(dtype='float64', name='mean_infectious_contact_partners', index=pd.Index([], name='step'))

    contact_cols = ['run_id', 'step', 'agent_id', 'partner_id']
    state_cols = ['run_id', 'step', 'agent_id', 'infectious']
    for df, cols, name in ((contacts, contact_cols, 'contacts'), (states, state_cols, 'agent_states')):
        missing = [c for c in cols if c not in df.columns]
        if missing:
            return pd.Series(dtype='float64', name='mean_infectious_contact_partners', index=pd.Index([], name='step'))

    contacts = contacts[contact_cols].copy()
    states = states[state_cols].copy()

    contacts = contacts.dropna(subset=['run_id', 'step', 'agent_id', 'partner_id'])
    states = states.dropna(subset=['run_id', 'step', 'agent_id'])

    if contacts.empty or states.empty:
        return pd.Series(dtype='float64', name='mean_infectious_contact_partners', index=pd.Index([], name='step'))

    contacts['step'] = contacts['step'].astype('int64')
    states['step'] = states['step'].astype('int64')
    states['infectious'] = states['infectious'].fillna(False).astype(bool)

    states = (
        states.groupby(['run_id', 'step', 'agent_id'], as_index=False)['infectious']
        .max()
    )

    focal_states = states.rename(columns={'infectious': 'focal_infectious'})
    merged = contacts.merge(
        focal_states,
        on=['run_id', 'step', 'agent_id'],
        how='inner'
    )

    partner_states = states.rename(
        columns={'agent_id': 'partner_id', 'infectious': 'partner_infectious'}
    )
    merged = merged.merge(
        partner_states,
        on=['run_id', 'step', 'partner_id'],
        how='inner'
    )

    merged['edge_infectious'] = merged['focal_infectious'] | merged['partner_infectious']

    infectious_partner_counts = (
        merged[merged['edge_infectious']]
        .groupby(['run_id', 'step', 'agent_id'], sort=False)['partner_id']
        .nunique()
        .rename('n_infectious_contact_partners')
    )

    agents = states[['run_id', 'step', 'agent_id']].drop_duplicates()
    per_agent = agents.merge(
        infectious_partner_counts.reset_index(),
        on=['run_id', 'step', 'agent_id'],
        how='left'
    )
    per_agent['n_infectious_contact_partners'] = (
        per_agent['n_infectious_contact_partners'].fillna(0).astype('int64')
    )

    aggregation = 'mean'
    if isinstance(config, dict):
        aggregation = config.get('agent_aggregation', 'mean')

    if aggregation == 'sum':
        out = per_agent.groupby('step')['n_infectious_contact_partners'].sum()
    elif aggregation == 'median':
        out = per_agent.groupby('step')['n_infectious_contact_partners'].median()
    else:
        out = per_agent.groupby('step')['n_infectious_contact_partners'].mean()

    out = out.sort_index()
    out.index = out.index.astype('int64')
    out.index.name = 'step'
    out.name = 'mean_infectious_contact_partners'
    return out
