import numpy as np
import pandas as pd
from collections import Counter


def _components(n, edges):
    parent = list(range(n))

    def find(a):
        while parent[a] != a:
            parent[a] = parent[parent[a]]
            a = parent[a]
        return a

    for a, b in edges:
        ra, rb = find(a), find(b)
        if ra != rb:
            parent[ra] = rb

    return Counter(find(i) for i in range(n))


def compute_indicator(data, config):
    st = data['agent_states'][['run_id', 'step', 'agent_id', 'role']].copy()
    ct = data['contacts'][['run_id', 'step', 'agent_id', 'partner_id']].copy()

    role = st['role'].astype(str).str.lower()
    st = st[role == str(config.get('role_filter', 'fish')).lower()]
    st = st.dropna(subset=['agent_id'])
    ct = ct.dropna(subset=['agent_id', 'partner_id'])

    contact_groups = {}
    for key, g in ct.groupby(['run_id', 'step']):
        contact_groups[key] = g[['agent_id', 'partner_id']].astype('int64').to_numpy()

    idx = []
    vals = []

    for (rid, step), g in st.groupby(['run_id', 'step'], sort=True):
        ids = g['agent_id'].astype('int64').to_numpy()
        n = len(ids)
        index_map = {int(a): i for i, a in enumerate(ids)}

        edges = []
        for a, b in contact_groups.get((rid, step), np.empty((0, 2), dtype='int64')):
            ia = index_map.get(int(a))
            ib = index_map.get(int(b))
            if ia is not None and ib is not None and ia != ib:
                edges.append((ia, ib))

        comps = _components(n, edges)
        idx.append(step)
        vals.append(len(comps))

    return pd.Series(vals, index=pd.Index(idx, name='step'), name='value')
