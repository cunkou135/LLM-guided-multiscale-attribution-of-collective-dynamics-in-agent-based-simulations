import numpy as np
import pandas as pd


def compute_indicator(data, config):
    st = data['agent_states'][['run_id', 'step', 'agent_id', 'role', 'x', 'y']].copy()
    role = st['role'].astype(str).str.lower()
    st = st[role == str(config.get('role_filter', 'fish')).lower()]
    st = st.dropna(subset=['agent_id', 'x', 'y'])

    idx = []
    vals = []

    for (rid, step), g in st.groupby(['run_id', 'step'], sort=True):
        p = g[['x', 'y']].to_numpy(dtype=float)
        n = len(p)
        idx.append(step)

        if n < 3:
            vals.append(np.nan)
            continue

        mu = p.mean(axis=0)
        d = p - mu
        cov = (d.T @ d) / (n - 1)
        w = np.linalg.eigvalsh(cov)
        if w[0] > 0:
            vals.append(float(w[1] / w[0]))
        else:
            vals.append(np.nan)

    return pd.Series(vals, index=pd.Index(idx, name='step'), name='value')
