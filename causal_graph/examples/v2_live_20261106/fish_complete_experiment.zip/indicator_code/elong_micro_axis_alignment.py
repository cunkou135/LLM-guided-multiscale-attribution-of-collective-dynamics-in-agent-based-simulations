import numpy as np
import pandas as pd


def compute_indicator(data, config):
    st = data['agent_states'][['run_id', 'step', 'agent_id', 'role', 'x', 'y', 'heading']].copy()
    role = st['role'].astype(str).str.lower()
    st = st[role == str(config.get('role_filter', 'fish')).lower()]
    st = st.dropna(subset=['agent_id', 'x', 'y', 'heading'])

    steps = []
    aids = []
    vals = []

    for (rid, step), g in st.groupby(['run_id', 'step'], sort=True):
        ids = g['agent_id'].astype('int64').to_numpy()
        p = g[['x', 'y']].to_numpy(dtype=float)
        h = g['heading'].to_numpy(dtype=float)
        n = len(ids)

        if n < 3:
            a = np.full(n, np.nan)
        else:
            mu = p.mean(axis=0)
            d = p - mu
            cov = (d.T @ d) / (n - 1)
            w, v = np.linalg.eigh(cov)
            if w[1] <= 0 or np.isclose(w[1], w[0]):
                a = np.full(n, np.nan)
            else:
                u = v[:, 1]
                a = np.abs(np.cos(h) * u[0] + np.sin(h) * u[1])

        steps.extend([step] * n)
        aids.extend(ids.tolist())
        vals.extend(a.tolist())

    out = pd.DataFrame({'step': steps, 'agent_id': aids, 'value': vals})
    out = out.set_index(['step', 'agent_id'])
    return out
