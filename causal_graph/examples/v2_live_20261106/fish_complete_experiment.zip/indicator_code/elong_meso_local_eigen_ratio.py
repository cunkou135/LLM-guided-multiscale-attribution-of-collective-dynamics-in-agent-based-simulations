import numpy as np
import pandas as pd


def compute_indicator(data, config):
    st = data['agent_states'][['run_id', 'step', 'agent_id', 'role', 'x', 'y']].copy()
    ct = data['contacts'][['run_id', 'step', 'agent_id', 'partner_id']].copy()

    role = st['role'].astype(str).str.lower()
    st = st[role == str(config.get('role_filter', 'fish')).lower()]
    st = st.dropna(subset=['agent_id', 'x', 'y'])
    ct = ct.dropna(subset=['agent_id', 'partner_id'])
    min_size = int(config.get('min_neighborhood_size', 3))

    contact_groups = {}
    for key, g in ct.groupby(['run_id', 'step']):
        contact_groups[key] = g[['agent_id', 'partner_id']].astype('int64').to_numpy()

    idx = []
    vals = []

    for (rid, step), g in st.groupby(['run_id', 'step'], sort=True):
        ids = g['agent_id'].astype('int64').to_numpy()
        p = g[['x', 'y']].to_numpy(dtype=float)
        n = len(ids)
        index_map = {int(a): i for i, a in enumerate(ids)}
        adj = {i: set() for i in range(n)}

        for a, b in contact_groups.get((rid, step), np.empty((0, 2), dtype='int64')):
            ia = index_map.get(int(a))
            ib = index_map.get(int(b))
            if ia is not None and ib is not None and ia != ib:
                adj[ia].add(ib)
                adj[ib].add(ia)

        ratios = []
        for i in range(n):
            S = [i] + list(adj[i])
            if len(S) < min_size:
                continue
            q = p[S]
            mu = q.mean(axis=0)
            d = q - mu
            cov = (d.T @ d) / (len(S) - 1)
            w = np.linalg.eigvalsh(cov)
            if w[0] > 0:
                ratios.append(w[1] / w[0])

        idx.append(step)
        vals.append(float(np.mean(ratios)) if ratios else np.nan)

    return pd.Series(vals, index=pd.Index(idx, name='step'), name='value')
