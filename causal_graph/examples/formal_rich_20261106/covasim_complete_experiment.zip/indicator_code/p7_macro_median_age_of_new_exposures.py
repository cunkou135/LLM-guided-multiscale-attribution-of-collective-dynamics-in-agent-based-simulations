import numpy as np
import pandas as pd


def _flag_transitions(df, col):
    x = df.dropna(subset=['run_id', 'agent_id', 'step']).copy()
    if x.empty:
        return pd.DataFrame(columns=['run_id', 'agent_id', 'step'])
    x['agent_id'] = x['agent_id'].astype('int64')
    x['step'] = x['step'].astype('int64')
    x[col] = x[col].fillna(False).astype(bool)
    x = x.drop_duplicates(subset=['run_id', 'agent_id', 'step']).sort_values(['run_id', 'agent_id', 'step'])
    prev = x.groupby(['run_id', 'agent_id'], sort=False)[col].shift(1)
    cur = x[col].to_numpy(dtype=bool)
    prev_false = (~prev.fillna(False).astype(bool)).to_numpy()
    mask = cur & prev_false
    return x.loc[mask, ['run_id', 'agent_id', 'step']].reset_index(drop=True)


def _empty(names, name):
    return pd.Series(dtype='float64', name=name, index=pd.MultiIndex.from_arrays([[] for _ in names], names=names))


def compute_indicator(data, config):
    ast = data['agent_states']
    base = ast[['run_id', 'agent_id', 'step', 'exposed']].dropna(subset=['run_id', 'agent_id', 'step']).copy()
    tr = _flag_transitions(base, 'exposed')
    if tr.empty:
        return _empty(['step', 'run_id'], 'median_age_new_exposures')
    ag = ast[['run_id', 'agent_id', 'step', 'age']].dropna(subset=['run_id', 'agent_id', 'step', 'age']).copy()
    if ag.empty:
        return _empty(['step', 'run_id'], 'median_age_new_exposures')
    ag['agent_id'] = ag['agent_id'].astype('int64')
    ag['step'] = ag['step'].astype('int64')
    merged = tr.merge(ag, on=['run_id', 'agent_id', 'step'], how='inner')
    if merged.empty:
        return _empty(['step', 'run_id'], 'median_age_new_exposures')
    med = merged.groupby(['run_id', 'step'], sort=True)['age'].median()
    out = med.reorder_levels(['step', 'run_id']).sort_index()
    out.name = 'median_age_new_exposures'
    return out
