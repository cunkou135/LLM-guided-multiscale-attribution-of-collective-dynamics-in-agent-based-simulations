import numpy as np
import pandas as pd


def compute_indicator(data, config):
    df = data["agent_states"][["run_id", "agent_id", "step", "infectious", "diagnosed"]].copy()
    df = df.sort_values(["run_id", "agent_id", "step"], kind="mergesort")
    inj = df["infectious"].fillna(False).astype(bool)
    diag = df["diagnosed"].fillna(False).astype(bool)
    df["Z"] = (inj & (~diag)).astype(int)
    df["cum"] = df.groupby(["run_id", "agent_id"])["Z"].cumsum()
    out = df.set_index(["run_id", "step", "agent_id"])["cum"].astype(float)
    out.name = "silent_infectious_duration"
    return out
