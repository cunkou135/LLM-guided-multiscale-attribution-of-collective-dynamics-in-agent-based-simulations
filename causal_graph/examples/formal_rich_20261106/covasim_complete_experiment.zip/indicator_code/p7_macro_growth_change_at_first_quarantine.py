import math
import numpy as np
import pandas as pd


def _flag_transitions(df, col):
    x = df.dropna(subset=['run_id', 'agent_id', 'step']).copy()
    if x.empty:
        return pd.DataFrame(columns=['run_id', 'agent_id', 'step'])
    x['agent_id'] = x['agent_id'].astype('int64')
    x['step'] = x['step'].astype('int64')
    x[col] = x[col].fillna(False).astype(bool)
    x = x.drop_duplicates(subset=['run_id', 'agent_id', 'step']).sort_values(['run_id', 'agent_id', 'step'])
    prev = x.groupby(['run_id', 'agent_id'], sort=False)[col].shift(1)
    cur = x[col].to_numpy(dtype=bool)
    prev_false = (~prev.fillna(False).astype(bool)).to_numpy()
    mask = cur & prev_false
    return x.loc[mask, ['run_id', 'agent_id', 'step']].reset_index(drop=True)


def _empty(names, name):
    return pd.Series(dtype='float64', name=name, index=pd.MultiIndex.from_arrays([[] for _ in names], names=names))


def compute_indicator(data, config):
    ast = data['agent_states']
    base = ast[['run_id', 'agent_id', 'step', 'exposed', 'quarantined']].dropna(subset=['run_id', 'agent_id', 'step']).copy()
    if base.empty:
        return _empty(['step', 'run_id'], 'growth_change_at_first_quarantine')
    exp_tr = _flag_transitions(base, 'exposed')
    qua_tr = _flag_transitions(base, 'quarantined')
    if exp_tr.empty or qua_tr.empty:
        return _empty(['step', 'run_id'], 'growth_change_at_first_quarantine')
    tq = qua_tr.groupby('run_id', sort=True)['step'].min()
    base['step'] = base['step'].astype('int64')
    grid = base[['run_id', 'step']].drop_duplicates().sort_values(['run_id', 'step'])
    cnt = exp_tr.groupby(['run_id', 'step'], sort=True).size().rename('n').reset_index()
    grid_n = grid.merge(cnt, on=['run_id', 'step'], how='left')
    grid_n['n'] = grid_n['n'].fillna(0).astype('int64')
    rows = []
    for rid, sub in grid_n.groupby('run_id', sort=True):
        if rid not in tq.index:
            continue
        anchor = int(tq.loc[rid])
        nmap = dict(zip(sub['step'].astype('int64').tolist(), sub['n'].astype('int64').tolist()))
        before = []
        after = []
        for s in sorted(nmap.keys()):
            if (s - 1) not in nmap:
                continue
            n0 = nmap[s - 1]
            n1 = nmap[s]
            if n0 <= 0 or n1 <= 0:
                continue
            val = math.log(float(n1) / float(n0))
            if s < anchor:
                before.append(val)
            elif s > anchor:
                after.append(val)
        if not before or not after:
            continue
        rows.append((anchor, rid, float(np.mean(after) - np.mean(before))))
    if not rows:
        return _empty(['step', 'run_id'], 'growth_change_at_first_quarantine')
    res = pd.DataFrame(rows, columns=['step', 'run_id', 'value'])
    out = res.set_index(['step', 'run_id'])['value'].sort_index()
    out.name = 'growth_change_at_first_quarantine'
    return out
