import numpy as np
import pandas as pd


def compute_indicator(data, config):
    df = data["agent_states"][["run_id", "agent_id", "step", "exposed", "infectious", "diagnosed", "quarantined"]].copy()
    df = df.sort_values(["run_id", "agent_id", "step"], kind="mergesort")
    exp = df["exposed"].fillna(False).astype(bool)
    df["exp"] = exp
    prev = df.groupby(["run_id", "agent_id"])["exp"].shift(1)
    had_prev = prev.notna()
    prev_bool = prev.fillna(False).astype(bool)
    df["X"] = (had_prev & df["exp"] & (~prev_bool)).astype(int)
    inj = df["infectious"].fillna(False).astype(bool)
    diag = df["diagnosed"].fillna(False).astype(bool)
    df["Z"] = (inj & (~diag)).astype(int)
    df["group_id"] = df["quarantined"].fillna(False).astype(bool)
    g = df.groupby(["run_id", "step", "group_id"])
    xsum = g["X"].sum()
    zsum = g["Z"].sum()
    y = xsum / zsum.where(zsum > 0, np.nan)
    y = y.astype(float)
    y.name = "exposure_yield_silent"
    return y
