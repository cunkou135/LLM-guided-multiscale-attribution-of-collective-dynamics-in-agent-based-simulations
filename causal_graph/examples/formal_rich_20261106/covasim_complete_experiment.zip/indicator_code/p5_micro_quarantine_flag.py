import pandas as pd


def compute_indicator(data, config):
    df = data["agent_states"][["run_id", "agent_id", "step", "quarantined"]].copy()
    df["flag"] = df["quarantined"].fillna(False).astype(bool).astype(float)
    out = df.set_index(["run_id", "step", "agent_id"])["flag"].astype(float)
    out.name = "quarantine_flag"
    return out
