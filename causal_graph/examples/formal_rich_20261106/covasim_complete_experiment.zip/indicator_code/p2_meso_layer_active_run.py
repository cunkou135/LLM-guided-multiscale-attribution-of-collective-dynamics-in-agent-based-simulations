def compute_indicator(data, config):
    import pandas as pd
    import numpy as np
    
    events = data['events']
    agent_states = data['agent_states']
    
    observed_steps = sorted(agent_states['step'].unique())
    
    exp_events = events[(events['state'] == 'exposed') & (events['after'] == True) & events['layer'].notna()]
    layer_step_counts = exp_events.groupby(['layer', 'step']).size().reset_index(name='count')
    
    results = []
    for layer, group in layer_step_counts.groupby('layer'):
        count_series = group.set_index('step')['count'].reindex(observed_steps, fill_value=0)
        run_length = 0
        for step in observed_steps:
            if count_series.loc[step] > 0:
                run_length += 1
            else:
                run_length = 0
            results.append({'step': step, 'layer': layer, 'value': run_length})
    
    df = pd.DataFrame(results)
    return df