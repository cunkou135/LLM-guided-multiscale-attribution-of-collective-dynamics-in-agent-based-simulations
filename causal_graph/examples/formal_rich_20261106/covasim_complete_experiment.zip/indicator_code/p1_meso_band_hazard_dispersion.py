def compute_indicator(data, config):
    import numpy as np
    import pandas as pd

    states = data["agent_states"]
    cols = ["step", "agent_id", "age", "exposed", "susceptible"]
    base = states.loc[states["agent_id"].notna() & states["step"].notna(), cols].copy()
    base["step"] = base["step"].astype("int64")
    base["agent_id"] = base["agent_id"].astype("int64")
    base = base.drop_duplicates(subset=["step", "agent_id"], keep="last")
    base = base.sort_values(["agent_id", "step"], kind="mergesort").reset_index(drop=True)

    grp = base.groupby("agent_id", sort=False)
    prev_exposed = grp["exposed"].shift(1)
    prev_susc = grp["susceptible"].shift(1)
    prev_step = grp["step"].shift(1)
    consecutive = prev_step.notna() & (prev_step == base["step"] - 1)

    cur_b = base["exposed"].astype("boolean").fillna(False).astype(bool)
    prev_b = prev_exposed.astype("boolean").fillna(False).astype(bool)
    usable = base["exposed"].notna() & prev_exposed.notna() & consecutive
    x = pd.Series(np.where(usable.to_numpy(),
                           np.where((cur_b & ~prev_b).to_numpy(), 1.0, 0.0),
                           np.nan),
                  index=base.index)

    susc_b = prev_susc.astype("boolean").fillna(False).astype(bool)
    susc_ok = base["susceptible"].notna() & prev_susc.notna() & consecutive
    s_prev = pd.Series(np.where(susc_ok.to_numpy(),
                                susc_b.to_numpy().astype("float64"),
                                np.nan),
                       index=base.index)

    age_vals = base.loc[base["age"].notna(), "age"].astype("float64")
    if age_vals.empty:
        return pd.Series(dtype="float64", index=pd.Index([], name="step"), name="p1_meso_band_hazard_dispersion")
    edges = np.unique(np.quantile(age_vals.to_numpy(dtype="float64"), np.linspace(0.1, 0.9, 9)))
    agent_age = base.loc[base["age"].notna()].groupby("agent_id")["age"].first().astype("float64")

    def band_of(v):
        if v is None:
            return None
        fv = float(v)
        if np.isnan(fv):
            return None
        return int(np.searchsorted(edges, fv, side="right"))

    band_map = agent_age.map(band_of)
    work = pd.DataFrame({"step": base["step"],
                         "band": base["agent_id"].map(band_map),
                         "x": x,
                         "s_prev": s_prev})
    work = work.loc[work["band"].notna()].copy()
    work["band"] = work["band"].astype("int64")

    num = work.groupby(["step", "band"])["x"].sum(min_count=1)
    den = work.groupby(["step", "band"])["s_prev"].sum(min_count=1)
    table = pd.concat([num.rename("num"), den.rename("den")], axis=1, join="inner").dropna()
    table = table.loc[table["den"].to_numpy() > 0]
    hazard = (table["num"] / table["den"])

    haz_frame = hazard.reset_index()
    haz_frame.columns = ["step", "band", "h"]
    agg = haz_frame.groupby("step").agg(
        count=("h", "count"),
        mean=("h", "mean"),
        sd=("h", lambda s: float(np.std(s.to_numpy(dtype="float64"), ddof=0))))
    valid = (agg["count"] >= 2) & (agg["mean"] != 0)
    res = (agg["sd"] / agg["mean"]).where(valid).dropna()
    res.index.name = "step"
    res.name = "p1_meso_band_hazard_dispersion"
    return res.sort_index()
