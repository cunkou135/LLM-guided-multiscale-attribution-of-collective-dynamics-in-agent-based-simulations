def compute_indicator(data, config):
    import pandas as pd
    import numpy as np

    ag = data['agent_states'].copy()
    ag = ag.dropna(subset=['step', 'agent_id'])
    ag['step'] = ag['step'].astype(int)
    ag['agent_id'] = ag['agent_id'].astype(int)
    has_run = 'run_id' in ag.columns
    if has_run:
        ag = ag.dropna(subset=['run_id'])
    ag['_susceptible'] = ag['susceptible'].fillna(False).astype(bool)
    ag['_infectious'] = ag['infectious'].fillna(False).astype(bool)

    rows = []
    if has_run:
        inf_counts = ag.groupby(['run_id', 'step'], sort=True)['_infectious'].sum()
        for rid, sub in inf_counts.groupby(level=0):
            if sub.empty:
                continue
            m = sub.min()
            steps = sub[sub == m].index.get_level_values('step')
            if not len(steps):
                continue
            t = int(steps.min())
            at = ag[(ag['run_id'] == rid) & (ag['step'] == t)].drop_duplicates(subset=['agent_id'])
            if at.empty:
                continue
            share = float(at['_susceptible'].sum()) / float(len(at))
            if np.isfinite(share):
                rows.append((rid, t, share))
    else:
        inf_counts = ag.groupby('step', sort=True)['_infectious'].sum()
        if not inf_counts.empty:
            m = inf_counts.min()
            steps = inf_counts[inf_counts == m].index
            t = int(steps.min())
            at = ag[ag['step'] == t].drop_duplicates(subset=['agent_id'])
            if not at.empty:
                share = float(at['_susceptible'].sum()) / float(len(at))
                if np.isfinite(share):
                    rows.append((t, share))

    if not rows:
        return pd.Series(dtype=float, name='trough_susceptible_share')
    if has_run:
        idx = pd.MultiIndex.from_tuples([(r[0], r[1]) for r in rows], names=['run_id', 'step'])
        return pd.Series([r[2] for r in rows], index=idx, name='trough_susceptible_share')
    idx = pd.Index([r[0] for r in rows], name='step')
    return pd.Series([r[1] for r in rows], index=idx, name='trough_susceptible_share')
