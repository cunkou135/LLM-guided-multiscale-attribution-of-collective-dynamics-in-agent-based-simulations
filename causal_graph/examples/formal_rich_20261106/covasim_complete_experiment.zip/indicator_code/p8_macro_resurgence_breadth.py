def compute_indicator(data, config):
    import pandas as pd
    import numpy as np

    ag = data['agent_states'].copy()
    ev = data['events'].copy()
    co = data['contacts'].copy()

    ag = ag.dropna(subset=['step'])
    ag['step'] = ag['step'].astype(int)
    has_run = 'run_id' in ag.columns
    if has_run:
        ag = ag.dropna(subset=['run_id'])
    ag['_infectious'] = ag['infectious'].fillna(False).astype(bool)

    if has_run:
        inf_counts = ag.groupby(['run_id', 'step'], sort=True)['_infectious'].sum()
        troughs = {}
        for rid, sub in inf_counts.groupby(level=0):
            if sub.empty:
                continue
            m = sub.min()
            steps = sub[sub == m].index.get_level_values('step')
            if len(steps):
                troughs[rid] = int(steps.min())
    else:
        inf_counts = ag.groupby('step', sort=True)['_infectious'].sum()
        trough = None
        if not inf_counts.empty:
            m = inf_counts.min()
            steps = inf_counts[inf_counts == m].index
            trough = int(steps.min())

    ev = ev.dropna(subset=['step', 'layer'])
    ev['step'] = ev['step'].astype(int)
    if has_run and 'run_id' in ev.columns:
        ev = ev.dropna(subset=['run_id'])
    ev['_is_exposed'] = ev['state'].astype(str).str.lower().eq('exposed') & ev['after'].fillna(False).astype(bool)
    ev_f = ev[ev['_is_exposed']].copy()

    co = co.dropna(subset=['step', 'layer'])
    co['step'] = co['step'].astype(int)
    if has_run and 'run_id' in co.columns:
        co = co.dropna(subset=['run_id'])
    edge_cols = ['run_id', 'step', 'layer', 'agent_id', 'partner_id'] if has_run else ['step', 'layer', 'agent_id', 'partner_id']
    co_edges = co.drop_duplicates(subset=edge_cols)

    if has_run:
        exp_counts = ev_f.groupby(['run_id', 'step', 'layer'], sort=True).size()
        edge_counts = co_edges.groupby(['run_id', 'step', 'layer'], sort=True).size()
    else:
        exp_counts = ev_f.groupby(['step', 'layer'], sort=True).size()
        edge_counts = co_edges.groupby(['step', 'layer'], sort=True).size()

    lam = exp_counts.rename('exposures').to_frame().join(edge_counts.rename('edges'), how='outer')
    lam['exposures'] = lam['exposures'].fillna(0.0)
    lam['edges'] = lam['edges'].fillna(0.0)
    lam = lam[lam['edges'] > 0].copy()
    lam['lambda'] = lam['exposures'] / lam['edges']
    lam = lam.reset_index()
    lam['step'] = lam['step'].astype(int)

    def _layer_phi(sub, t):
        phis = []
        for layer, ssub in sub.groupby('layer', sort=True):
            s = ssub.set_index('step')['lambda'].sort_index()
            if t not in s.index:
                continue
            val_t = s.loc[t]
            if not np.isfinite(val_t) or val_t <= 0:
                continue
            after = s[s.index > t]
            after = after[np.isfinite(after)]
            if after.empty:
                continue
            phi = float(after.mean() / val_t)
            if np.isfinite(phi):
                phis.append(phi)
        return phis

    rows = []
    if has_run:
        for rid, sub in lam.groupby('run_id', sort=True):
            t = troughs.get(rid)
            if t is None:
                continue
            phis = _layer_phi(sub, t)
            if not phis:
                continue
            breadth = float(sum(1 for p in phis if p > 1.0)) / float(len(phis))
            if np.isfinite(breadth):
                rows.append((rid, t, breadth))
    else:
        if trough is not None:
            phis = _layer_phi(lam, trough)
            if phis:
                breadth = float(sum(1 for p in phis if p > 1.0)) / float(len(phis))
                if np.isfinite(breadth):
                    rows.append((trough, breadth))

    if not rows:
        return pd.Series(dtype=float, name='post_trough_resurgence_breadth')
    if has_run:
        idx = pd.MultiIndex.from_tuples([(r[0], r[1]) for r in rows], names=['run_id', 'step'])
        return pd.Series([r[2] for r in rows], index=idx, name='post_trough_resurgence_breadth')
    idx = pd.Index([r[0] for r in rows], name='step')
    return pd.Series([r[1] for r in rows], index=idx, name='post_trough_resurgence_breadth')
