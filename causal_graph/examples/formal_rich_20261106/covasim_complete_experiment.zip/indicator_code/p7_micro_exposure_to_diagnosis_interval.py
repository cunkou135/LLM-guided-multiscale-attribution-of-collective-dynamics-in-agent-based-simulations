import numpy as np
import pandas as pd


def _empty_frame(col):
    idx = pd.MultiIndex.from_arrays([[] for _ in range(3)], names=['step', 'run_id', 'agent_id'])
    return pd.DataFrame({col: pd.Series(dtype='float64', index=idx)})


def compute_indicator(data, config):
    ast = data['agent_states']
    d = ast[['run_id', 'agent_id', 'step', 'date_exposed', 'date_diagnosed']].copy()
    d = d.dropna(subset=['run_id', 'agent_id', 'step'])
    if d.empty:
        return _empty_frame('exposure_to_diagnosis_interval')
    d['agent_id'] = d['agent_id'].astype('int64')
    d['step'] = d['step'].astype('int64')
    d = d.sort_values(['run_id', 'agent_id', 'step'])
    exp_rows = d.dropna(subset=['date_exposed'])
    dia_rows = d.dropna(subset=['date_diagnosed'])
    if exp_rows.empty or dia_rows.empty:
        return _empty_frame('exposure_to_diagnosis_interval')
    exp_first = exp_rows.groupby(['run_id', 'agent_id'], sort=True).agg(
        step_exposed=('step', 'min'), date_exposed=('date_exposed', 'first'))
    dia_first = dia_rows.groupby(['run_id', 'agent_id'], sort=True).agg(
        step_diagnosed=('step', 'min'), date_diagnosed=('date_diagnosed', 'first'))
    joined = exp_first.join(dia_first, how='inner').reset_index()
    if joined.empty:
        return _empty_frame('exposure_to_diagnosis_interval')
    step_out = np.maximum(joined['step_exposed'].to_numpy(dtype='int64'), joined['step_diagnosed'].to_numpy(dtype='int64'))
    value = joined['date_diagnosed'].to_numpy(dtype='float64') - joined['date_exposed'].to_numpy(dtype='float64')
    res = pd.DataFrame({'step': step_out, 'run_id': joined['run_id'].to_numpy(), 'agent_id': joined['agent_id'].to_numpy(),
                        'exposure_to_diagnosis_interval': value})
    out = res.set_index(['step', 'run_id', 'agent_id'])[['exposure_to_diagnosis_interval']].sort_index()
    return out
