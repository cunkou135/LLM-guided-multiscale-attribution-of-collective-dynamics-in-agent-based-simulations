def compute_indicator(data, config):
    import numpy as np
    import pandas as pd

    states = data["agent_states"]
    base = states.loc[states["agent_id"].notna() & states["step"].notna(),
                      ["step", "agent_id", "exposed"]].copy()
    base["step"] = base["step"].astype("int64")
    base["agent_id"] = base["agent_id"].astype("int64")
    base = base.drop_duplicates(subset=["step", "agent_id"], keep="last")
    base = base.sort_values(["agent_id", "step"], kind="mergesort").reset_index(drop=True)

    grp = base.groupby("agent_id", sort=False)
    prev_exposed = grp["exposed"].shift(1)
    prev_step = grp["step"].shift(1)
    consecutive = prev_step.notna() & (prev_step == base["step"] - 1)

    cur_b = base["exposed"].astype("boolean").fillna(False).astype(bool)
    prev_b = prev_exposed.astype("boolean").fillna(False).astype(bool)
    usable = base["exposed"].notna() & prev_exposed.notna() & consecutive
    x = pd.Series(np.where(usable.to_numpy(),
                           np.where((cur_b & ~prev_b).to_numpy(), 1.0, 0.0),
                           np.nan),
                  index=base.index)

    ever = x.groupby(base["agent_id"]).cummax().fillna(0.0)

    out = pd.DataFrame({"step": base["step"],
                        "agent_id": base["agent_id"],
                        "value": ever})
    res = out.set_index(["step", "agent_id"])["value"].sort_index()
    res.index = res.index.set_names(["step", "agent_id"])
    res.name = "p1_micro_ever_exposed_state"
    return res
