import numpy as np
import pandas as pd


def _empty(names, name):
    return pd.Series(dtype='float64', name=name, index=pd.MultiIndex.from_arrays([[] for _ in names], names=names))


def compute_indicator(data, config):
    ev = data['events'][['run_id', 'agent_id', 'step', 'state', 'after', 'layer']].copy()
    ev = ev.dropna(subset=['run_id', 'step'])
    if ev.empty:
        return _empty(['step', 'run_id'], 'layer_composition_drift')
    ev['step'] = ev['step'].astype('int64')
    after_true = ev['after'].fillna(False).astype(bool)
    hit = ev[(ev['state'] == 'exposed') & after_true & ev['layer'].notna()]
    if hit.empty:
        return _empty(['step', 'run_id'], 'layer_composition_drift')
    cnt = hit.groupby(['run_id', 'step', 'layer'], sort=True).size().rename('n').reset_index()
    wide = cnt.pivot_table(index=['run_id', 'step'], columns='layer', values='n', aggfunc='sum', fill_value=0)
    shares = wide.div(wide.sum(axis=1), axis=0)
    rows = []
    for rid, sub in shares.groupby(level='run_id', sort=True):
        sub2 = sub.droplevel('run_id')
        t1 = sub2.index.min()
        ref = sub2.loc[t1]
        for t in sub2.index:
            cur = sub2.loc[t]
            rows.append((int(t), rid, 0.5 * float(np.abs(cur - ref).sum())))
    if not rows:
        return _empty(['step', 'run_id'], 'layer_composition_drift')
    res = pd.DataFrame(rows, columns=['step', 'run_id', 'value'])
    out = res.set_index(['step', 'run_id'])['value'].sort_index()
    out.name = 'layer_composition_drift'
    return out
