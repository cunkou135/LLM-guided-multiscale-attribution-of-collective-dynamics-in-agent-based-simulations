import numpy as np
import pandas as pd


def _all_layer_edges(contacts):
    c = contacts[['run_id', 'step', 'layer', 'agent_id', 'partner_id']]
    c = c.dropna(subset=['run_id', 'step', 'layer', 'agent_id', 'partner_id'])
    a = c['agent_id'].to_numpy(dtype='int64')
    b = c['partner_id'].to_numpy(dtype='int64')
    e = pd.DataFrame({
        'run_id': c['run_id'].to_numpy(),
        'step': c['step'].to_numpy(dtype='int64'),
        'u': np.minimum(a, b),
        'v': np.maximum(a, b),
    })
    return e.drop_duplicates(subset=['run_id', 'step', 'u', 'v'])


def compute_indicator(data, config):
    edges = _all_layer_edges(data['contacts'])
    if edges.empty:
        return pd.Series(dtype='float64', index=pd.Index([], name='step', dtype='int64'), name='value')
    vol = edges.groupby(['run_id', 'step']).size().rename('E').reset_index()
    vol = vol.sort_values(['run_id', 'step']).reset_index(drop=True)
    g = vol.groupby('run_id', sort=False)
    prev_e = g['E'].shift(1)
    prev_step = g['step'].shift(1)
    ok = (prev_step == vol['step'] - 1) & prev_e.notna() & (prev_e > 0)
    keep = ok.to_numpy()
    if not keep.any():
        return pd.Series(dtype='float64', index=pd.Index([], name='step', dtype='int64'), name='value')
    sub = vol.loc[keep, ['run_id', 'step', 'E']].copy()
    sub['prev_E'] = prev_e.to_numpy()[keep]
    sub['value'] = (sub['E'] - sub['prev_E']) / sub['prev_E']
    res = sub.groupby('step')['value'].mean()
    res.index.names = ['step']
    return res.rename('value')
