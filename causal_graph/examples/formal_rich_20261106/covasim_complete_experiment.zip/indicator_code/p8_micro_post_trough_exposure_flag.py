def compute_indicator(data, config):
    import pandas as pd
    import numpy as np

    ag = data['agent_states'].copy()
    for col in ['step', 'agent_id', 'exposed', 'infectious']:
        if col not in ag.columns:
            raise KeyError(col)
    ag = ag.dropna(subset=['step', 'agent_id'])
    ag['step'] = ag['step'].astype(int)
    ag['agent_id'] = ag['agent_id'].astype(int)
    has_run = 'run_id' in ag.columns
    if has_run:
        ag = ag.dropna(subset=['run_id'])
    ag['_exposed'] = ag['exposed'].fillna(False).astype(bool)
    ag['_infectious'] = ag['infectious'].fillna(False).astype(bool)

    if has_run:
        inf_counts = ag.groupby(['run_id', 'step'], sort=True)['_infectious'].sum()
        troughs = {}
        for rid, sub in inf_counts.groupby(level=0):
            if sub.empty:
                continue
            m = sub.min()
            steps = sub[sub == m].index.get_level_values('step')
            if len(steps):
                troughs[rid] = int(steps.min())
    else:
        inf_counts = ag.groupby('step', sort=True)['_infectious'].sum()
        trough = None
        if not inf_counts.empty:
            m = inf_counts.min()
            steps = inf_counts[inf_counts == m].index
            trough = int(steps.min())

    group_cols = ['run_id', 'agent_id'] if has_run else ['agent_id']
    ag = ag.sort_values(group_cols + ['step'])
    ag['_prev_exposed'] = ag.groupby(group_cols, sort=False)['_exposed'].shift(1)
    trans = ag[(ag['_prev_exposed'].notna()) & (~ag['_prev_exposed'].astype(bool)) & (ag['_exposed'])].copy()
    if trans.empty:
        return pd.Series(dtype=float, name='post_trough_exposure_flag')

    if has_run:
        trans['_tstar'] = trans['run_id'].map(troughs)
    else:
        trans['_tstar'] = trough
    trans = trans.dropna(subset=['_tstar'])
    if trans.empty:
        return pd.Series(dtype=float, name='post_trough_exposure_flag')
    trans['_tstar'] = trans['_tstar'].astype(int)
    trans['value'] = (trans['step'] > trans['_tstar']).astype(float)
    idx_cols = ['run_id', 'step', 'agent_id'] if has_run else ['step', 'agent_id']
    out = trans.set_index(idx_cols)['value']
    out.name = 'post_trough_exposure_flag'
    return out
