import numpy as np
import pandas as pd


def _degree_table(contacts):
    c = contacts[['run_id', 'step', 'agent_id', 'partner_id']].copy()
    c = c.dropna(subset=['run_id', 'step', 'agent_id', 'partner_id'])
    if c.empty:
        return pd.DataFrame(columns=['run_id', 'step', 'agent_id', 'degree'])
    c['agent_id'] = c['agent_id'].astype('int64')
    c['partner_id'] = c['partner_id'].astype('int64')
    c['step'] = c['step'].astype('int64')
    c = c[c['agent_id'] != c['partner_id']]
    lo = np.minimum(c['agent_id'].to_numpy(), c['partner_id'].to_numpy())
    hi = np.maximum(c['agent_id'].to_numpy(), c['partner_id'].to_numpy())
    pairs = pd.DataFrame({'run_id': c['run_id'].to_numpy(), 'step': c['step'].to_numpy(), 'lo': lo, 'hi': hi})
    pairs = pairs.drop_duplicates()
    left = pairs[['run_id', 'step', 'lo']].rename(columns={'lo': 'agent_id'})
    right = pairs[['run_id', 'step', 'hi']].rename(columns={'hi': 'agent_id'})
    nodes = pd.concat([left, right], ignore_index=True)
    deg = nodes.groupby(['run_id', 'step', 'agent_id'], sort=True).size().rename('degree').reset_index()
    return deg


def _empty(names, name):
    return pd.Series(dtype='float64', name=name, index=pd.MultiIndex.from_arrays([[] for _ in names], names=names))


def compute_indicator(data, config):
    ast = data['agent_states']
    con = data['contacts']
    q = ast[['run_id', 'step', 'agent_id', 'quarantined']].copy()
    q = q.dropna(subset=['run_id', 'step', 'agent_id'])
    if q.empty:
        return _empty(['step', 'run_id'], 'adherence_share')
    q['agent_id'] = q['agent_id'].astype('int64')
    q['step'] = q['step'].astype('int64')
    q['quarantined'] = q['quarantined'].fillna(False).astype(bool)
    q = q.drop_duplicates(subset=['run_id', 'step', 'agent_id'])
    deg = _degree_table(con)
    merged = q.merge(deg, on=['run_id', 'step', 'agent_id'], how='left')
    merged['degree'] = merged['degree'].fillna(0.0)
    rows = []
    for (rid, st), g in merged.groupby(['run_id', 'step'], sort=True):
        qd = g.loc[g['quarantined'], 'degree'].to_numpy(dtype='float64')
        nd = g.loc[~g['quarantined'], 'degree'].to_numpy(dtype='float64')
        if qd.size == 0 or nd.size == 0:
            continue
        med = float(np.median(nd))
        rows.append((int(st), rid, float(np.count_nonzero(qd <= med)) / float(qd.size)))
    if not rows:
        return _empty(['step', 'run_id'], 'adherence_share')
    res = pd.DataFrame(rows, columns=['step', 'run_id', 'value'])
    out = res.set_index(['step', 'run_id'])['value'].sort_index()
    out.name = 'adherence_share'
    return out
