def compute_indicator(data, config):
    import numpy as np
    import pandas as pd

    states = data["agent_states"]
    base = states.loc[states["agent_id"].notna() & states["step"].notna(),
                      ["step", "agent_id", "exposed"]].copy()
    base["step"] = base["step"].astype("int64")
    base["agent_id"] = base["agent_id"].astype("int64")
    base = base.drop_duplicates(subset=["step", "agent_id"], keep="last")
    base = base.sort_values(["agent_id", "step"], kind="mergesort").reset_index(drop=True)

    grp = base.groupby("agent_id", sort=False)
    prev_exposed = grp["exposed"].shift(1)
    prev_step = grp["step"].shift(1)
    consecutive = prev_step.notna() & (prev_step == base["step"] - 1)
    cur_b = base["exposed"].astype("boolean").fillna(False).astype(bool)
    prev_b = prev_exposed.astype("boolean").fillna(False).astype(bool)
    usable = base["exposed"].notna() & prev_exposed.notna() & consecutive
    x = pd.Series(np.where(usable.to_numpy(),
                           np.where((cur_b & ~prev_b).to_numpy(), 1.0, 0.0),
                           np.nan),
                  index=base.index)
    new_exposure = pd.DataFrame({"step": base["step"],
                                 "agent_id": base["agent_id"],
                                 "x": x})
    new_exposure = new_exposure.loc[new_exposure["x"] == 1.0, ["step", "agent_id"]]

    empty_index = pd.MultiIndex.from_arrays([[], [], []], names=["step", "agent_id", "layer"])

    events = data["events"]
    ev = events.loc[:, ["step", "agent_id", "layer", "state", "after", "event_index"]].copy()
    state_ok = (ev["state"] == "exposed").fillna(False).to_numpy(dtype=bool)
    after_ok = ev["after"].astype("boolean").fillna(False).to_numpy(dtype=bool)
    ids_ok = (ev["step"].notna() & ev["agent_id"].notna() & ev["layer"].notna()).to_numpy(dtype=bool)
    keep = state_ok & after_ok & ids_ok
    ev_kept = ev.loc[keep, ["step", "agent_id", "layer", "event_index"]].copy()
    if ev_kept.empty or new_exposure.empty:
        return pd.Series(dtype="float64", index=empty_index, name="p2_micro_layer_exposure_flag")
    ev_kept["step"] = ev_kept["step"].astype("int64")
    ev_kept["agent_id"] = ev_kept["agent_id"].astype("int64")
    ev_kept = ev_kept.sort_values(["step", "agent_id", "event_index"], kind="mergesort")
    attributed = ev_kept.drop_duplicates(subset=["step", "agent_id"], keep="first")
    attributed = attributed.loc[:, ["step", "agent_id", "layer"]].rename(columns={"layer": "attr_layer"})

    matched = new_exposure.merge(attributed, on=["step", "agent_id"], how="inner")
    if matched.empty:
        return pd.Series(dtype="float64", index=empty_index, name="p2_micro_layer_exposure_flag")
    layer_step = ev_kept.loc[:, ["step", "layer"]].drop_duplicates()
    grid = matched.merge(layer_step, on="step", how="inner")
    grid["value"] = (grid["layer"] == grid["attr_layer"]).astype("float64")
    res = grid.set_index(["step", "agent_id", "layer"])["value"].sort_index()
    res.index = res.index.set_names(["step", "agent_id", "layer"])
    res.name = "p2_micro_layer_exposure_flag"
    return res
