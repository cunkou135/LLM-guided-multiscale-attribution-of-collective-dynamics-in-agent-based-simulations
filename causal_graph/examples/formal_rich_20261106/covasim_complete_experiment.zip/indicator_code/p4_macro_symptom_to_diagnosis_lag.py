import numpy as np
import pandas as pd


def compute_indicator(data, config):
    df = data["agent_states"][["run_id", "agent_id", "step", "diagnosed", "date_symptomatic", "date_diagnosed"]].copy()
    df = df.sort_values(["run_id", "agent_id", "step"], kind="mergesort")
    diag = df["diagnosed"].fillna(False).astype(bool)
    df["diag"] = diag
    prev = df.groupby(["run_id", "agent_id"])["diag"].shift(1)
    had_prev = prev.notna()
    prev_bool = prev.fillna(False).astype(bool)
    isnew = had_prev & df["diag"] & (~prev_bool)
    lag = df["date_diagnosed"] - df["date_symptomatic"]
    valid = isnew & df["date_symptomatic"].notna() & df["date_diagnosed"].notna()
    vals = lag[valid]
    steps = pd.Index(sorted(df["step"].unique()), name="step")
    if len(vals) == 0:
        out = pd.Series(np.nan, index=steps, dtype=float)
    else:
        sub = df.loc[valid, ["step"]].copy()
        sub["lag"] = vals.astype(float).to_numpy()
        grp = sub.groupby("step")["lag"].mean()
        out = grp.reindex(steps)
    out = out.astype(float)
    out.name = "symptom_to_diagnosis_lag"
    return out
