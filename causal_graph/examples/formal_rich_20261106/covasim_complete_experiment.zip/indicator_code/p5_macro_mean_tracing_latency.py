import numpy as np
import pandas as pd


def compute_indicator(data, config):
    cols = ['run_id', 'agent_id', 'step', 'quarantined', 'date_known_contact', 'date_quarantined']
    s = data['agent_states'][cols].dropna(subset=['run_id', 'agent_id', 'step']).copy()
    s['step'] = s['step'].to_numpy(dtype='int64')
    s['quarantined'] = s['quarantined'].fillna(False).astype(bool)
    s['dqc'] = pd.to_numeric(s['date_quarantined'], errors='coerce')
    s['dkc'] = pd.to_numeric(s['date_known_contact'], errors='coerce')
    s = s.sort_values(['run_id', 'agent_id', 'step'])
    g = s.groupby(['run_id', 'agent_id'], sort=False)
    prev_q = g['quarantined'].shift(1)
    prev_step = g['step'].shift(1)
    mask = s['quarantined'] & (prev_q.fillna(True).astype(bool) == False) & (prev_step == s['step'] - 1)
    newq = s.loc[mask.to_numpy()].copy()
    newq['lat'] = newq['dqc'] - newq['dkc']
    newq = newq.dropna(subset=['lat'])
    if newq.empty:
        return pd.Series(dtype='float64', index=pd.Index([], name='step', dtype='int64'), name='value')
    per_run = newq.groupby(['run_id', 'step'])['lat'].mean().reset_index()
    res = per_run.groupby('step')['lat'].mean()
    res.index.names = ['step']
    return res.rename('value')
