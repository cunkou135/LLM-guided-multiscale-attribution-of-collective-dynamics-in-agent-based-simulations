import numpy as np
import pandas as pd


def _empty(names, name):
    return pd.Series(dtype='float64', name=name, index=pd.MultiIndex.from_arrays([[] for _ in names], names=names))


def compute_indicator(data, config):
    ev = data['events'][['run_id', 'agent_id', 'step', 'state', 'after', 'layer']].copy()
    ev = ev.dropna(subset=['run_id', 'step'])
    if ev.empty:
        return _empty(['step', 'run_id', 'layer'], 'layer_exposure_share')
    ev['step'] = ev['step'].astype('int64')
    after_true = ev['after'].fillna(False).astype(bool)
    hit = ev[(ev['state'] == 'exposed') & after_true & ev['layer'].notna()]
    if hit.empty:
        return _empty(['step', 'run_id', 'layer'], 'layer_exposure_share')
    cnt = hit.groupby(['run_id', 'step', 'layer'], sort=True).size().rename('n').reset_index()
    cnt['share'] = cnt['n'].astype('float64') / cnt.groupby(['run_id', 'step'])['n'].transform('sum').astype('float64')
    out = cnt.set_index(['step', 'run_id', 'layer'])['share'].sort_index()
    out.name = 'layer_exposure_share'
    return out
