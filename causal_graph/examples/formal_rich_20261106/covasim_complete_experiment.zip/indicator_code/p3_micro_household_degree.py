def compute_indicator(data, config):
    import pandas as pd
    import numpy as np
    
    contacts = data['contacts']
    agent_states = data['agent_states']
    observed_steps = sorted(agent_states['step'].unique())
    
    layer_steps_edges = {}
    for layer, group in contacts.groupby('layer'):
        if pd.isna(layer):
            continue
        steps_edges = {}
        for step, step_group in group.groupby('step'):
            pairs = set()
            for _, row in step_group.iterrows():
                a = row['agent_id']
                b = row['partner_id']
                if pd.notna(a) and pd.notna(b):
                    pairs.add((min(a,b), max(a,b)))
            steps_edges[step] = pairs
        layer_steps_edges[layer] = steps_edges
    
    layer_mean_overlap = {}
    layer_mean_edges = {}
    for layer, steps_edges in layer_steps_edges.items():
        overlaps = []
        for i in range(1, len(observed_steps)):
            t = observed_steps[i]
            t_prev = observed_steps[i-1]
            A = steps_edges.get(t, set())
            B = steps_edges.get(t_prev, set())
            union = len(A | B)
            if union > 0:
                intersection = len(A & B)
                overlaps.append(intersection / union)
        total_edges = 0
        for t in observed_steps:
            total_edges += len(steps_edges.get(t, set()))
        mean_edges = total_edges / len(observed_steps) if observed_steps else 0
        layer_mean_edges[layer] = mean_edges
        layer_mean_overlap[layer] = np.mean(overlaps) if overlaps else -1
    
    best_layer = None
    best_overlap = -np.inf
    best_edges = -np.inf
    for layer, overlap in layer_mean_overlap.items():
        edges = layer_mean_edges[layer]
        if overlap > best_overlap or (overlap == best_overlap and edges > best_edges):
            best_overlap = overlap
            best_edges = edges
            best_layer = layer
    
    if best_layer is None:
        return pd.DataFrame(columns=['step', 'agent_id', 'value'])
    
    layer_contacts = contacts[contacts['layer'] == best_layer]
    agent_steps = agent_states[['step', 'agent_id']].drop_duplicates()
    
    results = []
    for step in observed_steps:
        sub = layer_contacts[layer_contacts['step'] == step]
        pairs = set()
        for _, row in sub.iterrows():
            a = row['agent_id']
            b = row['partner_id']
            if pd.notna(a) and pd.notna(b):
                pairs.add((min(a,b), max(a,b)))
        agent_degree = {}
        for a, b in pairs:
            agent_degree[a] = agent_degree.get(a, 0) + 1
            agent_degree[b] = agent_degree.get(b, 0) + 1
        step_agents = agent_steps[agent_steps['step'] == step]['agent_id'].unique()
        for agent in step_agents:
            deg = agent_degree.get(agent, 0)
            results.append({'step': step, 'agent_id': agent, 'value': deg})
    
    df = pd.DataFrame(results)
    return df