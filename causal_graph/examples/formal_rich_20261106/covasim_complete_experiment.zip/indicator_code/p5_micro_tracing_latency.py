import numpy as np
import pandas as pd


def compute_indicator(data, config):
    df = data["agent_states"][["run_id", "agent_id", "step", "date_known_contact", "date_quarantined"]].copy()
    df = df.sort_values(["run_id", "agent_id", "step"], kind="mergesort")
    valid = df["date_known_contact"].notna() & df["date_quarantined"].notna()
    v = df.loc[valid, ["run_id", "agent_id", "step", "date_known_contact", "date_quarantined"]].copy()
    v["tau"] = v["date_quarantined"].astype(float) - v["date_known_contact"].astype(float)
    first = v.groupby(["run_id", "agent_id"], as_index=True)["tau"].first()
    out = first.astype(float)
    out.name = "tracing_latency"
    return out
