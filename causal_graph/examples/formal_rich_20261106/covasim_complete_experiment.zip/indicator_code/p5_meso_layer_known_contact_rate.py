import numpy as np
import pandas as pd


def compute_indicator(data, config):
    states = data["agent_states"][["run_id", "agent_id", "step", "known_contact"]].copy()
    states = states.sort_values(["run_id", "agent_id", "step"], kind="mergesort")
    kc = states["known_contact"].fillna(False).astype(bool)
    states["kc"] = kc
    prev = states.groupby(["run_id", "agent_id"])["kc"].shift(1)
    had_prev = prev.notna()
    prev_bool = prev.fillna(False).astype(bool)
    isnew = had_prev & states["kc"] & (~prev_bool)
    trans = states.loc[isnew, ["run_id", "agent_id", "step"]].copy()

    ev = data["events"][["run_id", "agent_id", "step", "state", "after", "before", "layer"]].copy()
    aft = ev["after"].fillna(False).astype(bool)
    bef = ev["before"].fillna(False).astype(bool)
    ev = ev.loc[aft & (~bef), ["run_id", "agent_id", "step", "state", "layer"]].copy()
    if ev["state"].notna().any():
        m = ev["state"].astype(str).str.contains("known_contact", case=False, na=False)
        if m.any():
            ev = ev.loc[m, :].copy()
    ev = ev[["run_id", "agent_id", "step", "layer"]].drop_duplicates(["run_id", "agent_id", "step"])

    merged = trans.merge(ev, on=["run_id", "agent_id", "step"], how="left")
    merged_layer = merged.dropna(subset=["layer"]).copy()
    num = merged_layer.groupby(["run_id", "step", "layer"]).size().rename("num")

    contacts = data["contacts"][["run_id", "agent_id", "partner_id", "layer", "step"]].copy()
    contacts = contacts.dropna(subset=["agent_id", "partner_id", "layer"]).copy()
    a = contacts["agent_id"].to_numpy(dtype="int64")
    b = contacts["partner_id"].to_numpy(dtype="int64")
    contacts["lo"] = np.minimum(a, b)
    contacts["hi"] = np.maximum(a, b)
    edges = contacts.drop_duplicates(["run_id", "step", "layer", "lo", "hi"])
    edge_count = edges.groupby(["run_id", "step", "layer"]).size().rename("N")

    combined = pd.concat([edge_count.astype(float), num.astype(float)], axis=1)
    combined["num"] = combined["num"].fillna(0.0)
    den = combined["N"]
    keep = den > 0
    rate = (combined.loc[keep, "num"] / den.loc[keep]).astype(float)
    rate.name = "known_contact_rate"
    return rate
