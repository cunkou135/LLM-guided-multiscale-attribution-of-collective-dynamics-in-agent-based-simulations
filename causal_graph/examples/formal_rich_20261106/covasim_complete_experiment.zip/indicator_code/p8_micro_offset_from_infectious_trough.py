import numpy as np
import pandas as pd


def _flag_transitions(df, col):
    x = df.dropna(subset=['run_id', 'agent_id', 'step']).copy()
    if x.empty:
        return pd.DataFrame(columns=['run_id', 'agent_id', 'step'])
    x['agent_id'] = x['agent_id'].astype('int64')
    x['step'] = x['step'].astype('int64')
    x[col] = x[col].fillna(False).astype(bool)
    x = x.drop_duplicates(subset=['run_id', 'agent_id', 'step']).sort_values(['run_id', 'agent_id', 'step'])
    prev = x.groupby(['run_id', 'agent_id'], sort=False)[col].shift(1)
    cur = x[col].to_numpy(dtype=bool)
    prev_false = (~prev.fillna(False).astype(bool)).to_numpy()
    mask = cur & prev_false
    return x.loc[mask, ['run_id', 'agent_id', 'step']].reset_index(drop=True)


def _empty_frame(col):
    idx = pd.MultiIndex.from_arrays([[] for _ in range(3)], names=['step', 'run_id', 'agent_id'])
    return pd.DataFrame({col: pd.Series(dtype='float64', index=idx)})


def compute_indicator(data, config):
    ast = data['agent_states']
    base = ast[['run_id', 'agent_id', 'step', 'exposed', 'infectious']].dropna(subset=['run_id', 'agent_id', 'step']).copy()
    if base.empty:
        return _empty_frame('offset_from_infectious_trough')
    tr = _flag_transitions(base, 'exposed')
    if tr.empty:
        return _empty_frame('offset_from_infectious_trough')
    inf_flag = base['infectious'].fillna(False).astype(bool)
    infectious_rows = base.loc[inf_flag, ['run_id', 'step']]
    grid = base[['run_id', 'step']].drop_duplicates().sort_values(['run_id', 'step'])
    cnt = infectious_rows.groupby(['run_id', 'step'], sort=True).size().rename('n').reset_index()
    grid_n = grid.merge(cnt, on=['run_id', 'step'], how='left')
    grid_n['n'] = grid_n['n'].fillna(0).astype('int64')
    trough = grid_n.loc[grid_n.groupby('run_id', sort=True)['n'].idxmin()]
    trough = trough[['run_id', 'step']].rename(columns={'step': 'trough_step'})
    first = tr.groupby(['run_id', 'agent_id'], sort=True)['step'].min().rename('exposure_step').reset_index()
    joined = first.merge(trough, on='run_id', how='inner')
    if joined.empty:
        return _empty_frame('offset_from_infectious_trough')
    joined['offset_from_infectious_trough'] = (joined['exposure_step'].astype('float64') - joined['trough_step'].astype('float64'))
    res = joined.rename(columns={'exposure_step': 'step'})
    out = res.set_index(['step', 'run_id', 'agent_id'])[['offset_from_infectious_trough']].sort_index()
    return out
