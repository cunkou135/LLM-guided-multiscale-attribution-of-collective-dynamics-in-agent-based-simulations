def compute_indicator(data, config):
    import pandas as pd
    import numpy as np

    ag = data['agent_states'].copy()
    ag = ag.dropna(subset=['step'])
    ag['step'] = ag['step'].astype(int)
    has_run = 'run_id' in ag.columns
    if has_run:
        ag = ag.dropna(subset=['run_id'])
    ag['_infectious'] = ag['infectious'].fillna(False).astype(bool)

    rows = []
    if has_run:
        counts = ag.groupby(['run_id', 'step'], sort=True)['_infectious'].sum()
        for rid, sub in counts.groupby(level=0):
            if sub.empty:
                continue
            m = sub.min()
            steps = sub[sub == m].index.get_level_values('step')
            if not len(steps):
                continue
            t = int(steps.min())
            s = sub.droplevel(0).sort_index()
            if t not in s.index:
                continue
            c_t = s.loc[t]
            after = s[s.index > t]
            if c_t <= 0 or after.empty:
                continue
            amp = float(after.max()) / float(c_t)
            if np.isfinite(amp):
                rows.append((rid, t, amp))
    else:
        counts = ag.groupby('step', sort=True)['_infectious'].sum()
        if not counts.empty:
            m = counts.min()
            steps = counts[counts == m].index
            t = int(steps.min())
            if t in counts.index:
                c_t = counts.loc[t]
                after = counts[counts.index > t]
                if c_t > 0 and not after.empty:
                    amp = float(after.max()) / float(c_t)
                    if np.isfinite(amp):
                        rows.append((t, amp))

    if not rows:
        return pd.Series(dtype=float, name='post_trough_resurgence_amplitude')
    if has_run:
        idx = pd.MultiIndex.from_tuples([(r[0], r[1]) for r in rows], names=['run_id', 'step'])
        return pd.Series([r[2] for r in rows], index=idx, name='post_trough_resurgence_amplitude')
    idx = pd.Index([r[0] for r in rows], name='step')
    return pd.Series([r[1] for r in rows], index=idx, name='post_trough_resurgence_amplitude')
