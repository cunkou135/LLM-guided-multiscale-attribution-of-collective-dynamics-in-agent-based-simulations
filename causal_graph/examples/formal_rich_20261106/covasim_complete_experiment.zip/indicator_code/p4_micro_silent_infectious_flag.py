def compute_indicator(data, config):
    import pandas as pd
    
    agent_states = data['agent_states']
    infectious_agents = agent_states[agent_states['infectious'] == True]
    infectious_agents = infectious_agents[infectious_agents['diagnosed'].notna()]
    infectious_agents['value'] = (~infectious_agents['diagnosed']).astype(int)
    
    return infectious_agents[['step', 'agent_id', 'value']]