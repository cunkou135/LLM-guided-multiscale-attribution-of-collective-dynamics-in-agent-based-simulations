def compute_indicator(data, config):
    import numpy as np
    import pandas as pd

    states = data["agent_states"]
    obs = states.loc[states["agent_id"].notna() & states["step"].notna(),
                     ["step", "agent_id"]].copy()
    obs["step"] = obs["step"].astype("int64")
    obs["agent_id"] = obs["agent_id"].astype("int64")
    obs = obs.drop_duplicates()

    contacts = data["contacts"]
    raw = contacts.loc[:, ["step", "layer", "agent_id", "partner_id"]].copy()
    mask = (raw["step"].notna() & raw["layer"].notna()
            & raw["agent_id"].notna() & raw["partner_id"].notna()).to_numpy(dtype=bool)
    edge_rows = raw.loc[mask].copy()
    edge_rows["step"] = edge_rows["step"].astype("int64")
    edge_rows["agent_id"] = edge_rows["agent_id"].astype("int64")
    edge_rows["partner_id"] = edge_rows["partner_id"].astype("int64")
    edge_rows = edge_rows.loc[edge_rows["agent_id"] != edge_rows["partner_id"]]
    lo = np.minimum(edge_rows["agent_id"].to_numpy(), edge_rows["partner_id"].to_numpy())
    hi = np.maximum(edge_rows["agent_id"].to_numpy(), edge_rows["partner_id"].to_numpy())
    undirected = edge_rows.assign(lo=lo, hi=hi).drop_duplicates(subset=["step", "layer", "lo", "hi"])

    endpoints = pd.concat([
        undirected.loc[:, ["step", "layer", "lo"]].rename(columns={"lo": "agent_id"}),
        undirected.loc[:, ["step", "layer", "hi"]].rename(columns={"hi": "agent_id"}),
    ], ignore_index=True)
    degree = endpoints.groupby(["step", "layer", "agent_id"]).size().rename("value")

    layer_step = undirected.loc[:, ["step", "layer"]].drop_duplicates()
    grid = obs.merge(layer_step, on="step", how="inner").set_index(["step", "layer", "agent_id"])
    filled = degree.reindex(grid.index).fillna(0.0)
    frame = filled.reset_index()
    frame.columns = ["step", "layer", "agent_id", "value"]

    if frame.empty:
        return pd.Series(dtype="float64", index=pd.MultiIndex.from_arrays([[], []], names=["step", "layer"]), name="p2_meso_layer_degree_dispersion")

    agg = frame.groupby(["step", "layer"]).agg(
        count=("value", "count"),
        mean=("value", "mean"),
        sd=("value", lambda s: float(np.std(s.to_numpy(dtype="float64"), ddof=0))))
    valid = (agg["count"] >= 2) & (agg["mean"] != 0)
    res = (agg["sd"] / agg["mean"]).where(valid).dropna()
    res.index = res.index.set_names(["step", "layer"])
    res.name = "p2_meso_layer_degree_dispersion"
    return res.sort_index()
