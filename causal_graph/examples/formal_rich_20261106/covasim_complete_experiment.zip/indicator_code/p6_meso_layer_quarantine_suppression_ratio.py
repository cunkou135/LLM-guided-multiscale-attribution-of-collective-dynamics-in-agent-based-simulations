import numpy as np
import pandas as pd


def _undirected_edges(contacts):
    c = contacts[['run_id', 'step', 'layer', 'agent_id', 'partner_id']]
    c = c.dropna(subset=['run_id', 'step', 'layer', 'agent_id', 'partner_id'])
    a = c['agent_id'].to_numpy(dtype='int64')
    b = c['partner_id'].to_numpy(dtype='int64')
    e = pd.DataFrame({
        'run_id': c['run_id'].to_numpy(),
        'step': c['step'].to_numpy(dtype='int64'),
        'layer': c['layer'].to_numpy(),
        'u': np.minimum(a, b),
        'v': np.maximum(a, b),
    })
    return e.drop_duplicates(subset=['run_id', 'step', 'layer', 'u', 'v'])


def _layer_degrees(edges):
    left = edges[['run_id', 'step', 'layer', 'u']].rename(columns={'u': 'agent_id'})
    right = edges[['run_id', 'step', 'layer', 'v']].rename(columns={'v': 'agent_id'})
    stacked = pd.concat([left, right], ignore_index=True)
    d = stacked.groupby(['run_id', 'step', 'layer', 'agent_id']).size().rename('degree')
    return d.reset_index()


def _fill_cols(df, spec):
    out = df.copy()
    for name, value in spec:
        if name not in out.columns:
            out[name] = value
    return out


def compute_indicator(data, config):
    st = data['agent_states'][['run_id', 'step', 'agent_id', 'quarantined']]
    st = st.dropna(subset=['run_id', 'step', 'agent_id']).copy()
    st['step'] = st['step'].to_numpy(dtype='int64')
    st['quarantined'] = st['quarantined'].fillna(False).astype(bool)
    empty_idx = pd.MultiIndex.from_arrays([np.array([], dtype='int64'), np.array([], dtype='object')], names=['step', 'layer'])
    if st.empty:
        return pd.Series(dtype='float64', index=empty_idx, name='value')
    deg = _layer_degrees(_undirected_edges(data['contacts']))
    if deg.empty:
        return pd.Series(dtype='float64', index=empty_idx, name='value')
    joined = deg.merge(st, on=['run_id', 'step', 'agent_id'], how='inner')
    sums = joined.groupby(['run_id', 'step', 'layer', 'quarantined'])['degree'].sum().reset_index()
    piv = sums.pivot_table(index=['run_id', 'step', 'layer'], columns='quarantined', values='degree', aggfunc='sum').reset_index()
    piv = piv.rename(columns={True: 'sum_q', False: 'sum_n'})
    piv = _fill_cols(piv, [('sum_q', 0.0), ('sum_n', 0.0)])
    piv[['sum_q', 'sum_n']] = piv[['sum_q', 'sum_n']].fillna(0.0)
    cnt = st.groupby(['run_id', 'step', 'quarantined']).size().unstack('quarantined').reset_index()
    cnt = cnt.rename(columns={True: 'cnt_q', False: 'cnt_n'})
    cnt = _fill_cols(cnt, [('cnt_q', 0), ('cnt_n', 0)])
    cnt[['cnt_q', 'cnt_n']] = cnt[['cnt_q', 'cnt_n']].fillna(0)
    work = piv.merge(cnt, on=['run_id', 'step'], how='inner')
    work = work[(work['cnt_q'] > 0) & (work['cnt_n'] > 0)].copy()
    if work.empty:
        return pd.Series(dtype='float64', index=empty_idx, name='value')
    work['mean_q'] = work['sum_q'] / work['cnt_q']
    work['mean_n'] = work['sum_n'] / work['cnt_n']
    work = work[work['mean_n'] > 0].copy()
    if work.empty:
        return pd.Series(dtype='float64', index=empty_idx, name='value')
    work['value'] = work['mean_q'] / work['mean_n']
    res = work.groupby(['step', 'layer'])['value'].mean()
    res.index.names = ['step', 'layer']
    return res.rename('value')
