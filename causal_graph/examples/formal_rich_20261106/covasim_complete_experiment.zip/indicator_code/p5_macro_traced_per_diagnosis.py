import numpy as np
import pandas as pd


def _transitions(states, col):
    s = states[['run_id', 'agent_id', 'step', col]]
    s = s.dropna(subset=['run_id', 'agent_id', 'step']).copy()
    s['step'] = s['step'].to_numpy(dtype='int64')
    s['cur'] = s[col].fillna(False).astype(bool)
    s = s.sort_values(['run_id', 'agent_id', 'step'])
    g = s.groupby(['run_id', 'agent_id'], sort=False)
    prev = g['cur'].shift(1)
    prev_step = g['step'].shift(1)
    mask = s['cur'] & (prev.fillna(True).astype(bool) == False) & (prev_step == s['step'] - 1)
    return s.loc[mask.to_numpy(), ['run_id', 'step', 'agent_id']]


def compute_indicator(data, config):
    st = data['agent_states']
    traced = _transitions(st, 'known_contact')
    diag = _transitions(st, 'diagnosed')
    if traced.empty or diag.empty:
        return pd.Series(dtype='float64', index=pd.Index([], name='step', dtype='int64'), name='value')
    tn = traced.groupby(['run_id', 'step']).size().rename('traced').reset_index()
    dn = diag.groupby(['run_id', 'step']).size().rename('diag').reset_index()
    work = tn.merge(dn, on=['run_id', 'step'], how='inner')
    work = work[work['diag'] > 0].copy()
    work['value'] = work['traced'] / work['diag']
    res = work.groupby('step')['value'].mean()
    res.index.names = ['step']
    return res.rename('value')
