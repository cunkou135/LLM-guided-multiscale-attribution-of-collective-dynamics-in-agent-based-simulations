def compute_indicator(data, config):
    import pandas as pd
    import numpy as np

    ag = data['agent_states'].copy()
    for c in ['step', 'agent_id', 'age', 'exposed', 'susceptible', 'infectious']:
        if c not in ag.columns:
            raise KeyError(c)
    ag = ag.dropna(subset=['step', 'agent_id'])
    ag['step'] = ag['step'].astype(int)
    ag['agent_id'] = ag['agent_id'].astype(int)
    has_run = 'run_id' in ag.columns
    if has_run:
        ag = ag.dropna(subset=['run_id'])
    ag['_exposed'] = ag['exposed'].fillna(False).astype(bool)
    ag['_susceptible'] = ag['susceptible'].fillna(False).astype(bool)
    ag['_infectious'] = ag['infectious'].fillna(False).astype(bool)

    if has_run:
        inf_counts = ag.groupby(['run_id', 'step'], sort=True)['_infectious'].sum()
        troughs = {}
        for rid, sub in inf_counts.groupby(level=0):
            if sub.empty:
                continue
            m = sub.min()
            steps = sub[sub == m].index.get_level_values('step')
            if len(steps):
                troughs[rid] = int(steps.min())
    else:
        inf_counts = ag.groupby('step', sort=True)['_infectious'].sum()
        trough = None
        if not inf_counts.empty:
            m = inf_counts.min()
            steps = inf_counts[inf_counts == m].index
            trough = int(steps.min())

    bands = config.get('age_bands', [[0, 18], [18, 40], [40, 65], [65, 120]])

    def _band_label(age):
        if pd.isna(age):
            return None
        for lo, hi in bands:
            if age >= lo and age < hi:
                return f'{lo}-{hi}'
        return None

    ag['_band'] = ag['age'].apply(_band_label)

    sus = ag[ag['_susceptible']].copy()
    if has_run:
        s_counts = sus.groupby(['run_id', 'step', '_band'], sort=True).size()
        s_df = s_counts.rename('S').reset_index()
        s_df = s_df.sort_values(['run_id', '_band', 'step'])
        s_df['S_prev'] = s_df.groupby(['run_id', '_band'], sort=False)['S'].shift(1)
        s_prev = s_df.set_index(['run_id', 'step', '_band'])['S_prev']
    else:
        s_counts = sus.groupby(['step', '_band'], sort=True).size()
        s_df = s_counts.rename('S').reset_index()
        s_df = s_df.sort_values(['_band', 'step'])
        s_df['S_prev'] = s_df.groupby('_band', sort=False)['S'].shift(1)
        s_prev = s_df.set_index(['step', '_band'])['S_prev']

    group_cols = ['run_id', 'agent_id'] if has_run else ['agent_id']
    ag = ag.sort_values(group_cols + ['step'])
    ag['_prev_exposed'] = ag.groupby(group_cols, sort=False)['_exposed'].shift(1)
    trans = ag[(ag['_prev_exposed'].notna()) & (~ag['_prev_exposed'].astype(bool)) & (ag['_exposed'])].copy()
    trans = trans.dropna(subset=['_band'])
    if has_run:
        e_counts = trans.groupby(['run_id', 'step', '_band'], sort=True).size()
    else:
        e_counts = trans.groupby(['step', '_band'], sort=True).size()
    e_df = e_counts.rename('E').reset_index()

    if has_run:
        h_df = e_df.join(s_prev, on=['run_id', 'step', '_band'], how='left')
    else:
        h_df = e_df.join(s_prev, on=['step', '_band'], how='left')
    h_df['h'] = h_df['E'] / h_df['S_prev']
    h_df = h_df.replace([np.inf, -np.inf], np.nan).dropna(subset=['h'])

    rows = []
    if has_run:
        for (rid, band), sub in h_df.groupby(['run_id', '_band'], sort=True):
            t = troughs.get(rid)
            if t is None:
                continue
            s = sub.set_index('step')['h'].sort_index()
            if t not in s.index:
                continue
            val_t = s.loc[t]
            if not np.isfinite(val_t) or val_t <= 0:
                continue
            after = s[s.index > t]
            after = after[np.isfinite(after)]
            if after.empty:
                continue
            psi = float(after.mean() / val_t)
            if np.isfinite(psi):
                rows.append((rid, t, band, psi))
    else:
        if trough is not None:
            for band, sub in h_df.groupby('_band', sort=True):
                s = sub.set_index('step')['h'].sort_index()
                if trough not in s.index:
                    continue
                val_t = s.loc[trough]
                if not np.isfinite(val_t) or val_t <= 0:
                    continue
                after = s[s.index > trough]
                after = after[np.isfinite(after)]
                if after.empty:
                    continue
                psi = float(after.mean() / val_t)
                if np.isfinite(psi):
                    rows.append((trough, band, psi))

    if not rows:
        return pd.Series(dtype=float, name='post_trough_band_incidence_ratio')
    if has_run:
        idx = pd.MultiIndex.from_tuples([(r[0], r[1], r[2]) for r in rows], names=['run_id', 'step', 'band'])
        return pd.Series([r[3] for r in rows], index=idx, name='post_trough_band_incidence_ratio')
    idx = pd.MultiIndex.from_tuples([(r[0], r[1]) for r in rows], names=['step', 'band'])
    return pd.Series([r[2] for r in rows], index=idx, name='post_trough_band_incidence_ratio')
