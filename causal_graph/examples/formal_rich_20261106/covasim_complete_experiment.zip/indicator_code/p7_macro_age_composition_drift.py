import numpy as np
import pandas as pd


def _flag_transitions(df, col):
    x = df.dropna(subset=['run_id', 'agent_id', 'step']).copy()
    if x.empty:
        return pd.DataFrame(columns=['run_id', 'agent_id', 'step'])
    x['agent_id'] = x['agent_id'].astype('int64')
    x['step'] = x['step'].astype('int64')
    x[col] = x[col].fillna(False).astype(bool)
    x = x.drop_duplicates(subset=['run_id', 'agent_id', 'step']).sort_values(['run_id', 'agent_id', 'step'])
    prev = x.groupby(['run_id', 'agent_id'], sort=False)[col].shift(1)
    cur = x[col].to_numpy(dtype=bool)
    prev_false = (~prev.fillna(False).astype(bool)).to_numpy()
    mask = cur & prev_false
    return x.loc[mask, ['run_id', 'agent_id', 'step']].reset_index(drop=True)


def _band_labels(ast):
    ag = ast[['run_id', 'agent_id', 'step', 'age']].dropna(subset=['run_id', 'agent_id', 'step', 'age']).copy()
    if ag.empty:
        return pd.DataFrame(columns=['run_id', 'agent_id', 'band'])
    ag['agent_id'] = ag['agent_id'].astype('int64')
    ag['step'] = ag['step'].astype('int64')
    ag = ag.sort_values(['run_id', 'agent_id', 'step']).drop_duplicates(subset=['run_id', 'agent_id'])
    parts = []
    for rid, sub in ag.groupby('run_id', sort=True):
        vals = sub['age'].to_numpy(dtype='float64')
        edges = np.quantile(vals, [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9])
        bands = np.searchsorted(edges, vals, side='right').astype('int64')
        parts.append(pd.DataFrame({'run_id': rid, 'agent_id': sub['agent_id'].to_numpy(), 'band': bands}))
    if not parts:
        return pd.DataFrame(columns=['run_id', 'agent_id', 'band'])
    return pd.concat(parts, ignore_index=True)


def _empty(names, name):
    return pd.Series(dtype='float64', name=name, index=pd.MultiIndex.from_arrays([[] for _ in names], names=names))


def compute_indicator(data, config):
    ast = data['agent_states']
    tr = _flag_transitions(ast[['run_id', 'agent_id', 'step', 'exposed']], 'exposed')
    if tr.empty:
        return _empty(['step', 'run_id'], 'age_composition_drift')
    bands = _band_labels(ast)
    if bands.empty:
        return _empty(['step', 'run_id'], 'age_composition_drift')
    tagged = tr.merge(bands, on=['run_id', 'agent_id'], how='inner')
    if tagged.empty:
        return _empty(['step', 'run_id'], 'age_composition_drift')
    cnt = tagged.groupby(['run_id', 'step', 'band'], sort=True).size().rename('n').reset_index()
    wide = cnt.pivot_table(index=['run_id', 'step'], columns='band', values='n', aggfunc='sum', fill_value=0)
    shares = wide.div(wide.sum(axis=1), axis=0)
    rows = []
    for rid, sub in shares.groupby(level='run_id', sort=True):
        sub2 = sub.droplevel('run_id')
        t0 = sub2.index.min()
        ref = sub2.loc[t0]
        for t in sub2.index:
            cur = sub2.loc[t]
            rows.append((int(t), rid, 0.5 * float(np.abs(cur - ref).sum())))
    if not rows:
        return _empty(['step', 'run_id'], 'age_composition_drift')
    res = pd.DataFrame(rows, columns=['step', 'run_id', 'value'])
    out = res.set_index(['step', 'run_id'])['value'].sort_index()
    out.name = 'age_composition_drift'
    return out
