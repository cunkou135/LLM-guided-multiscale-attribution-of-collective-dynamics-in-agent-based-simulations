def compute_indicator(data, config):
    import pandas as pd
    import numpy as np

    ag = data['agent_states'].copy()
    ag = ag.dropna(subset=['step'])
    ag['step'] = ag['step'].astype(int)
    has_run = 'run_id' in ag.columns
    if has_run:
        ag = ag.dropna(subset=['run_id'])
    ag['_infectious'] = ag['infectious'].fillna(False).astype(bool)

    rows = []
    if has_run:
        counts = ag.groupby(['run_id', 'step'], sort=True)['_infectious'].sum()
        for rid, sub in counts.groupby(level=0):
            if sub.empty:
                continue
            m = sub.min()
            steps = sub[sub == m].index.get_level_values('step')
            if not len(steps):
                continue
            t = int(steps.min())
            s = sub.droplevel(0).sort_index()
            vals = []
            idx = s.index.to_list()
            for i in range(1, len(idx)):
                s0, s1 = idx[i - 1], idx[i]
                if s1 <= t:
                    continue
                c0, c1 = s.loc[s0], s.loc[s1]
                if c0 > 0 and c1 > 0:
                    vals.append(np.log(float(c1) / float(c0)))
            if vals:
                rows.append((rid, t, float(np.mean(vals))))
    else:
        counts = ag.groupby('step', sort=True)['_infectious'].sum()
        if not counts.empty:
            m = counts.min()
            steps = counts[counts == m].index
            t = int(steps.min())
            vals = []
            idx = counts.index.to_list()
            for i in range(1, len(idx)):
                s0, s1 = idx[i - 1], idx[i]
                if s1 <= t:
                    continue
                c0, c1 = counts.loc[s0], counts.loc[s1]
                if c0 > 0 and c1 > 0:
                    vals.append(np.log(float(c1) / float(c0)))
            if vals:
                rows.append((t, float(np.mean(vals))))

    if not rows:
        return pd.Series(dtype=float, name='post_trough_infectious_growth')
    if has_run:
        idx = pd.MultiIndex.from_tuples([(r[0], r[1]) for r in rows], names=['run_id', 'step'])
        return pd.Series([r[2] for r in rows], index=idx, name='post_trough_infectious_growth')
    idx = pd.Index([r[0] for r in rows], name='step')
    return pd.Series([r[1] for r in rows], index=idx, name='post_trough_infectious_growth')
