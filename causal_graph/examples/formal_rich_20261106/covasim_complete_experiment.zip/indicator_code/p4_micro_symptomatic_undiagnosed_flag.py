import numpy as np
import pandas as pd


def compute_indicator(data, config):
    df = data["agent_states"][["run_id", "agent_id", "step", "symptomatic", "diagnosed"]].copy()
    symp = df["symptomatic"].fillna(False).astype(bool)
    diag = df["diagnosed"].fillna(False).astype(bool)
    val = np.where(symp, np.where(diag, 0.0, 1.0), np.nan)
    df["flag"] = val
    out = df.set_index(["run_id", "step", "agent_id"])["flag"].astype(float)
    out.name = "symptomatic_undiagnosed_flag"
    return out
