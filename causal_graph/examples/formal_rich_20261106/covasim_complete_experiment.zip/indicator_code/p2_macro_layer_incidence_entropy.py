def compute_indicator(data, config):
    import pandas as pd
    import numpy as np
    
    events = data['events']
    agent_states = data['agent_states']
    observed_steps = sorted(agent_states['step'].unique())
    
    exp_events = events[(events['state'] == 'exposed') & (events['after'] == True) & events['layer'].notna()]
    step_layer_counts = exp_events.groupby(['step', 'layer']).size().reset_index(name='count')
    
    results = []
    for step in observed_steps:
        group = step_layer_counts[step_layer_counts['step'] == step]
        if group.empty:
            continue
        counts = group['count'].values
        total = counts.sum()
        if total == 0:
            continue
        p = counts / total
        n = len(counts[counts > 0])
        if n < 2:
            continue
        H = -np.sum(p * np.log(p)) / np.log(n)
        results.append({'step': step, 'value': H})
    
    df = pd.DataFrame(results)
    return df