import numpy as np
import pandas as pd


def compute_indicator(data, config):
    df = data["agent_states"][["run_id", "agent_id", "step", "infectious", "diagnosed", "quarantined"]].copy()
    inj = df["infectious"].fillna(False).astype(bool)
    diag = df["diagnosed"].fillna(False).astype(bool)
    df["inj"] = inj.astype(int)
    df["Z"] = (inj & (~diag)).astype(int)
    df["group_id"] = df["quarantined"].fillna(False).astype(bool)
    g = df.groupby(["run_id", "step", "group_id"])
    zsum = g["Z"].sum()
    isum = g["inj"].sum()
    share = zsum / isum.where(isum > 0, np.nan)
    share = share.astype(float)
    share.name = "silent_share"
    return share
