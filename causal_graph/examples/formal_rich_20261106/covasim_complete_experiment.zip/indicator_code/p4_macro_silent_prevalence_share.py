import numpy as np
import pandas as pd


def compute_indicator(data, config):
    df = data["agent_states"][["run_id", "agent_id", "step", "infectious", "diagnosed"]].copy()
    inj = df["infectious"].fillna(False).astype(bool)
    diag = df["diagnosed"].fillna(False).astype(bool)
    df["inj"] = inj.astype(int)
    df["Z"] = (inj & (~diag)).astype(int)
    g = df.groupby("step")
    zsum = g["Z"].sum()
    isum = g["inj"].sum()
    share = zsum / isum.where(isum > 0, np.nan)
    share = share.astype(float)
    share.name = "silent_prevalence_share"
    return share
