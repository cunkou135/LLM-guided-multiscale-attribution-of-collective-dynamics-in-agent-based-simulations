def compute_indicator(data, config):
    import numpy as np
    import pandas as pd

    states = data["agent_states"]
    base = states.loc[states["agent_id"].notna() & states["step"].notna(),
                      ["step", "agent_id", "age", "exposed"]].copy()
    base["step"] = base["step"].astype("int64")
    base["agent_id"] = base["agent_id"].astype("int64")
    base = base.drop_duplicates(subset=["step", "agent_id"], keep="last")
    base = base.sort_values(["agent_id", "step"], kind="mergesort").reset_index(drop=True)

    grp = base.groupby("agent_id", sort=False)
    prev_exposed = grp["exposed"].shift(1)
    prev_step = grp["step"].shift(1)
    consecutive = prev_step.notna() & (prev_step == base["step"] - 1)
    cur_b = base["exposed"].astype("boolean").fillna(False).astype(bool)
    prev_b = prev_exposed.astype("boolean").fillna(False).astype(bool)
    usable = base["exposed"].notna() & prev_exposed.notna() & consecutive
    x = pd.Series(np.where(usable.to_numpy(),
                           np.where((cur_b & ~prev_b).to_numpy(), 1.0, 0.0),
                           np.nan),
                  index=base.index)
    ever = x.groupby(base["agent_id"]).cummax().fillna(0.0)

    age_vals = base.loc[base["age"].notna(), "age"].astype("float64")
    if age_vals.empty:
        return pd.Series(dtype="float64", index=pd.MultiIndex.from_arrays([[], []], names=["step", "band"]), name="p1_meso_band_attack_ratio")
    edges = np.unique(np.quantile(age_vals.to_numpy(dtype="float64"), np.linspace(0.1, 0.9, 9)))
    agent_age = base.loc[base["age"].notna()].groupby("agent_id")["age"].first().astype("float64")

    def band_of(v):
        if v is None:
            return None
        fv = float(v)
        if np.isnan(fv):
            return None
        return int(np.searchsorted(edges, fv, side="right"))

    band_map = agent_age.map(band_of)

    work = pd.DataFrame({"step": base["step"],
                         "agent_id": base["agent_id"],
                         "ever": ever})
    work["band"] = base["agent_id"].map(band_map)
    work = work.loc[work["band"].notna()].copy()
    work["band"] = work["band"].astype("int64")

    num = work.groupby(["step", "band"])["ever"].sum(min_count=1)

    agents = work.groupby("agent_id").agg(band=("band", "first"),
                                           first_step=("step", "min")).reset_index()
    steps = np.sort(work["step"].unique())
    pieces = []
    for b, sub in agents.groupby("band"):
        fs = np.sort(sub["first_step"].to_numpy(dtype="int64"))
        cnt = np.searchsorted(fs, steps, side="right").astype("float64")
        pieces.append(pd.DataFrame({"step": steps, "band": np.int64(b), "count": cnt}))
    if not pieces:
        return pd.Series(dtype="float64", index=pd.MultiIndex.from_arrays([[], []], names=["step", "band"]), name="p1_meso_band_attack_ratio")
    den = pd.concat(pieces, ignore_index=True).set_index(["step", "band"])["count"]

    table = pd.concat([num.rename("num"), den.rename("den")], axis=1, join="inner").dropna()
    table = table.loc[table["den"].to_numpy() > 0]
    res = (table["num"] / table["den"]).sort_index()
    res.index = res.index.set_names(["step", "band"])
    res.name = "p1_meso_band_attack_ratio"
    return res
