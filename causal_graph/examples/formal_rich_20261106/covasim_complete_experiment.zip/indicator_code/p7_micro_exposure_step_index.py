import numpy as np
import pandas as pd


def _flag_transitions(df, col):
    x = df.dropna(subset=['run_id', 'agent_id', 'step']).copy()
    if x.empty:
        return pd.DataFrame(columns=['run_id', 'agent_id', 'step'])
    x['agent_id'] = x['agent_id'].astype('int64')
    x['step'] = x['step'].astype('int64')
    x[col] = x[col].fillna(False).astype(bool)
    x = x.drop_duplicates(subset=['run_id', 'agent_id', 'step']).sort_values(['run_id', 'agent_id', 'step'])
    prev = x.groupby(['run_id', 'agent_id'], sort=False)[col].shift(1)
    cur = x[col].to_numpy(dtype=bool)
    prev_false = (~prev.fillna(False).astype(bool)).to_numpy()
    mask = cur & prev_false
    return x.loc[mask, ['run_id', 'agent_id', 'step']].reset_index(drop=True)


def _empty_frame(col):
    idx = pd.MultiIndex.from_arrays([[] for _ in range(3)], names=['step', 'run_id', 'agent_id'])
    return pd.DataFrame({col: pd.Series(dtype='float64', index=idx)})


def compute_indicator(data, config):
    ast = data['agent_states']
    tr = _flag_transitions(ast[['run_id', 'agent_id', 'step', 'exposed']], 'exposed')
    if tr.empty:
        return _empty_frame('exposure_step_index')
    first = tr.groupby(['run_id', 'agent_id'], sort=True)['step'].min().rename('exposure_step_index').reset_index()
    first['exposure_step_index'] = first['exposure_step_index'].astype('float64')
    out = first.set_index(['step', 'run_id', 'agent_id'])[['exposure_step_index']].sort_index()
    return out
