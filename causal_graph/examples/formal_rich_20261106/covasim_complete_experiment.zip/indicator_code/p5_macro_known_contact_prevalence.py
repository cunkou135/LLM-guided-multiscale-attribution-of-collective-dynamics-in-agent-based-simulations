import numpy as np
import pandas as pd


def compute_indicator(data, config):
    s = data['agent_states'][['run_id', 'step', 'known_contact']].dropna(subset=['run_id', 'step']).copy()
    s['step'] = s['step'].to_numpy(dtype='int64')
    s['known_contact'] = s['known_contact'].fillna(False).astype(bool)
    if s.empty:
        return pd.Series(dtype='float64', index=pd.Index([], name='step', dtype='int64'), name='value')
    per_run = s.groupby(['run_id', 'step'])['known_contact'].mean().reset_index()
    res = per_run.groupby('step')['known_contact'].mean()
    res.index.names = ['step']
    return res.rename('value')
