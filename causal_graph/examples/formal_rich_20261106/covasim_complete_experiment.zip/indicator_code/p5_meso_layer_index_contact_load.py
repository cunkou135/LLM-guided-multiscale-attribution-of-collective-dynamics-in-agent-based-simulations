import numpy as np
import pandas as pd


def _undirected_edges(contacts):
    c = contacts[['run_id', 'step', 'layer', 'agent_id', 'partner_id']]
    c = c.dropna(subset=['run_id', 'step', 'layer', 'agent_id', 'partner_id'])
    a = c['agent_id'].to_numpy(dtype='int64')
    b = c['partner_id'].to_numpy(dtype='int64')
    e = pd.DataFrame({
        'run_id': c['run_id'].to_numpy(),
        'step': c['step'].to_numpy(dtype='int64'),
        'layer': c['layer'].to_numpy(),
        'u': np.minimum(a, b),
        'v': np.maximum(a, b),
    })
    return e.drop_duplicates(subset=['run_id', 'step', 'layer', 'u', 'v'])


def _layer_degrees(edges):
    left = edges[['run_id', 'step', 'layer', 'u']].rename(columns={'u': 'agent_id'})
    right = edges[['run_id', 'step', 'layer', 'v']].rename(columns={'v': 'agent_id'})
    stacked = pd.concat([left, right], ignore_index=True)
    d = stacked.groupby(['run_id', 'step', 'layer', 'agent_id']).size().rename('degree')
    return d.reset_index()


def _newly_quarantined(states):
    s = states[['run_id', 'agent_id', 'step', 'quarantined']]
    s = s.dropna(subset=['run_id', 'agent_id', 'step']).copy()
    s['step'] = s['step'].to_numpy(dtype='int64')
    s['quarantined'] = s['quarantined'].fillna(False).astype(bool)
    s = s.sort_values(['run_id', 'agent_id', 'step'])
    g = s.groupby(['run_id', 'agent_id'], sort=False)
    prev_q = g['quarantined'].shift(1)
    prev_step = g['step'].shift(1)
    mask = s['quarantined'] & (prev_q.fillna(True).astype(bool) == False) & (prev_step == s['step'] - 1)
    return s.loc[mask.to_numpy()].reset_index(drop=True)


def compute_indicator(data, config):
    newq = _newly_quarantined(data['agent_states'])[['run_id', 'step', 'agent_id']]
    deg = _layer_degrees(_undirected_edges(data['contacts']))
    if newq.empty or deg.empty:
        idx = pd.MultiIndex.from_arrays([np.array([], dtype='int64'), np.array([], dtype='object')], names=['step', 'layer'])
        return pd.Series(dtype='float64', index=idx, name='value')
    layers = deg[['run_id', 'step', 'layer']].drop_duplicates()
    den = newq.groupby(['run_id', 'step']).size().rename('den').reset_index()
    sub = deg.merge(newq, on=['run_id', 'step', 'agent_id'], how='inner')
    num = sub.groupby(['run_id', 'step', 'layer'])['degree'].sum().rename('num').reset_index()
    work = layers.merge(num, on=['run_id', 'step', 'layer'], how='left')
    work['num'] = work['num'].fillna(0.0)
    work = work.merge(den, on=['run_id', 'step'], how='inner')
    work = work[work['den'] > 0].copy()
    work['value'] = work['num'] / work['den']
    res = work.groupby(['step', 'layer'])['value'].mean()
    res.index.names = ['step', 'layer']
    return res.rename('value')
