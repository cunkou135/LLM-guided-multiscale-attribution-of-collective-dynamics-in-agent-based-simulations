import numpy as np
import pandas as pd


def compute_indicator(data, config):
    df = data["agent_states"][["run_id", "agent_id", "step", "diagnosed", "infectious"]].copy()
    df = df.sort_values(["run_id", "agent_id", "step"], kind="mergesort")
    diag = df["diagnosed"].fillna(False).astype(bool)
    inj = df["infectious"].fillna(False).astype(bool)
    df["diag"] = diag
    df["inj"] = inj.astype(int)
    prev = df.groupby(["run_id", "agent_id"])["diag"].shift(1)
    had_prev = prev.notna()
    prev_bool = prev.fillna(False).astype(bool)
    df["isnew"] = (had_prev & df["diag"] & (~prev_bool)).astype(float)
    num = df.groupby("step")["isnew"].sum()
    den = df.groupby("step")["inj"].sum()
    rate = num / den.where(den > 0, np.nan)
    rate = rate.astype(float)
    rate.name = "detection_coverage_rate"
    return rate
