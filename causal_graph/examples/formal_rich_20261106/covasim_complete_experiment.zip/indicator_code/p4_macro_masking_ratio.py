import numpy as np
import pandas as pd


def compute_indicator(data, config):
    df = data["agent_states"][["run_id", "agent_id", "step", "exposed", "diagnosed"]].copy()
    df = df.sort_values(["run_id", "agent_id", "step"], kind="mergesort")
    exp = df["exposed"].fillna(False).astype(bool)
    diag = df["diagnosed"].fillna(False).astype(bool)
    df["exp"] = exp
    df["diag"] = diag
    df["Eever"] = df.groupby(["run_id", "agent_id"])["exp"].cummax().astype(bool)
    df["Dever"] = df.groupby(["run_id", "agent_id"])["diag"].cummax().astype(bool)
    df["num"] = (df["Eever"] & (~df["Dever"])).astype(int)
    df["den"] = (df["Eever"] & df["Dever"]).astype(int)
    g = df.groupby("step")
    nsum = g["num"].sum()
    dsum = g["den"].sum()
    ratio = nsum / dsum.where(dsum > 0, np.nan)
    ratio = ratio.astype(float)
    ratio.name = "masking_ratio"
    return ratio
