def compute_indicator(data, config):
    import pandas as pd
    import numpy as np
    
    contacts = data['contacts']
    agent_states = data['agent_states']
    observed_steps = sorted(agent_states['step'].unique())
    
    layer_steps_edges = {}
    for layer, group in contacts.groupby('layer'):
        if pd.isna(layer):
            continue
        steps_edges = {}
        for step, step_group in group.groupby('step'):
            pairs = set()
            for _, row in step_group.iterrows():
                a = row['agent_id']
                b = row['partner_id']
                if pd.notna(a) and pd.notna(b):
                    pairs.add((min(a,b), max(a,b)))
            steps_edges[step] = pairs
        layer_steps_edges[layer] = steps_edges
    
    results = []
    for layer, steps_edges in layer_steps_edges.items():
        for i in range(1, len(observed_steps)):
            t = observed_steps[i]
            t_prev = observed_steps[i-1]
            A = steps_edges.get(t, set())
            B = steps_edges.get(t_prev, set())
            union = len(A | B)
            if union == 0:
                continue
            intersection = len(A & B)
            J = 1 - intersection / union
            results.append({'step': t, 'layer': layer, 'value': J})
    
    df = pd.DataFrame(results)
    return df