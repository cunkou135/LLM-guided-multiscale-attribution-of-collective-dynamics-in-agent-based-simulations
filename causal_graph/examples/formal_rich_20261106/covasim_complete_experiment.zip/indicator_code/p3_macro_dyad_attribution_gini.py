def compute_indicator(data, config):
    import pandas as pd
    import numpy as np
    
    contacts = data['contacts']
    events = data['events']
    agent_states = data['agent_states']
    observed_steps = sorted(agent_states['step'].unique())
    
    layer_steps_edges = {}
    for layer, group in contacts.groupby('layer'):
        if pd.isna(layer):
            continue
        steps_edges = {}
        for step, step_group in group.groupby('step'):
            pairs = set()
            for _, row in step_group.iterrows():
                a = row['agent_id']
                b = row['partner_id']
                if pd.notna(a) and pd.notna(b):
                    pairs.add((min(a,b), max(a,b)))
            steps_edges[step] = pairs
        layer_steps_edges[layer] = steps_edges
    
    layer_mean_overlap = {}
    layer_mean_edges = {}
    for layer, steps_edges in layer_steps_edges.items():
        overlaps = []
        for i in range(1, len(observed_steps)):
            t = observed_steps[i]
            t_prev = observed_steps[i-1]
            A = steps_edges.get(t, set())
            B = steps_edges.get(t_prev, set())
            union = len(A | B)
            if union > 0:
                intersection = len(A & B)
                overlaps.append(intersection / union)
        total_edges = 0
        for t in observed_steps:
            total_edges += len(steps_edges.get(t, set()))
        mean_edges = total_edges / len(observed_steps) if observed_steps else 0
        layer_mean_edges[layer] = mean_edges
        layer_mean_overlap[layer] = np.mean(overlaps) if overlaps else -1
    
    best_layer = None
    best_overlap = -np.inf
    best_edges = -np.inf
    for layer, overlap in layer_mean_overlap.items():
        edges = layer_mean_edges[layer]
        if overlap > best_overlap or (overlap == best_overlap and edges > best_edges):
            best_overlap = overlap
            best_edges = edges
            best_layer = layer
    
    if best_layer is None:
        return pd.DataFrame(columns=['step', 'value'])
    
    layer_contacts = contacts[contacts['layer'] == best_layer]
    exp_events = events[(events['state'] == 'exposed') & (events['after'] == True) & events['partner_id'].notna()]
    
    step_dyads = {}
    for step in observed_steps:
        sub = layer_contacts[layer_contacts['step'] == step]
        dyads = set()
        for _, row in sub.iterrows():
            a = row['agent_id']
            b = row['partner_id']
            if pd.notna(a) and pd.notna(b):
                dyads.add((min(a,b), max(a,b)))
        step_dyads[step] = dyads
    
    step_event_counts = {}
    for step in observed_steps:
        sub = exp_events[exp_events['step'] == step]
        counts = {}
        for _, row in sub.iterrows():
            a = row['agent_id']
            b = row['partner_id']
            if pd.notna(a) and pd.notna(b):
                dyad = (min(a,b), max(a,b))
                counts[dyad] = counts.get(dyad, 0) + 1
        step_event_counts[step] = counts
    
    results = []
    cumulative_counts = {}
    seen_dyads = set()
    for step in observed_steps:
        seen_dyads.update(step_dyads[step])
        for dyad, count in step_event_counts[step].items():
            cumulative_counts[dyad] = cumulative_counts.get(dyad, 0) + count
        n = len(seen_dyads)
        if n < 2:
            continue
        counts_list = [cumulative_counts.get(dyad, 0) for dyad in seen_dyads]
        mean_count = np.mean(counts_list)
        if mean_count == 0:
            continue
        sorted_counts = np.sort(counts_list)
        sum_x = np.sum(sorted_counts)
        if sum_x == 0:
            continue
        index = np.arange(1, n+1)
        gini = (2 * np.sum(index * sorted_counts)) / (n * sum_x) - (n+1)/n
        results.append({'step': step, 'value': gini})
    
    df = pd.DataFrame(results)
    return df