def compute_indicator(data, config):
    import pandas as pd
    import numpy as np
    
    events = data['events']
    contacts = data['contacts']
    agent_states = data['agent_states']
    observed_steps = sorted(agent_states['step'].unique())
    
    layer_steps_edges = {}
    for layer, group in contacts.groupby('layer'):
        if pd.isna(layer):
            continue
        steps_edges = {}
        for step, step_group in group.groupby('step'):
            pairs = set()
            for _, row in step_group.iterrows():
                a = row['agent_id']
                b = row['partner_id']
                if pd.notna(a) and pd.notna(b):
                    pairs.add((min(a,b), max(a,b)))
            steps_edges[step] = pairs
        layer_steps_edges[layer] = steps_edges
    
    layer_mean_overlap = {}
    layer_mean_edges = {}
    for layer, steps_edges in layer_steps_edges.items():
        overlaps = []
        for i in range(1, len(observed_steps)):
            t = observed_steps[i]
            t_prev = observed_steps[i-1]
            A = steps_edges.get(t, set())
            B = steps_edges.get(t_prev, set())
            union = len(A | B)
            if union > 0:
                intersection = len(A & B)
                overlaps.append(intersection / union)
        total_edges = 0
        for t in observed_steps:
            total_edges += len(steps_edges.get(t, set()))
        mean_edges = total_edges / len(observed_steps) if observed_steps else 0
        layer_mean_edges[layer] = mean_edges
        layer_mean_overlap[layer] = np.mean(overlaps) if overlaps else -1
    
    best_layer = None
    best_overlap = -np.inf
    best_edges = -np.inf
    for layer, overlap in layer_mean_overlap.items():
        edges = layer_mean_edges[layer]
        if overlap > best_overlap or (overlap == best_overlap and edges > best_edges):
            best_overlap = overlap
            best_edges = edges
            best_layer = layer
    
    if best_layer is None:
        return pd.DataFrame(columns=['step', 'value'])
    
    exp_events = events[(events['state'] == 'exposed') & (events['after'] == True)]
    total_per_step = exp_events.groupby('step').size().reset_index(name='total')
    
    hh_events = exp_events[exp_events['partner_id'].notna() & (exp_events['layer'] == best_layer)]
    hh_per_step = hh_events.groupby('step').size().reset_index(name='hh')
    
    merged = total_per_step.merge(hh_per_step, on='step', how='left').fillna(0)
    merged['value'] = merged['hh'] / merged['total']
    merged = merged[merged['total'] > 0]
    
    return merged[['step', 'value']]