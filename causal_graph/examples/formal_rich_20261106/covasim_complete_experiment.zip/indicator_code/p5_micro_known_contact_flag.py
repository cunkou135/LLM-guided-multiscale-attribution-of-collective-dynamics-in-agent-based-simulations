import pandas as pd


def compute_indicator(data, config):
    df = data["agent_states"][["run_id", "agent_id", "step", "known_contact"]].copy()
    df["flag"] = df["known_contact"].fillna(False).astype(bool).astype(float)
    out = df.set_index(["run_id", "step", "agent_id"])["flag"].astype(float)
    out.name = "known_contact_flag"
    return out
