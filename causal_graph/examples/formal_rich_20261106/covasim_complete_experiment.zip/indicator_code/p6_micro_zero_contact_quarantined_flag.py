import numpy as np
import pandas as pd


def _all_layer_edges(contacts):
    c = contacts[['run_id', 'step', 'agent_id', 'partner_id']]
    c = c.dropna(subset=['run_id', 'step', 'agent_id', 'partner_id'])
    a = c['agent_id'].to_numpy(dtype='int64')
    b = c['partner_id'].to_numpy(dtype='int64')
    e = pd.DataFrame({
        'run_id': c['run_id'].to_numpy(),
        'step': c['step'].to_numpy(dtype='int64'),
        'u': np.minimum(a, b),
        'v': np.maximum(a, b),
    })
    return e.drop_duplicates(subset=['run_id', 'step', 'u', 'v'])


def _degrees(edges):
    left = edges[['run_id', 'step', 'u']].rename(columns={'u': 'agent_id'})
    right = edges[['run_id', 'step', 'v']].rename(columns={'v': 'agent_id'})
    stacked = pd.concat([left, right], ignore_index=True)
    d = stacked.groupby(['run_id', 'step', 'agent_id']).size().rename('degree')
    return d.reset_index()


def compute_indicator(data, config):
    st = data['agent_states'][['run_id', 'agent_id', 'step', 'quarantined']]
    st = st.dropna(subset=['run_id', 'agent_id', 'step']).copy()
    st['step'] = st['step'].to_numpy(dtype='int64')
    st['quarantined'] = st['quarantined'].fillna(False).astype(bool)
    empty_idx = pd.MultiIndex.from_arrays(
        [np.array([], dtype='object'), np.array([], dtype='int64'), np.array([], dtype='int64')],
        names=['run_id', 'step', 'agent_id'])
    if st.empty:
        return pd.Series(dtype='float64', index=empty_idx, name='value')
    deg = _degrees(_all_layer_edges(data['contacts']))
    grid = st.merge(deg, on=['run_id', 'step', 'agent_id'], how='left')
    grid['degree'] = grid['degree'].fillna(0.0)
    quar = grid[grid['quarantined']].copy()
    if quar.empty:
        return pd.Series(dtype='float64', index=empty_idx, name='value')
    quar['zero_flag'] = (quar['degree'] == 0).astype(float)
    res = quar.set_index(['run_id', 'step', 'agent_id'])['zero_flag']
    res.index.names = ['run_id', 'step', 'agent_id']
    return res.rename('value')
