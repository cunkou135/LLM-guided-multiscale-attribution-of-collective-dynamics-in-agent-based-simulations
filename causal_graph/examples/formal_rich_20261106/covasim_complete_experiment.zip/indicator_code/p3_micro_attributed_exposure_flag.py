def compute_indicator(data, config):
    import pandas as pd
    
    events = data['events']
    
    exp_events = events[(events['state'] == 'exposed') & (events['after'] == True)]
    grouped = exp_events.groupby(['step', 'agent_id']).agg(
        has_partner=('partner_id', lambda x: x.notna().any())
    ).reset_index()
    
    defined = grouped[grouped['has_partner'] == True]
    result = defined[['step', 'agent_id']].copy()
    result['value'] = 1
    
    return result