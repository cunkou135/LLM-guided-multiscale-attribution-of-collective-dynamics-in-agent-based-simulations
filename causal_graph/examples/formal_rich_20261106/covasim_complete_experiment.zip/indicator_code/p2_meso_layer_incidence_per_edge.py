def compute_indicator(data, config):
    import numpy as np
    import pandas as pd

    states = data["agent_states"]
    base = states.loc[states["agent_id"].notna() & states["step"].notna(),
                      ["step", "agent_id", "exposed"]].copy()
    base["step"] = base["step"].astype("int64")
    base["agent_id"] = base["agent_id"].astype("int64")
    base = base.drop_duplicates(subset=["step", "agent_id"], keep="last")
    base = base.sort_values(["agent_id", "step"], kind="mergesort").reset_index(drop=True)

    grp = base.groupby("agent_id", sort=False)
    prev_exposed = grp["exposed"].shift(1)
    prev_step = grp["step"].shift(1)
    consecutive = prev_step.notna() & (prev_step == base["step"] - 1)
    cur_b = base["exposed"].astype("boolean").fillna(False).astype(bool)
    prev_b = prev_exposed.astype("boolean").fillna(False).astype(bool)
    usable = base["exposed"].notna() & prev_exposed.notna() & consecutive
    x = pd.Series(np.where(usable.to_numpy(),
                           np.where((cur_b & ~prev_b).to_numpy(), 1.0, 0.0),
                           np.nan),
                  index=base.index)
    new_exposure = pd.DataFrame({"step": base["step"],
                                 "agent_id": base["agent_id"],
                                 "x": x})
    new_exposure = new_exposure.loc[new_exposure["x"] == 1.0, ["step", "agent_id"]]

    events = data["events"]
    ev = events.loc[:, ["step", "agent_id", "layer", "state", "after", "event_index"]].copy()
    state_ok = (ev["state"] == "exposed").fillna(False).to_numpy(dtype=bool)
    after_ok = ev["after"].astype("boolean").fillna(False).to_numpy(dtype=bool)
    ids_ok = (ev["step"].notna() & ev["agent_id"].notna() & ev["layer"].notna()).to_numpy(dtype=bool)
    ev_kept = ev.loc[state_ok & after_ok & ids_ok, ["step", "agent_id", "layer", "event_index"]].copy()
    if ev_kept.empty or new_exposure.empty:
        return pd.Series(dtype="float64", index=pd.MultiIndex.from_arrays([[], []], names=["step", "layer"]), name="p2_meso_layer_incidence_per_edge")
    ev_kept["step"] = ev_kept["step"].astype("int64")
    ev_kept["agent_id"] = ev_kept["agent_id"].astype("int64")
    ev_kept = ev_kept.sort_values(["step", "agent_id", "event_index"], kind="mergesort")
    attributed = ev_kept.drop_duplicates(subset=["step", "agent_id"], keep="first")
    attributed = attributed.loc[:, ["step", "agent_id", "layer"]]

    matched = new_exposure.merge(attributed, on=["step", "agent_id"], how="inner")
    if matched.empty:
        return pd.Series(dtype="float64", index=pd.MultiIndex.from_arrays([[], []], names=["step", "layer"]), name="p2_meso_layer_incidence_per_edge")
    numerator = matched.groupby(["step", "layer"]).size().rename("num")

    contacts = data["contacts"]
    raw = contacts.loc[:, ["step", "layer", "agent_id", "partner_id"]].copy()
    mask = (raw["step"].notna() & raw["layer"].notna()
            & raw["agent_id"].notna() & raw["partner_id"].notna()).to_numpy(dtype=bool)
    edge_rows = raw.loc[mask].copy()
    edge_rows["step"] = edge_rows["step"].astype("int64")
    edge_rows["agent_id"] = edge_rows["agent_id"].astype("int64")
    edge_rows["partner_id"] = edge_rows["partner_id"].astype("int64")
    edge_rows = edge_rows.loc[edge_rows["agent_id"] != edge_rows["partner_id"]]
    lo = np.minimum(edge_rows["agent_id"].to_numpy(), edge_rows["partner_id"].to_numpy())
    hi = np.maximum(edge_rows["agent_id"].to_numpy(), edge_rows["partner_id"].to_numpy())
    undirected = edge_rows.assign(lo=lo, hi=hi).drop_duplicates(subset=["step", "layer", "lo", "hi"])
    edges_per_layer = undirected.groupby(["step", "layer"]).size().rename("den")

    table = pd.concat([numerator, edges_per_layer], axis=1, join="outer")
    table["num"] = table["num"].fillna(0.0)
    table = table.loc[table["den"].to_numpy() > 0]
    res = (table["num"] / table["den"]).sort_index()
    res.index = res.index.set_names(["step", "layer"])
    res.name = "p2_meso_layer_incidence_per_edge"
    return res
