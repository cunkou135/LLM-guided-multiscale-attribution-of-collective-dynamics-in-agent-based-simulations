import pandas as pd
import numpy as np

def compute_indicator(data, config):
    agents = data['agent_states'].copy()
    contacts = data['contacts'].copy()
    results = []
    for (run_id, step), edge_group in contacts.groupby(['run_id', 'step']):
        if edge_group.empty:
            continue
        agents_in_step = set(edge_group['agent_id']).union(set(edge_group['partner_id']))
        agent_info = agents[(agents['run_id'] == run_id) & (agents['step'] == step) & (agents['agent_id'].isin(agents_in_step))]
        if agent_info.empty:
            continue
        parent = {}
        def find(a):
            if parent[a] != a:
                parent[a] = find(parent[a])
            return parent[a]
        def union(a, b):
            ra, rb = find(a), find(b)
            if ra != rb:
                parent[rb] = ra
        for a in agents_in_step:
            parent[a] = a
        for _, row in edge_group.iterrows():
            union(row['agent_id'], row['partner_id'])
        comp_dict = {}
        for a in agents_in_step:
            root = find(a)
            comp_dict.setdefault(root, []).append(a)
        for comp_id, comp_agents in comp_dict.items():
            comp_agents_set = set(comp_agents)
            fish_comp = agent_info[agent_info['agent_id'].isin(comp_agents_set) & (agent_info['role'] == 'fish')]
            if fish_comp.empty:
                continue
            n_fish = len(fish_comp)
            n_fright = (fish_comp['fright'] > 0).sum()
            prevalence = n_fright / n_fish if n_fish > 0 else np.nan
            results.append({'run_id': run_id, 'step': step, 'component_id': comp_id, 'value': prevalence})
    if not results:
        return pd.DataFrame(columns=['run_id', 'step', 'component_id', 'value'])
    return pd.DataFrame(results)