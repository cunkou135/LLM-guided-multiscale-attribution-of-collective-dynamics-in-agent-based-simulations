import pandas as pd
import numpy as np

def compute_indicator(data, config):
    states = data['agent_states'][['run_id','step','agent_id','role','x','y']].dropna(subset=['x','y'])
    if states.empty:
        return pd.Series(dtype=float, name='shark_proximity')
    fish = states[states['role']=='fish']
    sharks = states[states['role']=='shark']
    if fish.empty or sharks.empty:
        return pd.Series(dtype=float, name='shark_proximity')
    merged = fish.merge(sharks, on=['run_id','step'], suffixes=('_fish','_shark'))
    merged['dist'] = np.sqrt((merged['x_fish']-merged['x_shark'])**2 + (merged['y_fish']-merged['y_shark'])**2)
    min_dist = merged.groupby(['run_id','step','agent_id_fish'])['dist'].min().reset_index()
    min_dist = min_dist[min_dist['dist'] > 0]
    if min_dist.empty:
        return pd.Series(dtype=float, name='shark_proximity')
    min_dist['proximity'] = 1.0 / min_dist['dist']
    result = pd.Series(min_dist['proximity'].values, index=pd.MultiIndex.from_frame(min_dist[['run_id','step','agent_id_fish']].rename(columns={'agent_id_fish':'agent_id'})), name='shark_proximity')
    return result
