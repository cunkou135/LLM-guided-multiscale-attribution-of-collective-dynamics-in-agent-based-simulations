import pandas as pd
import numpy as np
from collections import defaultdict

def _uf(nodes, edges):
    parent = {n: n for n in nodes}
    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x
    for a, b in edges:
        if a in parent and b in parent:
            ra, rb = find(a), find(b)
            if ra != rb:
                parent[ra] = rb
    return {n: find(n) for n in nodes}

def compute_indicator(data, config):
    ast = data['agent_states'][['run_id', 'step', 'agent_id', 'role', 'x', 'y']]
    con = data['contacts'][['run_id', 'step', 'agent_id', 'partner_id']]
    fish = ast[ast['role'] == 'fish']
    sharks = ast[ast['role'] == 'shark']
    shark_groups = {}
    for k, gg in sharks.groupby(['run_id', 'step']):
        shark_groups[(k[0], int(k[1]))] = gg
    con_groups = {}
    for k, gg in con.groupby(['run_id', 'step']):
        con_groups[(k[0], int(k[1]))] = gg
    rows = []
    for k, g in fish.groupby(['run_id', 'step']):
        run_id = k[0]
        step = int(k[1])
        nodes = g['agent_id'].tolist()
        node_set = set(nodes)
        posx = dict(zip(g['agent_id'].values, g['x'].values))
        posy = dict(zip(g['agent_id'].values, g['y'].values))
        edges = []
        cg = con_groups.get((run_id, step))
        if cg is not None:
            for a, b in zip(cg['agent_id'].values, cg['partner_id'].values):
                if a in node_set and b in node_set and a != b:
                    edges.append((a, b))
        comp = _uf(nodes, edges)
        members = defaultdict(list)
        for a in nodes:
            members[comp[a]].append(a)
        sh = shark_groups.get((run_id, step))
        has_shark = sh is not None and len(sh) > 0
        if has_shark:
            sx = sh['x'].values
            sy = sh['y'].values
        for a in nodes:
            mem = members[comp[a]]
            cx = float(np.mean([posx[m] for m in mem]))
            cy = float(np.mean([posy[m] for m in mem]))
            if not has_shark:
                rows.append((run_id, step, int(a), np.nan))
                continue
            d = float(np.min(np.sqrt((sx - cx) ** 2 + (sy - cy) ** 2)))
            rows.append((run_id, step, int(a), d))
    out = pd.DataFrame(rows, columns=['run_id', 'step', 'agent_id', 'value'])
    out = out.set_index(['run_id', 'step', 'agent_id'])['value']
    return out
