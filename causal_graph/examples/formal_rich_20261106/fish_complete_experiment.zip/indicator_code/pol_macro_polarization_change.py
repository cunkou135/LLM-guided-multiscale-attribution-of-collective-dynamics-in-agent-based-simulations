import pandas as pd
import numpy as np

def compute_indicator(data, config):
    states = data['agent_states'][['run_id','step','agent_id','role','heading']].dropna(subset=['heading'])
    fish = states[states['role']=='fish']
    if fish.empty:
        return pd.Series(dtype=float, name='polarization_change')
    fish['sin_h'] = np.sin(fish['heading'])
    fish['cos_h'] = np.cos(fish['heading'])
    R_df = fish.groupby(['run_id','step']).agg(sum_sin=('sin_h','sum'), sum_cos=('cos_h','sum'), count=('heading','size')).reset_index()
    R_df['R'] = np.sqrt(R_df['sum_sin']**2 + R_df['sum_cos']**2) / R_df['count']
    R_df = R_df.sort_values(['run_id','step'])
    R_df['R_change'] = R_df.groupby('run_id')['R'].diff()
    R_df = R_df.dropna(subset=['R_change'])
    if R_df.empty:
        return pd.Series(dtype=float, name='polarization_change')
    result = pd.Series(R_df['R_change'].values, index=pd.MultiIndex.from_frame(R_df[['run_id','step']]), name='polarization_change')
    return result
