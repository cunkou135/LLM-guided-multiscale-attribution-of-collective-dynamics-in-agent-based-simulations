def compute_indicator(data, config):
    import numpy as np
    import pandas as pd
    import json
    agent_states = data['agent_states']
    events = data['events']
    fish = agent_states[agent_states['role'] == 'fish'][['run_id', 'step', 'x', 'y']].dropna(subset=['x', 'y'])
    esc_rows = []
    for rid, st, dj in zip(events['run_id'].values, events['step'].values, events['decision_json'].values):
        try:
            d = json.loads(dj) if isinstance(dj, str) else None
        except Exception:
            d = None
        ed = d.get('escape_direction') if isinstance(d, dict) else None
        if isinstance(ed, list) and len(ed) == 2:
            try:
                esc_rows.append({'run_id': rid, 'step': int(st), 'ex': float(ed[0]), 'ey': float(ed[1])})
            except Exception:
                pass
    esc = pd.DataFrame(esc_rows, columns=['run_id', 'step', 'ex', 'ey'])
    steps = []
    vals = []
    for (rid, step), grp in fish.groupby(['run_id', 'step'], observed=True):
        step_i = int(step)
        xy = grp[['x', 'y']].values
        if xy.shape[0] < 2:
            steps.append(step_i); vals.append(np.nan); continue
        cov = np.cov(xy, rowvar=False)
        eigs, evecs = np.linalg.eigh(cov)
        order = np.argsort(eigs)[::-1]
        evecs = evecs[:, order]
        u1 = evecs[:, 0]
        if esc.shape[0] == 0:
            val = np.nan
        else:
            sub = esc[(esc['run_id'] == rid) & (esc['step'] == step_i)]
            if sub.shape[0] == 0:
                val = np.nan
            else:
                mx = sub['ex'].mean(); my = sub['ey'].mean()
                nn = np.hypot(mx, my)
                if nn > 0:
                    val = float(abs(u1[0] * (mx / nn) + u1[1] * (my / nn)))
                else:
                    val = np.nan
        steps.append(step_i); vals.append(val)
    return pd.Series(vals, index=pd.Index(steps, name='step'), dtype=float)