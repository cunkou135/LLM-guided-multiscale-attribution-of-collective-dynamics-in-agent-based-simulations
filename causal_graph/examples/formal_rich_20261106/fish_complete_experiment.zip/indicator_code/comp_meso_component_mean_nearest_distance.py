def compute_indicator(data, config):
    import pandas as pd
    import numpy as np
    from collections import defaultdict

    ag = data['agent_states'][['run_id','step','agent_id','role','x','y']].copy()
    ag = ag[ag['role'] == 'fish'].dropna(subset=['agent_id','step','run_id','x','y'])
    if len(ag) == 0:
        return pd.Series([], index=pd.MultiIndex.from_tuples([], names=['run_id','step','component_id']), dtype=float)
    ag['agent_id'] = ag['agent_id'].astype('int64')
    fish_by = {}
    pos_by = {}
    for (r, s), g in ag.groupby(['run_id','step']):
        ids = g['agent_id'].tolist()
        xs = g['x'].tolist()
        ys = g['y'].tolist()
        fish_by[(r, s)] = set(ids)
        pos_by[(r, s)] = {int(i): (float(x), float(y)) for i, x, y in zip(ids, xs, ys)}

    ct = data['contacts'][['run_id','step','agent_id','partner_id']].dropna().copy()
    if len(ct) > 0:
        ct['agent_id'] = ct['agent_id'].astype('int64')
        ct['partner_id'] = ct['partner_id'].astype('int64')
        ct_groups = dict(list(ct.groupby(['run_id','step'])))
    else:
        ct_groups = {}

    rows = []
    for (r, s), fs in fish_by.items():
        sub = ct_groups.get((r, s))
        pos = pos_by.get((r, s), {})
        neigh = defaultdict(set)
        edges = set()
        if sub is not None:
            for u, v in zip(sub['agent_id'].tolist(), sub['partner_id'].tolist()):
                if u in fs and v in fs and u != v:
                    neigh[u].add(v)
                    neigh[v].add(u)
                    edges.add((min(u, v), max(u, v)))
        parent = {n: n for n in fs}
        def find(x):
            while parent[x] != x:
                parent[x] = parent[parent[x]]
                x = parent[x]
            return x
        for u, v in edges:
            ru, rv = find(u), find(v)
            if ru != rv:
                parent[ru] = rv
        comps = defaultdict(set)
        for n in fs:
            comps[find(n)].add(n)
        for root, nodes in comps.items():
            ds = []
            for n in nodes:
                if not neigh[n] or n not in pos:
                    continue
                px, py = pos[n]
                best = None
                for m in neigh[n]:
                    if m not in pos:
                        continue
                    d = float(np.hypot(pos[m][0] - px, pos[m][1] - py))
                    if best is None or d < best:
                        best = d
                if best is not None:
                    ds.append(best)
            if ds:
                rows.append((r, s, int(root), float(np.mean(ds))))
    if not rows:
        return pd.Series([], index=pd.MultiIndex.from_tuples([], names=['run_id','step','component_id']), dtype=float)
    idx = pd.MultiIndex.from_tuples([(r, s, k) for r, s, k, _ in rows], names=['run_id','step','component_id'])
    return pd.Series([v for *_ignored, v in rows], index=idx, dtype=float, name='value')
