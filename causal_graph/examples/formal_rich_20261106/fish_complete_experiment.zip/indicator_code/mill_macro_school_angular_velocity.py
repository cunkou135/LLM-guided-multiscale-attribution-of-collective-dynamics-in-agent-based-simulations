import pandas as pd
import numpy as np

def compute_indicator(data, config):
    ag = data['agent_states']
    fish = ag[ag['role'] == 'fish'].copy()
    if fish.empty:
        return pd.Series(dtype=float, name='value')
    def calc(g):
        x = g['x'].to_numpy(dtype=float)
        y = g['y'].to_numpy(dtype=float)
        vx = g['vx'].to_numpy(dtype=float)
        vy = g['vy'].to_numpy(dtype=float)
        N = len(g)
        if N == 0:
            return np.nan
        if np.any(np.isnan(x)) or np.any(np.isnan(y)) or np.any(np.isnan(vx)) or np.any(np.isnan(vy)):
            return np.nan
        cx = x.mean()
        cy = y.mean()
        rx = x - cx
        ry = y - cy
        r2 = rx*rx + ry*ry
        if np.any(r2 == 0):
            return np.nan
        cross = rx*vy - ry*vx
        vals = cross / r2
        return vals.mean()
    res = fish.groupby(['run_id','step'], sort=False).apply(calc)
    res.name = 'value'
    return res
