import pandas as pd
import numpy as np

def compute_indicator(data, config):
    agents = data['agent_states'].copy()
    contacts = data['contacts'].copy()
    results = []
    for (run_id, step), edge_group in contacts.groupby(['run_id', 'step']):
        if edge_group.empty:
            continue
        agents_in_step = set(edge_group['agent_id']).union(set(edge_group['partner_id']))
        agent_info = agents[(agents['run_id'] == run_id) & (agents['step'] == step) & (agents['agent_id'].isin(agents_in_step))]
        if agent_info.empty:
            continue
        parent = {}
        def find(a):
            if parent[a] != a:
                parent[a] = find(parent[a])
            return parent[a]
        def union(a, b):
            ra, rb = find(a), find(b)
            if ra != rb:
                parent[rb] = ra
        for a in agents_in_step:
            parent[a] = a
        for _, row in edge_group.iterrows():
            union(row['agent_id'], row['partner_id'])
        comp_dict = {}
        for a in agents_in_step:
            root = find(a)
            comp_dict.setdefault(root, []).append(a)
        fright_dict = dict(zip(agent_info['agent_id'], agent_info['fright']))
        for comp_id, comp_agents in comp_dict.items():
            comp_agents_set = set(comp_agents)
            comp_edges = edge_group[edge_group['agent_id'].isin(comp_agents_set) & edge_group['partner_id'].isin(comp_agents_set)]
            n_edges = len(comp_edges)
            if n_edges == 0:
                continue
            n_fright_edges = 0
            for _, row in comp_edges.iterrows():
                a, b = row['agent_id'], row['partner_id']
                f_a = fright_dict.get(a, np.nan)
                f_b = fright_dict.get(b, np.nan)
                if pd.notna(f_a) and pd.notna(f_b) and f_a > 0 and f_b > 0:
                    n_fright_edges += 1
            frac = n_fright_edges / n_edges
            results.append({'run_id': run_id, 'step': step, 'component_id': comp_id, 'value': frac})
    if not results:
        return pd.DataFrame(columns=['run_id', 'step', 'component_id', 'value'])
    return pd.DataFrame(results)