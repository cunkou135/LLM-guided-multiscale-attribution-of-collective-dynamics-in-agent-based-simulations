import pandas as pd
import numpy as np

def compute_indicator(data, config):
    states = data['agent_states'][['run_id','step','agent_id','role','heading']].dropna(subset=['heading'])
    fish = states[states['role']=='fish']
    if fish.empty:
        return pd.Series(dtype=float, name='school_polarization')
    fish['sin_h'] = np.sin(fish['heading'])
    fish['cos_h'] = np.cos(fish['heading'])
    grouped = fish.groupby(['run_id','step']).agg(sum_sin=('sin_h','sum'), sum_cos=('cos_h','sum'), count=('heading','size')).reset_index()
    grouped['pol'] = np.sqrt(grouped['sum_sin']**2 + grouped['sum_cos']**2) / grouped['count']
    result = pd.Series(grouped['pol'].values, index=pd.MultiIndex.from_frame(grouped[['run_id','step']]), name='school_polarization')
    return result
