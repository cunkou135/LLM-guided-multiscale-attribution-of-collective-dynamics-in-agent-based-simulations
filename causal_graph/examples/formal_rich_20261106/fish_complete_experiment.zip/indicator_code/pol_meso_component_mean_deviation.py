import pandas as pd
import numpy as np
from scipy.sparse import csr_matrix
from scipy.sparse.csgraph import connected_components

def compute_indicator(data, config):
    states = data['agent_states'][['run_id','step','agent_id','role','heading']].dropna(subset=['heading'])
    contacts = data['contacts'][['run_id','step','agent_id','partner_id']].dropna()
    if states.empty:
        return pd.Series(dtype=float, name='component_mean_deviation')
    fish = states[states['role']=='fish']
    if fish.empty:
        return pd.Series(dtype=float, name='component_mean_deviation')
    results = []
    for (run_id, step), fish_group in fish.groupby(['run_id','step']):
        fish_ids = fish_group['agent_id'].values
        headings = fish_group['heading'].values
        n = len(fish_ids)
        if n == 0:
            continue
        id_to_idx = {fid: i for i, fid in enumerate(fish_ids)}
        c = contacts[(contacts['run_id']==run_id) & (contacts['step']==step)]
        if not c.empty:
            mask = c['agent_id'].isin(fish_ids) & c['partner_id'].isin(fish_ids)
            c = c[mask]
            if not c.empty:
                rows = c['agent_id'].map(id_to_idx).values
                cols = c['partner_id'].map(id_to_idx).values
                data_ones = np.ones(len(rows))
                adj = csr_matrix((data_ones, (rows, cols)), shape=(n, n))
                adj = adj + adj.T
                adj.data[:] = 1
                n_comp, labels = connected_components(adj, directed=False)
            else:
                n_comp = n
                labels = np.arange(n)
        else:
            n_comp = n
            labels = np.arange(n)
        df_comp = pd.DataFrame({'label': labels, 'heading': headings})
        df_comp['sin_h'] = np.sin(df_comp['heading'])
        df_comp['cos_h'] = np.cos(df_comp['heading'])
        comp_list = []
        for label, group in df_comp.groupby('label'):
            mean_sin = group['sin_h'].mean()
            mean_cos = group['cos_h'].mean()
            Theta_C = np.arctan2(mean_sin, mean_cos)
            diff = group['heading'] - Theta_C
            abs_dev = np.abs(np.arctan2(np.sin(diff), np.cos(diff)))
            mean_dev = abs_dev.mean()
            comp_list.append({'label': label, 'mean_dev': mean_dev})
        comp_df = pd.DataFrame(comp_list)
        comp_df['run_id'] = run_id
        comp_df['step'] = step
        results.append(comp_df)
    if not results:
        return pd.Series(dtype=float, name='component_mean_deviation')
    out = pd.concat(results, ignore_index=True)
    result = pd.Series(out['mean_dev'].values, index=pd.MultiIndex.from_frame(out[['run_id','step','label']].rename(columns={'label':'component_id'})), name='component_mean_deviation')
    return result
