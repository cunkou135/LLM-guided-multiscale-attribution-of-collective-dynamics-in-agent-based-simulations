def compute_indicator(data, config):
    import pandas as pd
    import numpy as np
    from collections import defaultdict

    ag = data['agent_states'][['run_id','step','agent_id','role']].copy()
    ag = ag[ag['role'] == 'fish'].dropna(subset=['agent_id','step','run_id'])
    if len(ag) == 0:
        return pd.Series([], index=pd.MultiIndex.from_tuples([], names=['run_id','step','component_id']), dtype=float)
    ag['agent_id'] = ag['agent_id'].astype('int64')
    fish_by = {}
    for (r, s), g in ag.groupby(['run_id','step']):
        fish_by[(r, s)] = set(g['agent_id'].tolist())

    ct = data['contacts'][['run_id','step','agent_id','partner_id']].dropna().copy()
    if len(ct) > 0:
        ct['agent_id'] = ct['agent_id'].astype('int64')
        ct['partner_id'] = ct['partner_id'].astype('int64')
        ct_groups = dict(list(ct.groupby(['run_id','step'])))
    else:
        ct_groups = {}

    rows = []
    for (r, s), fs in fish_by.items():
        sub = ct_groups.get((r, s))
        edges = set()
        if sub is not None:
            for u, v in zip(sub['agent_id'].tolist(), sub['partner_id'].tolist()):
                if u in fs and v in fs and u != v:
                    edges.add((min(u, v), max(u, v)))
        degree = defaultdict(int)
        for u, v in edges:
            degree[u] += 1
            degree[v] += 1
        parent = {n: n for n in fs}
        def find(x):
            while parent[x] != x:
                parent[x] = parent[parent[x]]
                x = parent[x]
            return x
        for u, v in edges:
            ru, rv = find(u), find(v)
            if ru != rv:
                parent[ru] = rv
        comps = defaultdict(set)
        for n in fs:
            comps[find(n)].add(n)
        for root, nodes in comps.items():
            k_vals = [degree.get(n, 0) for n in nodes]
            rows.append((r, s, int(root), float(np.mean(k_vals))))
    if not rows:
        return pd.Series([], index=pd.MultiIndex.from_tuples([], names=['run_id','step','component_id']), dtype=float)
    idx = pd.MultiIndex.from_tuples([(r, s, k) for r, s, k, _ in rows], names=['run_id','step','component_id'])
    return pd.Series([v for *_ignored, v in rows], index=idx, dtype=float, name='value')
