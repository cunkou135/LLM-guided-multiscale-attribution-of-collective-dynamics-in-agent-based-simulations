import pandas as pd
import numpy as np

def compute_indicator(data, config):
    states = data['agent_states'][['run_id','step','agent_id','role','x','y']].dropna(subset=['x','y'])
    contacts = data['contacts'][['run_id','step','agent_id','partner_id']].dropna()
    fish = states[states['role']=='fish']
    if fish.empty:
        return pd.Series(dtype=float, name='nearest_contact_distance')
    edges1 = contacts[['run_id','step','agent_id','partner_id']]
    edges2 = contacts[['run_id','step','partner_id','agent_id']].rename(columns={'partner_id':'agent_id','agent_id':'partner_id'})
    edges = pd.concat([edges1, edges2], ignore_index=True).drop_duplicates()
    pos = states[['run_id','step','agent_id','x','y']]
    df = edges[['run_id','step','agent_id','partner_id']].copy()
    df = df.merge(pos.rename(columns={'agent_id':'agent_id_focal','x':'x_focal','y':'y_focal'}), on=['run_id','step','agent_id'], how='inner')
    df = df.merge(pos.rename(columns={'agent_id':'partner_id','x':'x_neighbor','y':'y_neighbor'}), on=['run_id','step','partner_id'], how='inner')
    df['dist'] = np.sqrt((df['x_focal']-df['x_neighbor'])**2 + (df['y_focal']-df['y_neighbor'])**2)
    min_dist = df.groupby(['run_id','step','agent_id'])['dist'].min().reset_index()
    merged = fish[['run_id','step','agent_id']].merge(min_dist, on=['run_id','step','agent_id'], how='inner')
    if merged.empty:
        return pd.Series(dtype=float, name='nearest_contact_distance')
    result = pd.Series(merged['dist'].values, index=pd.MultiIndex.from_frame(merged[['run_id','step','agent_id']]), name='nearest_contact_distance')
    return result
