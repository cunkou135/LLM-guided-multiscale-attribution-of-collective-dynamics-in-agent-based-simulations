def compute_indicator(data, config):
    import pandas as pd
    import numpy as np

    a = data['agent_states'][['run_id','step','agent_id','role','x','y','vx','vy']].copy()
    a = a[a['role'] == 'fish'].dropna(subset=['agent_id','step','run_id','x','y','vx','vy'])
    if len(a) == 0:
        return pd.Series([], index=pd.MultiIndex.from_tuples([], names=['run_id','step','agent_id']), dtype=float)
    a['agent_id'] = a['agent_id'].astype('int64')
    out_idx = []
    out_val = []
    for (r, s), g in a.groupby(['run_id','step']):
        xs = g['x'].values.astype(float)
        ys = g['y'].values.astype(float)
        vxs = g['vx'].values.astype(float)
        vys = g['vy'].values.astype(float)
        ids = g['agent_id'].values
        if len(xs) == 0:
            continue
        cx = xs.mean()
        cy = ys.mean()
        rx = xs - cx
        ry = ys - cy
        rnorm = np.sqrt(rx * rx + ry * ry)
        with np.errstate(divide='ignore', invalid='ignore'):
            vals = np.where(rnorm > 0, (rx * vxs + ry * vys) / rnorm, np.nan)
        for i in range(len(ids)):
            out_idx.append((r, s, int(ids[i])))
            out_val.append(float(vals[i]))
    if not out_idx:
        return pd.Series([], index=pd.MultiIndex.from_tuples([], names=['run_id','step','agent_id']), dtype=float)
    idx = pd.MultiIndex.from_tuples(out_idx, names=['run_id','step','agent_id'])
    return pd.Series(out_val, index=idx, dtype=float, name='value')
