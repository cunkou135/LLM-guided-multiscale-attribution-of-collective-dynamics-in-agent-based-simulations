import pandas as pd
import numpy as np
from scipy.sparse import csr_matrix
from scipy.sparse.csgraph import connected_components

def compute_indicator(data, config):
    states = data['agent_states'][['run_id','step','agent_id','role','heading']].dropna(subset=['heading'])
    contacts = data['contacts'][['run_id','step','agent_id','partner_id']].dropna()
    if states.empty:
        return pd.Series(dtype=float, name='component_polarization')
    fish = states[states['role']=='fish']
    if fish.empty:
        return pd.Series(dtype=float, name='component_polarization')
    results = []
    for (run_id, step), fish_group in fish.groupby(['run_id','step']):
        fish_ids = fish_group['agent_id'].values
        headings = fish_group['heading'].values
        n = len(fish_ids)
        if n == 0:
            continue
        id_to_idx = {fid: i for i, fid in enumerate(fish_ids)}
        c = contacts[(contacts['run_id']==run_id) & (contacts['step']==step)]
        if not c.empty:
            mask = c['agent_id'].isin(fish_ids) & c['partner_id'].isin(fish_ids)
            c = c[mask]
            if not c.empty:
                rows = c['agent_id'].map(id_to_idx).values
                cols = c['partner_id'].map(id_to_idx).values
                data_ones = np.ones(len(rows))
                adj = csr_matrix((data_ones, (rows, cols)), shape=(n, n))
                adj = adj + adj.T
                adj.data[:] = 1
                n_comp, labels = connected_components(adj, directed=False)
            else:
                n_comp = n
                labels = np.arange(n)
        else:
            n_comp = n
            labels = np.arange(n)
        df_comp = pd.DataFrame({'label': labels, 'heading': headings})
        df_comp['sin_h'] = np.sin(df_comp['heading'])
        df_comp['cos_h'] = np.cos(df_comp['heading'])
        comp_group = df_comp.groupby('label').agg(sum_sin=('sin_h','sum'), sum_cos=('cos_h','sum'), count=('heading','size')).reset_index()
        comp_group['pol'] = np.sqrt(comp_group['sum_sin']**2 + comp_group['sum_cos']**2) / comp_group['count']
        comp_group['run_id'] = run_id
        comp_group['step'] = step
        results.append(comp_group[['run_id','step','label','pol']])
    if not results:
        return pd.Series(dtype=float, name='component_polarization')
    out = pd.concat(results, ignore_index=True)
    result = pd.Series(out['pol'].values, index=pd.MultiIndex.from_frame(out[['run_id','step','label']].rename(columns={'label':'component_id'})), name='component_polarization')
    return result
