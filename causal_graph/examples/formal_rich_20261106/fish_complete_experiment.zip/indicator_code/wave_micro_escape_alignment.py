def compute_indicator(data, config):
    import numpy as np
    import pandas as pd
    import json
    agent_states = data['agent_states']
    events = data['events']
    fish = agent_states[agent_states['role'] == 'fish'][['run_id', 'step', 'agent_id', 'heading']].dropna(subset=['heading'])
    esc_rows = []
    for rid, st, ag, dj in zip(events['run_id'].values, events['step'].values, events['agent_id'].values, events['decision_json'].values):
        try:
            d = json.loads(dj) if isinstance(dj, str) else None
        except Exception:
            d = None
        ed = d.get('escape_direction') if isinstance(d, dict) else None
        if isinstance(ed, list) and len(ed) == 2:
            try:
                esc_rows.append({'run_id': rid, 'step': int(st), 'agent_id': int(ag), 'ex': float(ed[0]), 'ey': float(ed[1])})
            except Exception:
                pass
    esc = pd.DataFrame(esc_rows, columns=['run_id', 'step', 'agent_id', 'ex', 'ey'])
    if esc.shape[0] == 0 or fish.shape[0] == 0:
        return pd.Series(dtype=float, index=pd.MultiIndex.from_arrays([[], []], names=['step', 'agent_id']))
    merged = fish.merge(esc, on=['run_id', 'step', 'agent_id'], how='inner')
    if merged.shape[0] == 0:
        return pd.Series(dtype=float, index=pd.MultiIndex.from_arrays([[], []], names=['step', 'agent_id']))
    val = np.cos(merged['heading'].values - np.arctan2(merged['ey'].values, merged['ex'].values))
    idx = pd.MultiIndex.from_arrays([merged['step'].astype(int).values, merged['agent_id'].astype(int).values], names=['step', 'agent_id'])
    return pd.Series(val, index=idx, dtype=float).sort_index()