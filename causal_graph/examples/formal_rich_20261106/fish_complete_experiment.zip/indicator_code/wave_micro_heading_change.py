def compute_indicator(data, config):
    import numpy as np
    import pandas as pd
    agent_states = data['agent_states']
    fish = agent_states[agent_states['role'] == 'fish'][['run_id', 'step', 'agent_id', 'heading']].dropna(subset=['heading']).copy()
    fish = fish.sort_values(['run_id', 'agent_id', 'step'])
    g = fish.groupby(['run_id', 'agent_id'])
    fish['prev_step'] = g['step'].shift(1)
    fish['prev_head'] = g['heading'].shift(1)
    mask = fish['prev_step'] == (fish['step'] - 1)
    sub = fish[mask]
    if sub.shape[0] == 0:
        return pd.Series(dtype=float, index=pd.MultiIndex.from_arrays([[], []], names=['step', 'agent_id']))
    d = sub['heading'].values - sub['prev_head'].values
    val = np.abs(np.arctan2(np.sin(d), np.cos(d)))
    idx = pd.MultiIndex.from_arrays([sub['step'].astype(int).values, sub['agent_id'].astype(int).values], names=['step', 'agent_id'])
    return pd.Series(val, index=idx, dtype=float).sort_index()