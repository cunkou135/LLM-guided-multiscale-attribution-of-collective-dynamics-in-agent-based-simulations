import pandas as pd
import numpy as np
from scipy.sparse import csr_matrix
from scipy.sparse.csgraph import connected_components

def compute_indicator(data, config):
    states = data['agent_states'][['run_id','step','agent_id','role','x','y','heading']].dropna(subset=['x','y','heading'])
    contacts = data['contacts'][['run_id','step','agent_id','partner_id']].dropna()
    if states.empty:
        return pd.Series(dtype=float, name='component_away_shark_alignment')
    fish = states[states['role']=='fish']
    sharks = states[states['role']=='shark']
    if fish.empty or sharks.empty:
        return pd.Series(dtype=float, name='component_away_shark_alignment')
    results = []
    for (run_id, step), fish_group in fish.groupby(['run_id','step']):
        shark_group = sharks[(sharks['run_id']==run_id) & (sharks['step']==step)]
        if shark_group.empty:
            continue
        shark_pos = shark_group[['x','y']].values
        fish_ids = fish_group['agent_id'].values
        headings = fish_group['heading'].values
        positions = fish_group[['x','y']].values
        n = len(fish_ids)
        if n == 0:
            continue
        id_to_idx = {fid: i for i, fid in enumerate(fish_ids)}
        c = contacts[(contacts['run_id']==run_id) & (contacts['step']==step)]
        if not c.empty:
            mask = c['agent_id'].isin(fish_ids) & c['partner_id'].isin(fish_ids)
            c = c[mask]
            if not c.empty:
                rows = c['agent_id'].map(id_to_idx).values
                cols = c['partner_id'].map(id_to_idx).values
                data_ones = np.ones(len(rows))
                adj = csr_matrix((data_ones, (rows, cols)), shape=(n, n))
                adj = adj + adj.T
                adj.data[:] = 1
                n_comp, labels = connected_components(adj, directed=False)
            else:
                n_comp = n
                labels = np.arange(n)
        else:
            n_comp = n
            labels = np.arange(n)
        comp_list = []
        for label in range(n_comp):
            idx = np.where(labels == label)[0]
            if len(idx) == 0:
                continue
            pos_comp = positions[idx]
            head_comp = headings[idx]
            centroid = pos_comp.mean(axis=0)
            mean_sin = np.sin(head_comp).mean()
            mean_cos = np.cos(head_comp).mean()
            Theta_C = np.arctan2(mean_sin, mean_cos)
            dists = np.sqrt(((shark_pos - centroid)**2).sum(axis=1))
            min_idx = np.argmin(dists)
            d_min = dists[min_idx]
            if d_min <= 0:
                continue
            a = (centroid - shark_pos[min_idx]) / d_min
            align = np.cos(Theta_C)*a[0] + np.sin(Theta_C)*a[1]
            comp_list.append({'label': label, 'alignment': align})
        if not comp_list:
            continue
        comp_df = pd.DataFrame(comp_list)
        comp_df['run_id'] = run_id
        comp_df['step'] = step
        results.append(comp_df)
    if not results:
        return pd.Series(dtype=float, name='component_away_shark_alignment')
    out = pd.concat(results, ignore_index=True)
    result = pd.Series(out['alignment'].values, index=pd.MultiIndex.from_frame(out[['run_id','step','label']].rename(columns={'label':'component_id'})), name='component_away_shark_alignment')
    return result
