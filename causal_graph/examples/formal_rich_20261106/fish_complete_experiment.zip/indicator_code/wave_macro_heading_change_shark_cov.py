import pandas as pd
import numpy as np

def compute_indicator(data, config):
    df = data['agent_states'].copy()
    fish = df[df['role'] == 'fish'].copy()
    sharks = df[df['role'] == 'shark'].copy()
    if fish.empty or sharks.empty:
        return pd.DataFrame(columns=['run_id', 'step', 'value'])
    fish = fish.sort_values(['run_id', 'agent_id', 'step'])
    fish['prev_heading'] = fish.groupby(['run_id', 'agent_id'])['heading'].shift(1)
    fish['prev_step'] = fish.groupby(['run_id', 'agent_id'])['step'].shift(1)
    fish['valid_prev'] = fish['prev_step'] == fish['step'] - 1
    fish = fish[fish['valid_prev']].copy()
    if fish.empty:
        return pd.DataFrame(columns=['run_id', 'step', 'value'])
    def angle_diff(h1, h2):
        d = h1 - h2
        d = (d + np.pi) % (2*np.pi) - np.pi
        return abs(d)
    fish['delta_theta'] = fish.apply(lambda row: angle_diff(row['heading'], row['prev_heading']), axis=1)
    results = []
    for (run_id, step), fish_group in fish.groupby(['run_id', 'step']):
        shark_group = sharks[(sharks['run_id'] == run_id) & (sharks['step'] == step)]
        if shark_group.empty:
            continue
        fish_pos = fish_group[['x', 'y']].values
        shark_pos = shark_group[['x', 'y']].values
        diff = fish_pos[:, np.newaxis, :] - shark_pos[np.newaxis, :, :]
        dist = np.linalg.norm(diff, axis=2)
        min_dist = dist.min(axis=1)
        valid = min_dist > 0
        if valid.sum() < 2:
            continue
        x_vals = fish_group['delta_theta'].values[valid]
        y_vals = 1.0 / min_dist[valid]
        mean_x = x_vals.mean()
        mean_y = y_vals.mean()
        cov = np.mean((x_vals - mean_x) * (y_vals - mean_y))
        results.append({'run_id': run_id, 'step': step, 'value': cov})
    return pd.DataFrame(results)