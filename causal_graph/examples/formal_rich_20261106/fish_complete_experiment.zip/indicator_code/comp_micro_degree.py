import pandas as pd
import numpy as np

def compute_indicator(data, config):
    states = data['agent_states'][['run_id','step','agent_id','role']].dropna()
    contacts = data['contacts'][['run_id','step','agent_id','partner_id']].dropna()
    fish = states[states['role']=='fish']
    if fish.empty:
        return pd.Series(dtype=float, name='degree')
    edges1 = contacts[['run_id','step','agent_id','partner_id']]
    edges2 = contacts[['run_id','step','partner_id','agent_id']].rename(columns={'partner_id':'agent_id','agent_id':'partner_id'})
    edges = pd.concat([edges1, edges2], ignore_index=True).drop_duplicates()
    degree_df = edges.groupby(['run_id','step','agent_id'])['partner_id'].nunique().reset_index()
    degree_df = degree_df.rename(columns={'partner_id':'degree'})
    merged = fish.merge(degree_df, on=['run_id','step','agent_id'], how='left')
    merged['degree'] = merged['degree'].fillna(0).astype(int)
    result = pd.Series(merged['degree'].values, index=pd.MultiIndex.from_frame(merged[['run_id','step','agent_id']]), name='degree')
    return result
