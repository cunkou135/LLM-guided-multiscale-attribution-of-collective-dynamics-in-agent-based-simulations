import pandas as pd
import numpy as np

def compute_indicator(data, config):
    agents = data['agent_states'].copy()
    contacts = data['contacts'].copy()
    agent_fright = agents[['run_id', 'step', 'agent_id', 'fright']].rename(columns={'fright': 'fright_agent'})
    merged = contacts.merge(agent_fright, on=['run_id', 'step', 'agent_id'], how='left')
    merged = merged.merge(agent_fright, left_on=['run_id', 'step', 'partner_id'], right_on=['run_id', 'step', 'agent_id'], how='left', suffixes=('_focal', '_partner'))
    results = []
    for (run_id, step), group in merged.groupby(['run_id', 'step']):
        total_edges = len(group)
        if total_edges == 0:
            val = np.nan
        else:
            valid = group[(group['fright_agent_focal'] > 0) & (group['fright_agent_partner'] > 0)]
            frac = len(valid) / total_edges
            val = frac
        results.append({'run_id': run_id, 'step': step, 'value': val})
    return pd.DataFrame(results)