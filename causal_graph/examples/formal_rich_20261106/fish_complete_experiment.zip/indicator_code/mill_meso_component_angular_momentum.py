def compute_indicator(data, config):
    import pandas as pd
    import numpy as np
    from collections import defaultdict

    a = data['agent_states'][['run_id','step','agent_id','role','x','y','vx','vy']].copy()
    a = a[a['role'] == 'fish'].dropna(subset=['agent_id','step','run_id','x','y','vx','vy'])
    if len(a) == 0:
        return pd.Series([], index=pd.MultiIndex.from_tuples([], names=['run_id','step','component_id']), dtype=float)
    a['agent_id'] = a['agent_id'].astype('int64')
    ct = data['contacts'][['run_id','step','agent_id','partner_id']].dropna().copy()
    if len(ct) > 0:
        ct['agent_id'] = ct['agent_id'].astype('int64')
        ct['partner_id'] = ct['partner_id'].astype('int64')
        ct_groups = dict(list(ct.groupby(['run_id','step'])))
    else:
        ct_groups = {}
    rows = []
    for (r, s), g in a.groupby(['run_id','step']):
        ids = g['agent_id'].tolist()
        xs = g['x'].tolist()
        ys = g['y'].tolist()
        vxs = g['vx'].tolist()
        vys = g['vy'].tolist()
        pos = {int(i): (float(x), float(y)) for i, x, y in zip(ids, xs, ys)}
        vel = {int(i): (float(vx), float(vy)) for i, vx, vy in zip(ids, vxs, vys)}
        fs = set(int(i) for i in ids)
        sub = ct_groups.get((r, s))
        edges = set()
        if sub is not None:
            for u, v in zip(sub['agent_id'].tolist(), sub['partner_id'].tolist()):
                if u in fs and v in fs and u != v:
                    edges.add((min(u, v), max(u, v)))
        parent = {n: n for n in fs}
        def find(x):
            while parent[x] != x:
                parent[x] = parent[parent[x]]
                x = parent[x]
            return x
        for u, v in edges:
            ru, rv = find(u), find(v)
            if ru != rv:
                parent[ru] = rv
        comps = defaultdict(set)
        for n in fs:
            comps[find(n)].add(n)
        for root, nodes in comps.items():
            idx_list = sorted(nodes)
            px = np.array([pos[n][0] for n in idx_list], dtype=float)
            py = np.array([pos[n][1] for n in idx_list], dtype=float)
            vx = np.array([vel[n][0] for n in idx_list], dtype=float)
            vy = np.array([vel[n][1] for n in idx_list], dtype=float)
            cx = px.mean()
            cy = py.mean()
            rx = px - cx
            ry = py - cy
            val = float(np.mean(rx * vy - ry * vx))
            rows.append((r, s, int(root), val))
    if not rows:
        return pd.Series([], index=pd.MultiIndex.from_tuples([], names=['run_id','step','component_id']), dtype=float)
    idx = pd.MultiIndex.from_tuples([(r, s, k) for r, s, k, _ in rows], names=['run_id','step','component_id'])
    return pd.Series([val for *_ignored, val in rows], index=idx, dtype=float, name='value')
