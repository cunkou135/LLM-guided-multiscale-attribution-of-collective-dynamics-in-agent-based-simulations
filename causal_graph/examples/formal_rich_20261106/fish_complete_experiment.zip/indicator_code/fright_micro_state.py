import pandas as pd
import numpy as np

def compute_indicator(data, config):
    df = data['agent_states'].copy()
    fish = df[df['role'] == 'fish'].copy()
    if fish.empty:
        return pd.DataFrame(columns=['run_id', 'step', 'agent_id', 'value'])
    fish['value'] = fish['fright'].apply(lambda x: 1 if pd.notna(x) and x > 0 else (0 if pd.notna(x) else np.nan))
    return fish[['run_id', 'step', 'agent_id', 'value']].copy()