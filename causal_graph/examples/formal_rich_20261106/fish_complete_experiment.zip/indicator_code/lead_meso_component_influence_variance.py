import pandas as pd
import numpy as np
from collections import deque

def compute_indicator(data, config):
    ag = data['agent_states']
    fish = ag[ag['role'] == 'fish'][['run_id','step','agent_id','heading']].copy()
    fish = fish.sort_values(['run_id','agent_id','step'])
    fish['prev_heading'] = fish.groupby(['run_id','agent_id'])['heading'].shift(1)
    fish['delta'] = np.arctan2(np.sin(fish['heading'] - fish['prev_heading']), np.cos(fish['heading'] - fish['prev_heading']))
    contacts = data['contacts'][['run_id','step','agent_id','partner_id']].copy()
    partner_next = fish[['run_id','step','agent_id','delta']].rename(columns={'agent_id':'partner_id','delta':'partner_delta_next'}).copy()
    partner_next['step'] = partner_next['step'] - 1
    merged = contacts.merge(partner_next, on=['run_id','step','partner_id'], how='inner')
    def mean_no_nan(x):
        if x.isna().any():
            return np.nan
        return x.mean()
    y_df = merged.groupby(['run_id','step','agent_id'])['partner_delta_next'].apply(mean_no_nan).reset_index(name='y')
    result = fish[['run_id','step','agent_id','delta']].merge(y_df, on=['run_id','step','agent_id'], how='left')
    result = result.rename(columns={'delta':'x'})
    def corr_func(g):
        g = g.dropna(subset=['x','y'])
        if len(g) < 2:
            return np.nan
        if g['x'].std() == 0 or g['y'].std() == 0:
            return np.nan
        return np.corrcoef(g['x'], g['y'])[0,1]
    scores = result.groupby(['run_id','agent_id']).apply(corr_func).reset_index(name='s')
    s_dict = scores.set_index(['run_id','agent_id'])['s'].to_dict()
    ref_mode = config.get('reference_step', 'last')
    contacts_dict = {k: v for k, v in contacts.groupby(['run_id','step'])}
    rows = []
    for run_id, run_group in ag[ag['role'] == 'fish'].groupby('run_id'):
        steps = sorted(run_group['step'].unique())
        if ref_mode == 'last':
            ref_step = steps[-1]
        elif ref_mode == 'first':
            ref_step = steps[0]
        else:
            ref_step = int(ref_mode)
        fish_ref = run_group[run_group['step'] == ref_step]['agent_id'].tolist()
        if len(fish_ref) == 0:
            continue
        adj = {i: set() for i in fish_ref}
        edge_df = contacts_dict.get((run_id, ref_step))
        if edge_df is not None:
            for _, row in edge_df.iterrows():
                a = row['agent_id']
                b = row['partner_id']
                if a in adj and b in adj:
                    adj[a].add(b)
                    adj[b].add(a)
        visited = set()
        for i in fish_ref:
            if i in visited:
                continue
            q = deque([i])
            visited.add(i)
            comp = []
            while q:
                u = q.popleft()
                comp.append(u)
                for v in adj[u]:
                    if v not in visited:
                        visited.add(v)
                        q.append(v)
            comp_id = min(comp)
            s_vals = [s_dict.get((run_id, agent), np.nan) for agent in comp]
            defined = [v for v in s_vals if not np.isnan(v)]
            D = len(defined)
            if D < 2:
                val = np.nan
            else:
                mean_s = np.mean(defined)
                val = np.mean([(v - mean_s)**2 for v in defined])
            rows.append((run_id, comp_id, val))
    if not rows:
        return pd.Series(dtype=float, name='value')
    out = pd.DataFrame(rows, columns=['run_id','component_id','value']).set_index(['run_id','component_id'])
    return out['value']
