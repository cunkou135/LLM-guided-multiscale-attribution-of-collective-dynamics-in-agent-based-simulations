import pandas as pd
import numpy as np

def compute_indicator(data, config):
    states = data['agent_states'][['run_id','step','agent_id','role','x','y','heading']].dropna(subset=['x','y','heading'])
    if states.empty:
        return pd.Series(dtype=float, name='polarization_proximity_cov')
    fish = states[states['role']=='fish']
    sharks = states[states['role']=='shark']
    if fish.empty:
        return pd.Series(dtype=float, name='polarization_proximity_cov')
    fish['sin_h'] = np.sin(fish['heading'])
    fish['cos_h'] = np.cos(fish['heading'])
    R_df = fish.groupby(['run_id','step']).agg(sum_sin=('sin_h','sum'), sum_cos=('cos_h','sum'), count=('heading','size')).reset_index()
    R_df['R'] = np.sqrt(R_df['sum_sin']**2 + R_df['sum_cos']**2) / R_df['count']
    R_df = R_df[['run_id','step','R']]
    merged = fish.merge(sharks, on=['run_id','step'], suffixes=('_fish','_shark'))
    if merged.empty:
        return pd.Series(dtype=float, name='polarization_proximity_cov')
    merged['dist'] = np.sqrt((merged['x_fish']-merged['x_shark'])**2 + (merged['y_fish']-merged['y_shark'])**2)
    min_dist = merged.groupby(['run_id','step','agent_id_fish'])['dist'].min().reset_index()
    min_dist['inv_dist'] = 1.0 / min_dist['dist']
    min_dist.loc[min_dist['dist'] == 0, 'inv_dist'] = np.nan
    q_df = min_dist.groupby(['run_id','step'])['inv_dist'].mean().reset_index()
    q_df = q_df.rename(columns={'inv_dist':'q'})
    merged_Rq = R_df.merge(q_df, on=['run_id','step'], how='inner')
    merged_Rq = merged_Rq.dropna(subset=['q'])
    if merged_Rq.empty:
        return pd.Series(dtype=float, name='polarization_proximity_cov')
    def cov_group(g):
        R = g['R'].values
        q = g['q'].values
        if len(R) < 1:
            return np.nan
        mean_R = R.mean()
        mean_q = q.mean()
        cov = np.mean((R - mean_R) * (q - mean_q))
        return cov
    cov_series = merged_Rq.groupby('run_id').apply(cov_group)
    cov_series.name = 'polarization_proximity_cov'
    return cov_series
