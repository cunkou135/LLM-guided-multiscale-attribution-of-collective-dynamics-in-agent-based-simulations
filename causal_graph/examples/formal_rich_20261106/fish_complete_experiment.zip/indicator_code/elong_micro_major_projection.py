import pandas as pd
import numpy as np

def compute_indicator(data, config):
    min_eig = float(config.get('min_eigenvalue', 1e-12))
    ast = data['agent_states'][['run_id', 'step', 'agent_id', 'role', 'x', 'y']]
    fish = ast[ast['role'] == 'fish']
    rows = []
    for k, g in fish.groupby(['run_id', 'step']):
        run_id = k[0]
        step = int(k[1])
        ids = g['agent_id'].values
        P = np.column_stack([g['x'].values.astype(float), g['y'].values.astype(float)])
        n = P.shape[0]
        if n < 2:
            for a in ids:
                rows.append((run_id, step, int(a), np.nan))
            continue
        c = P.mean(axis=0)
        D = P - c
        C = (D.T @ D) / n
        try:
            w, V = np.linalg.eigh(C)
        except np.linalg.LinAlgError:
            for a in ids:
                rows.append((run_id, step, int(a), np.nan))
            continue
        lam1 = w[1]
        u1 = V[:, 1]
        if lam1 <= min_eig:
            for a in ids:
                rows.append((run_id, step, int(a), np.nan))
            continue
        proj = (D @ u1) / np.sqrt(lam1)
        for a, v in zip(ids, proj):
            rows.append((run_id, step, int(a), float(v)))
    out = pd.DataFrame(rows, columns=['run_id', 'step', 'agent_id', 'value'])
    out = out.set_index(['run_id', 'step', 'agent_id'])['value']
    return out
