def compute_indicator(data, config):
    import numpy as np
    import pandas as pd
    from collections import defaultdict
    agent_states = data['agent_states']
    contacts = data['contacts']
    fish = agent_states[agent_states['role'] == 'fish'][['run_id', 'step', 'agent_id', 'x', 'y']].dropna(subset=['x', 'y'])
    rows = []
    for (rid, st), grp in contacts.groupby(['run_id', 'step'], observed=True):
        adj = defaultdict(set)
        for a, b in zip(grp['agent_id'].values, grp['partner_id'].values):
            if pd.isna(a) or pd.isna(b):
                continue
            ai = int(a); bi = int(b)
            if ai == bi:
                continue
            adj[ai].add(bi); adj[bi].add(ai)
        seen = set(); cid = 0
        for node in list(adj.keys()):
            if node in seen:
                continue
            stack = [node]; comp = []
            while stack:
                cur = stack.pop()
                if cur in seen:
                    continue
                seen.add(cur); comp.append(cur)
                for nb in adj[cur]:
                    if nb not in seen:
                        stack.append(nb)
            for m in comp:
                rows.append({'run_id': rid, 'step': int(st), 'group_id': int(cid), 'agent_id': int(m)})
            cid += 1
    if not rows:
        return pd.Series(dtype=float, index=pd.MultiIndex.from_arrays([[], []], names=['step', 'group_id']))
    comp_df = pd.DataFrame(rows)
    merged = comp_df.merge(fish, on=['run_id', 'step', 'agent_id'], how='inner')
    if merged.shape[0] == 0:
        return pd.Series(dtype=float, index=pd.MultiIndex.from_arrays([[], []], names=['step', 'group_id']))
    steps = []; gids = []; vals = []
    for (rid, step, gid), grp in merged.groupby(['run_id', 'step', 'group_id'], observed=True):
        xy = grp[['x', 'y']].values
        if xy.shape[0] < 2:
            val = np.nan
        else:
            cov = np.cov(xy, rowvar=False)
            eigs = np.sort(np.linalg.eigvalsh(cov))[::-1]
            l1 = float(max(eigs[0], 0.0))
            val = float(np.sqrt(l1))
        steps.append(int(step)); gids.append(int(gid)); vals.append(val)
    idx = pd.MultiIndex.from_arrays([steps, gids], names=['step', 'group_id'])
    return pd.Series(vals, index=idx, dtype=float).sort_index()