import pandas as pd
import numpy as np

def compute_indicator(data, config):
    ag = data['agent_states']
    fish = ag[ag['role'] == 'fish'][['run_id','step','agent_id','heading']].copy()
    fish = fish.sort_values(['run_id','agent_id','step'])
    fish['prev_heading'] = fish.groupby(['run_id','agent_id'])['heading'].shift(1)
    fish['delta'] = np.arctan2(np.sin(fish['heading'] - fish['prev_heading']), np.cos(fish['heading'] - fish['prev_heading']))
    contacts = data['contacts'][['run_id','step','agent_id','partner_id']].copy()
    partner_next = fish[['run_id','step','agent_id','delta']].rename(columns={'agent_id':'partner_id','delta':'partner_delta_next'}).copy()
    partner_next['step'] = partner_next['step'] - 1
    merged = contacts.merge(partner_next, on=['run_id','step','partner_id'], how='inner')
    def mean_no_nan(x):
        if x.isna().any():
            return np.nan
        return x.mean()
    y_df = merged.groupby(['run_id','step','agent_id'])['partner_delta_next'].apply(mean_no_nan).reset_index(name='y')
    result = fish[['run_id','step','agent_id','delta']].merge(y_df, on=['run_id','step','agent_id'], how='left')
    result = result.rename(columns={'delta':'x'})
    def corr_func(g):
        g = g.dropna(subset=['x','y'])
        if len(g) < 2:
            return np.nan
        if g['x'].std() == 0 or g['y'].std() == 0:
            return np.nan
        return np.corrcoef(g['x'], g['y'])[0,1]
    scores = result.groupby(['run_id','agent_id']).apply(corr_func).reset_index(name='s')
    def var_run(g):
        valid = g['s'].dropna()
        M = len(valid)
        if M < 2:
            return np.nan
        mean_s = valid.mean()
        return ((valid - mean_s)**2).mean()
    res = scores.groupby('run_id').apply(var_run)
    res.name = 'value'
    return res
