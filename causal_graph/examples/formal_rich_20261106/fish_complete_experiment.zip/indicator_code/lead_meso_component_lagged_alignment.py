import pandas as pd
import numpy as np
from collections import deque

def compute_indicator(data, config):
    ag = data['agent_states']
    fish = ag[ag['role'] == 'fish'][['run_id','step','agent_id','heading']].copy()
    fish = fish.sort_values(['run_id','agent_id','step'])
    fish['prev_heading'] = fish.groupby(['run_id','agent_id'])['heading'].shift(1)
    fish['delta'] = np.arctan2(np.sin(fish['heading'] - fish['prev_heading']), np.cos(fish['heading'] - fish['prev_heading']))
    contacts = data['contacts'][['run_id','step','agent_id','partner_id']].copy()
    partner_delta = fish[['run_id','step','agent_id','delta']].rename(columns={'agent_id':'partner_id','delta':'partner_delta'})
    merged = contacts.merge(partner_delta, on=['run_id','step','partner_id'], how='inner')
    def mean_no_nan(x):
        if x.isna().any():
            return np.nan
        return x.mean()
    m_df = merged.groupby(['run_id','step','agent_id'])['partner_delta'].apply(mean_no_nan).reset_index(name='m')
    m_df['step'] = m_df['step'] + 1
    L_df = fish[['run_id','step','agent_id','delta']].merge(m_df, on=['run_id','step','agent_id'], how='left')
    L_df['L'] = np.cos(L_df['delta'] - L_df['m'])
    L_dict = L_df.set_index(['run_id','step','agent_id'])['L'].to_dict()
    fish_ids_df = ag[ag['role'] == 'fish'][['run_id','step','agent_id']].copy()
    contacts_dict = {k: v for k, v in contacts.groupby(['run_id','step'])}
    rows = []
    for (run_id, step), group in fish_ids_df.groupby(['run_id','step']):
        fish_ids = group['agent_id'].tolist()
        if len(fish_ids) == 0:
            continue
        adj = {i: set() for i in fish_ids}
        edge_df = contacts_dict.get((run_id, step))
        if edge_df is not None:
            for _, row in edge_df.iterrows():
                a = row['agent_id']
                b = row['partner_id']
                if a in adj and b in adj:
                    adj[a].add(b)
                    adj[b].add(a)
        visited = set()
        for i in fish_ids:
            if i in visited:
                continue
            q = deque([i])
            visited.add(i)
            comp = []
            while q:
                u = q.popleft()
                comp.append(u)
                for v in adj[u]:
                    if v not in visited:
                        visited.add(v)
                        q.append(v)
            comp_id = min(comp)
            Ls = [L_dict.get((run_id, step, agent), np.nan) for agent in comp]
            if any(np.isnan(Ls)):
                val = np.nan
            else:
                val = np.mean(Ls)
            rows.append((run_id, step, comp_id, val))
    if not rows:
        return pd.Series(dtype=float, name='value')
    out = pd.DataFrame(rows, columns=['run_id','step','component_id','value']).set_index(['run_id','step','component_id'])
    return out['value']
