import pandas as pd

def compute_indicator(data, config):
    df = data['agent_states'].copy()
    fish = df[df['role'] == 'fish'].copy()
    if fish.empty:
        return pd.DataFrame(columns=['run_id', 'step', 'agent_id', 'value'])
    result = fish[['run_id', 'step', 'agent_id']].copy()
    result['value'] = fish['remaining']
    return result