import pandas as pd
import numpy as np
from collections import defaultdict

def compute_indicator(data, config):
    ast = data['agent_states'][['run_id', 'step', 'agent_id', 'role', 'x', 'y']]
    con = data['contacts'][['run_id', 'step', 'agent_id', 'partner_id']]
    fish = ast[ast['role'] == 'fish']
    adj = defaultdict(set)
    for k, gg in con.groupby(['run_id', 'step']):
        run_id = k[0]
        step = int(k[1])
        for a, b in zip(gg['agent_id'].values, gg['partner_id'].values):
            if a == b:
                continue
            adj[(run_id, step, int(a))].add(int(b))
            adj[(run_id, step, int(b))].add(int(a))
    rows = []
    for k, g in fish.groupby(['run_id', 'step']):
        run_id = k[0]
        step = int(k[1])
        for a in g['agent_id'].values:
            deg = len(adj.get((run_id, step, int(a)), set()))
            rows.append((run_id, step, int(a), 1 if deg == 0 else 0))
    out = pd.DataFrame(rows, columns=['run_id', 'step', 'agent_id', 'value'])
    out = out.set_index(['run_id', 'step', 'agent_id'])['value']
    return out
