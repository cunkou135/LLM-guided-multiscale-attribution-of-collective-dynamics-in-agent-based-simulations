import pandas as pd
import numpy as np

def compute_indicator(data, config):
    agents = data['agent_states'].copy()
    fish = agents[agents['role'] == 'fish']
    if fish.empty:
        return pd.DataFrame(columns=['run_id', 'step', 'value'])
    grouped = fish.groupby(['run_id', 'step'])
    results = []
    for (run_id, step), group in grouped:
        n = len(group)
        n_fright = (group['fright'] > 0).sum()
        if n == 0:
            val = np.nan
        else:
            val = n_fright / n
        results.append({'run_id': run_id, 'step': step, 'value': val})
    return pd.DataFrame(results)