import pandas as pd
import numpy as np

def compute_indicator(data, config):
    ag = data['agent_states']
    fish = ag[ag['role'] == 'fish'][['run_id','step','agent_id','heading']].copy()
    fish = fish.sort_values(['run_id','agent_id','step'])
    fish['prev_heading'] = fish.groupby(['run_id','agent_id'])['heading'].shift(1)
    fish['delta'] = np.arctan2(np.sin(fish['heading'] - fish['prev_heading']), np.cos(fish['heading'] - fish['prev_heading']))
    delta_dict = fish.set_index(['run_id','step','agent_id'])['delta'].to_dict()
    fish_ids_df = ag[ag['role'] == 'fish'][['run_id','step','agent_id']].copy()
    rows = []
    for run_id, run_group in fish_ids_df.groupby('run_id'):
        steps = sorted(run_group['step'].unique())
        for t in steps[1:]:
            fish_t = run_group[run_group['step'] == t]['agent_id'].tolist()
            fish_prev = run_group[run_group['step'] == t-1]['agent_id'].tolist()
            if len(fish_t) == 0 or len(fish_prev) == 0:
                continue
            delta_curr = [delta_dict.get((run_id, t, i), np.nan) for i in fish_t]
            delta_prev = [delta_dict.get((run_id, t-1, i), np.nan) for i in fish_prev]
            if any(np.isnan(delta_curr)) or any(np.isnan(delta_prev)):
                val = np.nan
            else:
                M = np.mean(delta_prev)
                if M == 0:
                    val = np.nan
                else:
                    s = np.sign(M)
                    val = np.mean([1.0 if np.sign(d) == s else 0.0 for d in delta_curr])
            rows.append((run_id, t, val))
    if not rows:
        return pd.Series(dtype=float, name='value')
    out = pd.DataFrame(rows, columns=['run_id','step','value']).set_index(['run_id','step'])
    return out['value']
