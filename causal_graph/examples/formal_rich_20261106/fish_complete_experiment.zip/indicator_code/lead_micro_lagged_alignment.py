import pandas as pd
import numpy as np

def compute_indicator(data, config):
    ag = data['agent_states']
    fish = ag[ag['role'] == 'fish'][['run_id','step','agent_id','heading']].copy()
    fish = fish.sort_values(['run_id','agent_id','step'])
    fish['prev_heading'] = fish.groupby(['run_id','agent_id'])['heading'].shift(1)
    fish['delta'] = np.arctan2(np.sin(fish['heading'] - fish['prev_heading']), np.cos(fish['heading'] - fish['prev_heading']))
    contacts = data['contacts'][['run_id','step','agent_id','partner_id']].copy()
    partner_delta = fish[['run_id','step','agent_id','delta']].rename(columns={'agent_id':'partner_id','delta':'partner_delta'})
    merged = contacts.merge(partner_delta, on=['run_id','step','partner_id'], how='inner')
    def mean_no_nan(x):
        if x.isna().any():
            return np.nan
        return x.mean()
    m_df = merged.groupby(['run_id','step','agent_id'])['partner_delta'].apply(mean_no_nan).reset_index(name='m')
    m_df['step'] = m_df['step'] + 1
    result = fish[['run_id','step','agent_id','delta']].merge(m_df, on=['run_id','step','agent_id'], how='left')
    result['value'] = np.cos(result['delta'] - result['m'])
    result = result.set_index(['run_id','step','agent_id'])
    return result['value']
