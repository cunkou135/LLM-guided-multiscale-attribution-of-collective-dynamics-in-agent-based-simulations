import pandas as pd
import numpy as np
import math

def compute_indicator(data, config):
    df = data['agent_states']
    fish = df[df['role'] == 'fish'].copy()
    if fish.empty:
        return pd.Series(dtype=float, name='heading_deviation')
    fish['sin_h'] = np.sin(fish['heading'])
    fish['cos_h'] = np.cos(fish['heading'])
    grouped = fish.groupby(['run_id', 'step'])
    mean_sin = grouped['sin_h'].transform('mean')
    mean_cos = grouped['cos_h'].transform('mean')
    Theta = np.arctan2(mean_sin, mean_cos)
    diff = fish['heading'] - Theta
    dev = np.abs(np.arctan2(np.sin(diff), np.cos(diff)))
    result = pd.Series(dev.values, index=pd.MultiIndex.from_frame(fish[['run_id','step','agent_id']]), name='heading_deviation')
    return result
