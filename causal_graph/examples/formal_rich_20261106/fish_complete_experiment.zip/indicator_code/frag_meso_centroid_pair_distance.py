import pandas as pd
import numpy as np
from collections import Counter, defaultdict

def _uf(nodes, edges):
    parent = {n: n for n in nodes}
    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x
    for a, b in edges:
        if a in parent and b in parent:
            ra, rb = find(a), find(b)
            if ra != rb:
                parent[ra] = rb
    return {n: find(n) for n in nodes}

def compute_indicator(data, config):
    ast = data['agent_states'][['run_id', 'step', 'agent_id', 'role', 'x', 'y']]
    con = data['contacts'][['run_id', 'step', 'agent_id', 'partner_id']]
    fish = ast[ast['role'] == 'fish']
    con_groups = {}
    for k, gg in con.groupby(['run_id', 'step']):
        con_groups[(k[0], int(k[1]))] = gg
    rows = []
    for k, g in fish.groupby(['run_id', 'step']):
        run_id = k[0]
        step = int(k[1])
        nodes = g['agent_id'].tolist()
        node_set = set(nodes)
        posx = dict(zip(g['agent_id'].values, g['x'].values))
        posy = dict(zip(g['agent_id'].values, g['y'].values))
        edges = []
        cg = con_groups.get((run_id, step))
        if cg is not None:
            for a, b in zip(cg['agent_id'].values, cg['partner_id'].values):
                if a in node_set and b in node_set and a != b:
                    edges.append((a, b))
        comp = _uf(nodes, edges)
        members = defaultdict(list)
        for a in nodes:
            members[comp[a]].append(a)
        cents = []
        for root, mem in members.items():
            cx = float(np.mean([posx[m] for m in mem]))
            cy = float(np.mean([posy[m] for m in mem]))
            cents.append((cx, cy))
        m = len(cents)
        if m < 2:
            rows.append((run_id, step, np.nan))
            continue
        vals = []
        for i in range(m):
            for j in range(i + 1, m):
                vals.append(np.hypot(cents[i][0] - cents[j][0], cents[i][1] - cents[j][1]))
        rows.append((run_id, step, float(np.mean(vals))))
    df = pd.DataFrame(rows, columns=['run_id', 'step', 'value'])
    out = df.groupby('step')['value'].mean()
    return out
