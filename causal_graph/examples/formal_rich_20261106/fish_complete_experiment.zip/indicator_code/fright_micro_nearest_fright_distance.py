import pandas as pd
import numpy as np

def compute_indicator(data, config):
    agents = data['agent_states'].copy()
    contacts = data['contacts'].copy()
    fish = agents[agents['role'] == 'fish'][['run_id', 'step', 'agent_id', 'x', 'y']].copy()
    if fish.empty:
        return pd.DataFrame(columns=['run_id', 'step', 'agent_id', 'value'])
    agent_info = agents[['run_id', 'step', 'agent_id', 'x', 'y', 'fright', 'role']].copy()
    agent_info = agent_info.rename(columns={'x': 'x_agent', 'y': 'y_agent', 'fright': 'fright_agent', 'role': 'role_agent'})
    merged = contacts.merge(agent_info, on=['run_id', 'step', 'agent_id'], how='left')
    merged = merged.merge(agent_info, left_on=['run_id', 'step', 'partner_id'], right_on=['run_id', 'step', 'agent_id'], how='left', suffixes=('_focal', '_partner'))
    valid = merged[(merged['role_agent_focal'] == 'fish') & (merged['role_agent_partner'] == 'fish') & (merged['fright_agent_partner'] > 0)].copy()
    if valid.empty:
        fish['value'] = np.nan
        return fish[['run_id', 'step', 'agent_id', 'value']]
    valid['distance'] = np.sqrt((valid['x_agent_focal'] - valid['x_agent_partner'])**2 + (valid['y_agent_focal'] - valid['y_agent_partner'])**2)
    min_dist = valid.groupby(['run_id', 'step', 'agent_id'])['distance'].min().reset_index()
    result = fish.merge(min_dist, on=['run_id', 'step', 'agent_id'], how='left')
    result['value'] = result['distance']
    return result[['run_id', 'step', 'agent_id', 'value']]