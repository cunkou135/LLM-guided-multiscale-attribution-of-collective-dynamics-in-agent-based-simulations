import pandas as pd
import numpy as np

def compute_indicator(data, config):
    agents = data['agent_states'].copy()
    fish = agents[agents['role'] == 'fish'].copy()
    if fish.empty:
        return pd.DataFrame(columns=['run_id', 'step', 'value'])
    fish = fish.sort_values(['run_id', 'agent_id', 'step'])
    fish['prev_fright'] = fish.groupby(['run_id', 'agent_id'])['fright'].shift(1)
    fish['prev_step'] = fish.groupby(['run_id', 'agent_id'])['step'].shift(1)
    fish['defined'] = (fish['prev_step'] == fish['step'] - 1) & fish['fright'].notna() & fish['prev_fright'].notna()
    fish['onset'] = fish['defined'] & (fish['fright'] > 0) & (fish['prev_fright'] == 0)
    results = []
    for (run_id, step), group in fish.groupby(['run_id', 'step']):
        n_defined = group['defined'].sum()
        n_onset = group['onset'].sum()
        if n_defined == 0:
            val = np.nan
        else:
            val = n_onset / n_defined
        results.append({'run_id': run_id, 'step': step, 'value': val})
    return pd.DataFrame(results)