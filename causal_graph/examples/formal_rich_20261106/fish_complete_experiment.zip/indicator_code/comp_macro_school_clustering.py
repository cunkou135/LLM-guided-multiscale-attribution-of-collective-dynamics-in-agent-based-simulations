def compute_indicator(data, config):
    import pandas as pd
    import numpy as np
    from collections import defaultdict

    ag = data['agent_states'][['run_id','step','agent_id','role']].copy()
    ag = ag[ag['role'] == 'fish'].dropna(subset=['agent_id','step','run_id'])
    if len(ag) == 0:
        return pd.Series([], index=pd.MultiIndex.from_tuples([], names=['run_id','step']), dtype=float)
    ag['agent_id'] = ag['agent_id'].astype('int64')
    fish_by = {}
    for (r, s), g in ag.groupby(['run_id','step']):
        fish_by[(r, s)] = g['agent_id'].tolist()

    ct = data['contacts'][['run_id','step','agent_id','partner_id']].dropna().copy()
    if len(ct) > 0:
        ct['agent_id'] = ct['agent_id'].astype('int64')
        ct['partner_id'] = ct['partner_id'].astype('int64')
        ct_groups = dict(list(ct.groupby(['run_id','step'])))
    else:
        ct_groups = {}

    rows = []
    for (r, s), fs in fish_by.items():
        fs_set = set(fs)
        sub = ct_groups.get((r, s))
        neigh = defaultdict(set)
        if sub is not None:
            for u, v in zip(sub['agent_id'].tolist(), sub['partner_id'].tolist()):
                if u in fs_set and v in fs_set and u != v:
                    neigh[u].add(v)
                    neigh[v].add(u)
        tri_x3 = 0
        for a in neigh:
            na = neigh[a]
            for b in na:
                if b <= a:
                    continue
                tri_x3 += len(na & neigh[b])
        T = tri_x3 / 3.0
        Q = 0
        for nid in fs:
            k = len(neigh[nid])
            Q += k * (k - 1) / 2
        if Q == 0:
            rows.append((r, s, float('nan')))
        else:
            rows.append((r, s, 3.0 * T / Q))
    if not rows:
        return pd.Series([], index=pd.MultiIndex.from_tuples([], names=['run_id','step']), dtype=float)
    idx = pd.MultiIndex.from_tuples([(r, s) for r, s, _ in rows], names=['run_id','step'])
    return pd.Series([v for *_ignored, v in rows], index=idx, dtype=float, name='value')
