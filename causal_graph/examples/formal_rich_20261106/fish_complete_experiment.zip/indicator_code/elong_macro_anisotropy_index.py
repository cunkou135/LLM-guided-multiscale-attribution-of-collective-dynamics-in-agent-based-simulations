def compute_indicator(data, config):
    import numpy as np
    import pandas as pd
    agent_states = data['agent_states']
    fish = agent_states[agent_states['role'] == 'fish'][['run_id', 'step', 'x', 'y']].dropna(subset=['x', 'y'])
    steps = []
    vals = []
    for (rid, step), grp in fish.groupby(['run_id', 'step'], observed=True):
        xy = grp[['x', 'y']].values
        if xy.shape[0] < 2:
            val = np.nan
        else:
            cov = np.cov(xy, rowvar=False)
            eigs = np.sort(np.linalg.eigvalsh(cov))[::-1]
            l1, l2 = float(eigs[0]), float(eigs[1])
            s = l1 + l2
            val = (l1 - l2) / s if s > 0 else np.nan
        steps.append(int(step))
        vals.append(val)
    return pd.Series(vals, index=pd.Index(steps, name='step'), dtype=float)