import pandas as pd
import numpy as np

def compute_indicator(data, config):
    states = data['agent_states'][['run_id','step','agent_id','role']].dropna()
    contacts = data['contacts'][['run_id','step','agent_id','partner_id']].dropna()
    fish = states[states['role']=='fish']
    if fish.empty:
        return pd.Series(dtype=float, name='clustering_coefficient')
    results = []
    for (run_id, step), fish_group in fish.groupby(['run_id','step']):
        fish_ids = set(fish_group['agent_id'].values)
        c = contacts[(contacts['run_id']==run_id) & (contacts['step']==step)]
        if c.empty:
            continue
        adj = {}
        for _, row in c.iterrows():
            a = row['agent_id']
            b = row['partner_id']
            adj.setdefault(a, set()).add(b)
            adj.setdefault(b, set()).add(a)
        for fid in fish_ids:
            if fid not in adj:
                continue
            N = adj[fid]
            k = len(N)
            if k < 2:
                continue
            T = 0
            N_list = list(N)
            for i in range(len(N_list)):
                for j in range(i+1, len(N_list)):
                    ni = N_list[i]
                    nj = N_list[j]
                    if ni in adj and nj in adj.get(ni, set()):
                        T += 1
            if T == 0:
                cc = 0.0
            else:
                cc = 2.0 * T / (k * (k - 1))
            results.append({'run_id': run_id, 'step': step, 'agent_id': fid, 'cc': cc})
    if not results:
        return pd.Series(dtype=float, name='clustering_coefficient')
    out = pd.DataFrame(results)
    result = pd.Series(out['cc'].values, index=pd.MultiIndex.from_frame(out[['run_id','step','agent_id']]), name='clustering_coefficient')
    return result
