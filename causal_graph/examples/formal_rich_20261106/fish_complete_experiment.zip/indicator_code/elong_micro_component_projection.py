import pandas as pd
import numpy as np
from collections import defaultdict

def _uf(nodes, edges):
    parent = {n: n for n in nodes}
    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x
    for a, b in edges:
        if a in parent and b in parent:
            ra, rb = find(a), find(b)
            if ra != rb:
                parent[ra] = rb
    return {n: find(n) for n in nodes}

def compute_indicator(data, config):
    min_eig = float(config.get('min_eigenvalue', 1e-12))
    ast = data['agent_states'][['run_id', 'step', 'agent_id', 'role', 'x', 'y']]
    con = data['contacts'][['run_id', 'step', 'agent_id', 'partner_id']]
    fish = ast[ast['role'] == 'fish']
    con_groups = {}
    for k, gg in con.groupby(['run_id', 'step']):
        con_groups[(k[0], int(k[1]))] = gg
    rows = []
    for k, g in fish.groupby(['run_id', 'step']):
        run_id = k[0]
        step = int(k[1])
        nodes = g['agent_id'].tolist()
        node_set = set(nodes)
        posx = dict(zip(g['agent_id'].values, g['x'].values))
        posy = dict(zip(g['agent_id'].values, g['y'].values))
        edges = []
        cg = con_groups.get((run_id, step))
        if cg is not None:
            for a, b in zip(cg['agent_id'].values, cg['partner_id'].values):
                if a in node_set and b in node_set and a != b:
                    edges.append((a, b))
        comp = _uf(nodes, edges)
        members = defaultdict(list)
        for a in nodes:
            members[comp[a]].append(a)
        comp_stats = {}
        for root, mem in members.items():
            pts = np.array([[posx[m], posy[m]] for m in mem], dtype=float)
            if pts.shape[0] < 2:
                comp_stats[root] = (None, None, None)
                continue
            c = pts.mean(axis=0)
            D = pts - c
            C = (D.T @ D) / pts.shape[0]
            try:
                w, V = np.linalg.eigh(C)
            except np.linalg.LinAlgError:
                comp_stats[root] = (None, None, None)
                continue
            lam1 = w[1]
            u1 = V[:, 1]
            if lam1 <= min_eig:
                comp_stats[root] = (None, None, None)
            else:
                comp_stats[root] = (c, u1, lam1)
        for a in nodes:
            root = comp[a]
            c, u1, lam1 = comp_stats[root]
            if c is None:
                rows.append((run_id, step, int(a), np.nan))
                continue
            d = np.array([posx[a] - c[0], posy[a] - c[1]])
            v = float((d @ u1) / np.sqrt(lam1))
            rows.append((run_id, step, int(a), v))
    out = pd.DataFrame(rows, columns=['run_id', 'step', 'agent_id', 'value'])
    out = out.set_index(['run_id', 'step', 'agent_id'])['value']
    return out
