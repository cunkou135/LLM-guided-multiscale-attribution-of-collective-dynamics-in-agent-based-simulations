def compute_indicator(data, config):
    import pandas as pd
    from collections import defaultdict

    ag = data['agent_states'][['run_id','step','agent_id','role']].copy()
    ag = ag[ag['role'] == 'fish'].dropna(subset=['agent_id','step','run_id'])
    if len(ag) == 0:
        return pd.Series([], index=pd.MultiIndex.from_tuples([], names=['run_id','step']), dtype=float)
    ag['agent_id'] = ag['agent_id'].astype('int64')
    fish_by = {}
    for (r, s), g in ag.groupby(['run_id','step']):
        fish_by[(r, s)] = g['agent_id'].tolist()

    ct = data['contacts'][['run_id','step','agent_id','partner_id']].dropna().copy()
    if len(ct) > 0:
        ct['agent_id'] = ct['agent_id'].astype('int64')
        ct['partner_id'] = ct['partner_id'].astype('int64')
        ct_groups = dict(list(ct.groupby(['run_id','step'])))
    else:
        ct_groups = {}

    rows = []
    for (r, s), fs in fish_by.items():
        n = len(fs)
        if n == 0:
            continue
        fs_set = set(fs)
        sub = ct_groups.get((r, s))
        degree = defaultdict(int)
        if sub is not None:
            for u, v in zip(sub['agent_id'].tolist(), sub['partner_id'].tolist()):
                if u in fs_set and v in fs_set and u != v:
                    degree[u] += 1
                    degree[v] += 1
        tot = sum(degree.get(nid, 0) for nid in fs)
        rows.append((r, s, float(tot) / n))
    if not rows:
        return pd.Series([], index=pd.MultiIndex.from_tuples([], names=['run_id','step']), dtype=float)
    idx = pd.MultiIndex.from_tuples([(r, s) for r, s, _ in rows], names=['run_id','step'])
    return pd.Series([v for *_ignored, v in rows], index=idx, dtype=float, name='value')
