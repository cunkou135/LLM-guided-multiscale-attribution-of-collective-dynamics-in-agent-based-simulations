import pandas as pd
import numpy as np
import json

def compute_indicator(data, config):
    events = data['events'].copy()
    events = events[events['role'] == 'fish']
    if events.empty:
        return pd.DataFrame(columns=['run_id', 'step', 'value'])
    def parse_escape(dj):
        try:
            obj = json.loads(dj)
            ed = obj.get('escape_direction')
            if ed is not None and isinstance(ed, list) and len(ed) == 2:
                return ed
        except:
            pass
        return None
    events['escape_direction'] = events['decision_json'].apply(parse_escape)
    events = events.dropna(subset=['escape_direction'])
    if events.empty:
        return pd.DataFrame(columns=['run_id', 'step', 'value'])
    def to_unit(v):
        arr = np.array(v, dtype=float)
        norm = np.linalg.norm(arr)
        if norm > 0:
            return arr / norm
        return None
    events['unit'] = events['escape_direction'].apply(to_unit)
    events = events.dropna(subset=['unit'])
    grouped = events.groupby(['run_id', 'step'])
    results = []
    for (run_id, step), group in grouped:
        vecs = np.stack(group['unit'].values)
        if len(vecs) == 0:
            val = np.nan
        else:
            mean_vec = vecs.mean(axis=0)
            val = np.linalg.norm(mean_vec)
        results.append({'run_id': run_id, 'step': step, 'value': val})
    return pd.DataFrame(results)