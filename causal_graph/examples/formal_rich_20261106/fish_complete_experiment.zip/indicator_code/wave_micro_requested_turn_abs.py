def compute_indicator(data, config):
    import pandas as pd
    import json
    events = data['events']
    rows = []
    for st, ag, dj in zip(events['step'].values, events['agent_id'].values, events['decision_json'].values):
        try:
            d = json.loads(dj) if isinstance(dj, str) else None
        except Exception:
            d = None
        if isinstance(d, dict) and d.get('requested_turn') is not None:
            try:
                tv = float(d['requested_turn'])
            except Exception:
                continue
            rows.append({'step': int(st), 'agent_id': int(ag), 'val': abs(tv)})
    if not rows:
        return pd.Series(dtype=float, index=pd.MultiIndex.from_arrays([[], []], names=['step', 'agent_id']))
    df = pd.DataFrame(rows)
    idx = pd.MultiIndex.from_arrays([df['step'].astype(int).values, df['agent_id'].astype(int).values], names=['step', 'agent_id'])
    return pd.Series(df['val'].values, index=idx, dtype=float).sort_index()