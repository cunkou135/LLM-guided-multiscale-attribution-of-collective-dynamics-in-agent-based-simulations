import pandas as pd
import numpy as np

def compute_indicator(data, config):
    states = data['agent_states'][['run_id','step','agent_id','role','heading']].dropna(subset=['heading'])
    contacts = data['contacts'][['run_id','step','agent_id','partner_id']].dropna()
    if contacts.empty or states.empty:
        return pd.Series(dtype=float, name='neighbor_alignment')
    edges1 = contacts.rename(columns={'agent_id':'a','partner_id':'b'})[['run_id','step','a','b']]
    edges2 = contacts.rename(columns={'partner_id':'a','agent_id':'b'})[['run_id','step','a','b']]
    edges = pd.concat([edges1, edges2], ignore_index=True).drop_duplicates()
    focal = edges.merge(states, left_on=['run_id','step','a'], right_on=['run_id','step','agent_id'], how='inner')
    neighbor = edges.merge(states, left_on=['run_id','step','b'], right_on=['run_id','step','agent_id'], how='inner')
    neighbor['sin_h'] = np.sin(neighbor['heading'])
    neighbor['cos_h'] = np.cos(neighbor['heading'])
    grp = neighbor.groupby(['run_id','step','a']).agg(mean_sin=('sin_h','mean'), mean_cos=('cos_h','mean')).reset_index()
    grp['theta_N'] = np.arctan2(grp['mean_sin'], grp['mean_cos'])
    focal_unique = focal[['run_id','step','a','role','heading']].drop_duplicates()
    merged = focal_unique.merge(grp, on=['run_id','step','a'], how='inner')
    merged = merged[merged['role'] == 'fish']
    if merged.empty:
        return pd.Series(dtype=float, name='neighbor_alignment')
    diff = merged['heading'] - merged['theta_N']
    align = np.cos(diff)
    result = pd.Series(align.values, index=pd.MultiIndex.from_frame(merged[['run_id','step','a']].rename(columns={'a':'agent_id'})), name='neighbor_alignment')
    return result
