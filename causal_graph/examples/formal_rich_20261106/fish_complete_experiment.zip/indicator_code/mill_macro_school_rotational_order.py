import pandas as pd
import numpy as np

def compute_indicator(data, config):
    ag = data['agent_states']
    fish = ag[ag['role'] == 'fish'].copy()
    if fish.empty:
        return pd.Series(dtype=float, name='value')
    def calc(g):
        x = g['x'].to_numpy(dtype=float)
        y = g['y'].to_numpy(dtype=float)
        N = len(g)
        if N == 0:
            return np.nan
        if np.any(np.isnan(x)) or np.any(np.isnan(y)):
            return np.nan
        cx = x.mean()
        cy = y.mean()
        rx = x - cx
        ry = y - cy
        r = np.sqrt(rx*rx + ry*ry)
        if np.any(r == 0):
            return np.nan
        tx = -ry / r
        ty = rx / r
        mx = tx.mean()
        my = ty.mean()
        return np.sqrt(mx*mx + my*my)
    res = fish.groupby(['run_id','step'], sort=False).apply(calc)
    res.name = 'value'
    return res
