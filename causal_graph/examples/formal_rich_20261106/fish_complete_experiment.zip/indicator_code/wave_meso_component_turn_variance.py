def compute_indicator(data, config):
    import numpy as np
    import pandas as pd
    import json
    from collections import defaultdict
    agent_states = data['agent_states']
    contacts = data['contacts']
    events = data['events']
    fish = agent_states[agent_states['role'] == 'fish'][['run_id', 'step', 'agent_id']]
    req_rows = []
    for rid, st, ag, dj in zip(events['run_id'].values, events['step'].values, events['agent_id'].values, events['decision_json'].values):
        try:
            d = json.loads(dj) if isinstance(dj, str) else None
        except Exception:
            d = None
        if isinstance(d, dict) and d.get('requested_turn') is not None:
            try:
                tv = float(d['requested_turn'])
            except Exception:
                continue
            req_rows.append({'run_id': rid, 'step': int(st), 'agent_id': int(ag), 'req_turn': tv})
    req = pd.DataFrame(req_rows, columns=['run_id', 'step', 'agent_id', 'req_turn'])
    rows = []
    for (rid, st), grp in contacts.groupby(['run_id', 'step'], observed=True):
        adj = defaultdict(set)
        for a, b in zip(grp['agent_id'].values, grp['partner_id'].values):
            if pd.isna(a) or pd.isna(b):
                continue
            ai = int(a); bi = int(b)
            if ai == bi:
                continue
            adj[ai].add(bi); adj[bi].add(ai)
        seen = set(); cid = 0
        for node in list(adj.keys()):
            if node in seen:
                continue
            stack = [node]; comp = []
            while stack:
                cur = stack.pop()
                if cur in seen:
                    continue
                seen.add(cur); comp.append(cur)
                for nb in adj[cur]:
                    if nb not in seen:
                        stack.append(nb)
            for m in comp:
                rows.append({'run_id': rid, 'step': int(st), 'group_id': int(cid), 'agent_id': int(m)})
            cid += 1
    if not rows:
        return pd.Series(dtype=float, index=pd.MultiIndex.from_arrays([[], []], names=['step', 'group_id']))
    comp_df = pd.DataFrame(rows)
    merged = comp_df.merge(fish, on=['run_id', 'step', 'agent_id'], how='inner')
    if req.shape[0] > 0:
        merged = merged.merge(req, on=['run_id', 'step', 'agent_id'], how='left')
    else:
        merged['req_turn'] = np.nan
    if merged.shape[0] == 0:
        return pd.Series(dtype=float, index=pd.MultiIndex.from_arrays([[], []], names=['step', 'group_id']))
    steps = []; gids = []; vals = []
    for (rid, step, gid), grp in merged.groupby(['run_id', 'step', 'group_id'], observed=True):
        sub = grp.dropna(subset=['req_turn'])
        if sub.shape[0] == 0:
            val = np.nan
        else:
            t = sub['req_turn'].values
            m = t.mean()
            val = float(np.mean((t - m) ** 2))
        steps.append(int(step)); gids.append(int(gid)); vals.append(val)
    idx = pd.MultiIndex.from_arrays([steps, gids], names=['step', 'group_id'])
    return pd.Series(vals, index=idx, dtype=float).sort_index()