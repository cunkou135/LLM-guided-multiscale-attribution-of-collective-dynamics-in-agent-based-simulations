import numpy as np
import pandas as pd


def compute_indicator(data, config):
    mode = str(config.get("mode", "scalar"))
    contacts = data["contacts"]
    model_states = data["model_states"]

    con = contacts[["step"]].dropna(subset=["step"])
    con = con.assign(step=con["step"].astype("int64"))
    c_counts = con.groupby("step").size().sort_index()
    c_steps = c_counts.index.to_numpy(dtype="int64")
    c_vals = c_counts.to_numpy(dtype="float64")

    ms = model_states[["step", "quarantined"]].dropna(subset=["step", "quarantined"])
    ms = ms.assign(step=ms["step"].astype("int64")).sort_values("step")
    ms_steps = ms["step"].to_numpy(dtype="int64")
    q_vals = ms["quarantined"].astype("float64").to_numpy()

    axis_steps = np.array(
        sorted(set(int(s) for s in c_steps) | set(int(s) for s in ms_steps)), dtype="int64"
    )
    if axis_steps.size == 0:
        return pd.Series(dtype="float64", index=pd.Index([], name="step", dtype="int64"), name="value")

    delta_c = {}
    for i in range(1, len(c_steps)):
        if c_steps[i] - c_steps[i - 1] == 1:
            delta_c[int(c_steps[i])] = float(c_vals[i] - c_vals[i - 1])

    delta_q = {}
    for i in range(1, len(ms_steps)):
        if ms_steps[i] - ms_steps[i - 1] == 1:
            delta_q[int(ms_steps[i])] = float(q_vals[i] - q_vals[i - 1])

    increase_vals = []
    zero_vals = []
    increase_by_step = {}
    for t, dc in delta_c.items():
        dq = delta_q.get(t)
        if dq is None:
            continue
        if dq > 0.0:
            increase_vals.append(dc)
            increase_by_step[t] = dc
        elif dq == 0.0:
            zero_vals.append(dc)

    if not increase_vals or not zero_vals:
        return pd.Series(
            np.full(axis_steps.size, np.nan, dtype="float64"),
            index=pd.Index(axis_steps, name="step"),
            name="value",
        )

    a_mean = float(np.mean(increase_vals))
    b_mean = float(np.mean(zero_vals))

    if mode == "residual":
        values = np.full(axis_steps.size, np.nan, dtype="float64")
        for i, s in enumerate(axis_steps):
            key = int(s)
            if key in increase_by_step:
                values[i] = increase_by_step[key] - b_mean
        return pd.Series(values, index=pd.Index(axis_steps, name="step"), name="value")

    return pd.Series(
        np.full(axis_steps.size, a_mean - b_mean, dtype="float64"),
        index=pd.Index(axis_steps, name="step"),
        name="value",
    )
