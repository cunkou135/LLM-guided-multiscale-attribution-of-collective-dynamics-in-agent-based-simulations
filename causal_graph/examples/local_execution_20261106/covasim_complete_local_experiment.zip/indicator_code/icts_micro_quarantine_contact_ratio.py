import numpy as np
import pandas as pd


def compute_indicator(data, config):
    window = int(config.get("window", 7))
    labels = config.get("quarantine_state_labels") or ["quarantined"]
    aggregation = str(config.get("aggregation", "mean"))
    events = data["events"]
    contacts = data["contacts"]

    q = events[["run_id", "step", "agent_id", "state", "before", "after"]].dropna(subset=["step"])
    if q.empty:
        return pd.Series(dtype="float64", index=pd.Index([], name="step", dtype="int64"), name="value")

    before = pd.array(q["before"], dtype="boolean").fillna(False).to_numpy(dtype=bool)
    after = pd.array(q["after"], dtype="boolean").fillna(False).to_numpy(dtype=bool)
    state_hit = q["state"].isin(labels).fillna(False).to_numpy(dtype=bool)
    onsets = q.loc[state_hit & (~before) & after, ["run_id", "step", "agent_id"]]
    if onsets.empty:
        return pd.Series(dtype="float64", index=pd.Index([], name="step", dtype="int64"), name="value")

    con = contacts[["run_id", "step", "agent_id", "partner_id"]].dropna(
        subset=["run_id", "step", "agent_id", "partner_id"]
    )
    con = con[con["agent_id"] != con["partner_id"]]

    fwd = con.rename(columns={"agent_id": "a", "partner_id": "p"})[["run_id", "step", "a", "p"]]
    bwd = con.rename(columns={"partner_id": "a", "agent_id": "p"})[["run_id", "step", "a", "p"]]
    edges = pd.concat([fwd, bwd], ignore_index=True)

    groups = {}
    for key, g in edges.groupby("run_id", sort=False):
        g = g.sort_values("step")
        groups[key] = (
            g["step"].to_numpy(dtype="int64"),
            g["a"].to_numpy(),
            g["p"].to_numpy(),
        )

    out_steps = []
    out_values = []
    for run_id, step, agent_id in onsets.itertuples(index=False):
        out_steps.append(step)
        entry = groups.get(run_id)
        if entry is None or pd.isna(agent_id):
            out_values.append(np.nan)
            continue
        steps_arr, a_arr, p_arr = entry
        lo = int(np.searchsorted(steps_arr, step - window, side="left"))
        hi = int(np.searchsorted(steps_arr, step - 1, side="right"))
        pre = pd.unique(p_arr[lo:hi][a_arr[lo:hi] == agent_id]) if hi > lo else np.array([])
        lo2 = int(np.searchsorted(steps_arr, step + 1, side="left"))
        hi2 = int(np.searchsorted(steps_arr, step + window, side="right"))
        post = pd.unique(p_arr[lo2:hi2][a_arr[lo2:hi2] == agent_id]) if hi2 > lo2 else np.array([])
        if len(pre) == 0:
            out_values.append(np.nan)
            continue
        out_values.append(float(len(post)) / float(len(pre)))

    frame = pd.DataFrame({"step": out_steps, "value": out_values})
    series = frame.groupby("step")["value"].agg(aggregation).sort_index()
    series.index = series.index.astype("int64")
    series.index.name = "step"
    series.name = "value"
    return series
