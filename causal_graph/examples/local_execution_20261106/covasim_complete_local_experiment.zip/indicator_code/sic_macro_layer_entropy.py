import numpy as np
import pandas as pd


def _infection_mask(df, config):
    event_types = config.get("infection_event_types") or []
    states = config.get("infection_states") or []
    mask = pd.Series(False, index=df.index)
    if event_types:
        mask = mask | df["event_type"].isin(event_types).fillna(False).astype(bool)
    if states:
        mask = mask | df["state"].isin(states).fillna(False).astype(bool)
    return mask


def compute_indicator(data, config):
    events = data["events"]
    contacts = data["contacts"]
    window = int(config.get("window", 1))
    if window < 1:
        window = 1

    ev = events.loc[_infection_mask(events, config), ["step", "layer"]].dropna(subset=["step", "layer"])
    con = contacts[["step", "layer"]].dropna(subset=["step", "layer"])

    ev = ev.assign(step=ev["step"].astype("int64"), layer=ev["layer"].astype(str))
    con = con.assign(step=con["step"].astype("int64"), layer=con["layer"].astype(str))

    layers = sorted(set(ev["layer"].unique()) | set(con["layer"].unique()))
    steps = np.array(sorted(set(ev["step"].unique()) | set(con["step"].unique())), dtype="int64")
    n_layers = len(layers)

    if steps.size == 0:
        return pd.Series(dtype="float64", index=pd.Index([], name="step", dtype="int64"), name="layer_entropy")
    if n_layers <= 1 or ev.empty:
        return pd.Series(
            np.full(steps.size, np.nan, dtype="float64"),
            index=pd.Index(steps, name="step"),
            name="layer_entropy",
        )

    mat = (
        ev.groupby(["step", "layer"]).size().unstack(fill_value=0)
        .reindex(index=steps, columns=layers, fill_value=0)
        .fillna(0.0)
        .to_numpy(dtype="float64")
    )

    lo = np.searchsorted(steps, steps, side="left")
    hi = np.searchsorted(steps, steps + (window - 1), side="right")

    zeros = np.zeros((1, n_layers), dtype="float64")
    pre = np.vstack([zeros, np.cumsum(mat, axis=0)])
    windows = pre[hi] - pre[lo]

    totals = windows.sum(axis=1)
    safe_total = np.where(totals > 0.0, totals, 1.0)
    probs = windows / safe_total[:, None]
    safe_probs = np.where(probs > 0.0, probs, 1.0)
    terms = np.where(probs > 0.0, probs * np.log(safe_probs), 0.0)

    with np.errstate(divide="ignore", invalid="ignore"):
        entropy = -terms.sum(axis=1) / np.log(float(n_layers))

    entropy = np.where(totals > 0.0, entropy, np.nan)
    return pd.Series(entropy, index=pd.Index(steps, name="step"), name="layer_entropy")
