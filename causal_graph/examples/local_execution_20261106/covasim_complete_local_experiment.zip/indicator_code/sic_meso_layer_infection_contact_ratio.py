import numpy as np
import pandas as pd


def _infection_mask(df, config):
    event_types = config.get("infection_event_types") or []
    states = config.get("infection_states") or []
    mask = pd.Series(False, index=df.index)
    if event_types:
        mask = mask | df["event_type"].isin(event_types).fillna(False).astype(bool)
    if states:
        mask = mask | df["state"].isin(states).fillna(False).astype(bool)
    return mask


def compute_indicator(data, config):
    events = data["events"]
    contacts = data["contacts"]
    window = int(config.get("window", 1))
    if window < 1:
        window = 1

    ev = events.loc[_infection_mask(events, config), ["step", "layer"]].dropna(subset=["step", "layer"])
    con = contacts[["step", "layer"]].dropna(subset=["step", "layer"])

    ev = ev.assign(step=ev["step"].astype("int64"), layer=ev["layer"].astype(str))
    con = con.assign(step=con["step"].astype("int64"), layer=con["layer"].astype(str))

    layers = sorted(set(ev["layer"].unique()) | set(con["layer"].unique()))
    steps = np.array(sorted(set(ev["step"].unique()) | set(con["step"].unique())), dtype="int64")
    if not layers or steps.size == 0:
        return pd.DataFrame(index=pd.Index([], name="step", dtype="int64"))

    if ev.empty:
        i_mat = np.zeros((steps.size, len(layers)), dtype="float64")
    else:
        i_mat = (
            ev.groupby(["step", "layer"]).size().unstack(fill_value=0)
            .reindex(index=steps, columns=layers, fill_value=0)
            .fillna(0.0)
            .to_numpy(dtype="float64")
        )

    if con.empty:
        c_mat = np.zeros((steps.size, len(layers)), dtype="float64")
    else:
        c_mat = (
            con.groupby(["step", "layer"]).size().unstack(fill_value=0)
            .reindex(index=steps, columns=layers, fill_value=0)
            .fillna(0.0)
            .to_numpy(dtype="float64")
        )

    lo = np.searchsorted(steps, steps, side="left")
    hi = np.searchsorted(steps, steps + (window - 1), side="right")

    zeros = np.zeros((1, len(layers)), dtype="float64")
    i_pre = np.vstack([zeros, np.cumsum(i_mat, axis=0)])
    c_pre = np.vstack([zeros, np.cumsum(c_mat, axis=0)])

    i_win = i_pre[hi] - i_pre[lo]
    c_win = c_pre[hi] - c_pre[lo]

    safe = np.where(c_win > 0.0, c_win, 1.0)
    with np.errstate(divide="ignore", invalid="ignore"):
        ratio = np.where(c_win > 0.0, i_win / safe, np.nan)

    return pd.DataFrame(ratio, index=pd.Index(steps, name="step"), columns=layers)
