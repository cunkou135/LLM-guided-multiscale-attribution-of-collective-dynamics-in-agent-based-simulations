import numpy as np
import pandas as pd


def _empty(layers, steps):
    return pd.DataFrame(
        index=pd.Index(steps, name="step", dtype="int64"),
        columns=layers,
        dtype="float64",
    )


def compute_indicator(data, config):
    window = int(config.get("window", 7))
    reduction = str(config.get("reduction", "median"))
    contacts = data["contacts"]
    model_states = data["model_states"]

    ms = model_states[["step", "quarantined"]].dropna(subset=["step", "quarantined"])
    ms = ms.assign(step=ms["step"].astype("int64")).sort_values("step")
    if ms.empty:
        return pd.DataFrame(index=pd.Index([], name="step", dtype="int64"))

    q_vals = ms["quarantined"].astype("float64").to_numpy()
    ms_steps = ms["step"].to_numpy(dtype="int64")
    onset_steps = [int(ms_steps[i]) for i in range(1, len(ms_steps)) if q_vals[i] > q_vals[i - 1]]

    con = contacts[["step", "layer"]].dropna(subset=["step", "layer"])
    con = con.assign(step=con["step"].astype("int64"), layer=con["layer"].astype(str))
    counts = con.groupby(["step", "layer"]).size()
    count_lookup = counts.to_dict()
    observed_steps = set(int(s) for s in con["step"].unique())
    layers = sorted(con["layer"].unique())
    axis_steps = sorted(set(int(s) for s in ms_steps) | observed_steps)

    if not layers or window < 1 or not onset_steps:
        return _empty(layers, axis_steps)

    def _count(u, layer):
        return float(count_lookup.get((u, layer), 0.0))

    per_onset = {}
    for t in onset_steps:
        pre = [u for u in range(t - window, t) if u in observed_steps]
        post = [u for u in range(t + 1, t + window + 1) if u in observed_steps]
        if not pre or not post:
            continue
        row = {}
        for layer in layers:
            c_pre = float(np.mean([_count(u, layer) for u in pre]))
            c_post = float(np.mean([_count(u, layer) for u in post]))
            row[layer] = c_post - c_pre
        per_onset[t] = row

    if not per_onset:
        return _empty(layers, axis_steps)

    frame = pd.DataFrame.from_dict(per_onset, orient="index").reindex(columns=layers)
    frame.index = pd.Index(sorted(frame.index), name="step").astype("int64")

    if reduction == "per_onset":
        return frame.sort_index()

    medians = frame.median(axis=0, skipna=True)
    return pd.DataFrame(
        {layer: np.full(len(axis_steps), float(medians[layer]), dtype="float64") for layer in layers},
        index=pd.Index(axis_steps, name="step", dtype="int64"),
    )
